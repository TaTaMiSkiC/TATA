"use client";
import type { User } from '@/lib/types';
import { useState, useEffect, useCallback } from 'react'; // Added useCallback
import { getUserByEmail, addUser as serviceAddUser } from '@/services/userService'; 

const getMockUserRole = (): User['role'] | null => {
  if (typeof window !== 'undefined') {
    const role = localStorage.getItem('mockUserRole') as User['role'];
    if (role === 'admin' || role === 'moderator' || role === 'korisnik') {
      return role;
    }
  }
  return null;
};

const getMockUserId = (): string | null => {
  if (typeof window !== 'undefined') {
    return localStorage.getItem('mockUserId');
  }
  return null;
};

const getMockUserEmail = (): string | null => {
    if (typeof window !== 'undefined') {
        return localStorage.getItem('mockUserEmail');
    }
    return null;
}

export function useAuth() {
  const [userRole, setUserRole] = useState<User['role'] | null>(null);
  const [userId, setUserId] = useState<string | null>(null);
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const role = getMockUserRole();
    const id = getMockUserId();
    const email = getMockUserEmail();

    setUserRole(role);
    setUserId(id);
    setUserEmail(email);
    setIsLoading(false);

    const handleStorageChange = (event: StorageEvent) => {
      if (event.key === 'mockUserRole' || event.key === 'mockUserId' || event.key === 'mockUserEmail') {
        setUserRole(getMockUserRole());
        setUserId(getMockUserId());
        setUserEmail(getMockUserEmail());
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  const setAuthData_DEV_ONLY = useCallback((role: User['role'] | null, id: string | null, email: string | null) => {
    if (typeof window !== 'undefined') {
      if (role && id && email) {
        localStorage.setItem('mockUserRole', role);
        localStorage.setItem('mockUserId', id);
        localStorage.setItem('mockUserEmail', email);
      } else {
        localStorage.removeItem('mockUserRole');
        localStorage.removeItem('mockUserId');
        localStorage.removeItem('mockUserEmail');
      }
      setUserRole(role);
      setUserId(id);
      setUserEmail(email);
    }
  }, []); 
  
  const login_DEV_ONLY = useCallback(async (emailInput: string, passwordInput: string): Promise<User['role'] | 'user_not_found' | 'invalid_password'> => {
    const foundUser = await getUserByEmail(emailInput);
    if (foundUser) {
      // In a real app, compare hashed passwords. For this mock, direct comparison.
      if (foundUser.password === passwordInput) { 
        setAuthData_DEV_ONLY(foundUser.role, foundUser.id, foundUser.email);
        return foundUser.role;
      } else {
        return 'invalid_password';
      }
    } else {
      return 'user_not_found';
    }
  }, [setAuthData_DEV_ONLY]);

  const register_DEV_ONLY = useCallback(async (userData: Omit<User, 'id' | 'role'> & {role?: User['role']}) => {
    const existingUser = await getUserByEmail(userData.email);
    if (existingUser) {
      throw new Error("Korisnik s ovom email adresom već postoji.");
    }
    const newUser = await serviceAddUser({
      ...userData,
      role: userData.role || 'korisnik', // Default to 'korisnik' if not provided
    });
    return newUser;
  }, []); // Assuming getUserByEmail and serviceAddUser are stable imports

  const logout_DEV_ONLY = useCallback(() => {
    setAuthData_DEV_ONLY(null, null, null);
  }, [setAuthData_DEV_ONLY]);

  return {
    userId,
    userEmail,
    role: userRole,
    isLoggedIn: userRole !== null && userId !== null,
    isAdmin: userRole === 'admin',
    isModerator: userRole === 'moderator',
    isKorisnik: userRole === 'korisnik',
    isLoading,
    login_DEV_ONLY,
    register_DEV_ONLY,
    logout_DEV_ONLY,
    _setAuthData_DEV_ONLY: setAuthData_DEV_ONLY,
  };
}

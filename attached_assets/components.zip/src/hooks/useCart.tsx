
"use client";

import type { Product, CartItem as CartItemTypeFromLib } from '@/lib/types'; // Renamed to avoid conflict
import type { ReactNode } from 'react';
import { useEffect, useReducer, useCallback } from 'react';
import { createSafeContext } from '@/lib/createSafeContext';

// Define CartItem type for use within this hook
export interface CartItem extends CartItemTypeFromLib {
  // selectedFragrance and selectedColor are already in CartItemTypeFromLib via Product
}

interface CartState {
  items: CartItem[];
  totalItems: number;
  totalPrice: number;
  isCartOpen: boolean;
}

interface CartContextType extends CartState {
  addItem: (product: Product, quantity?: number, selectedFragrance?: string, selectedColor?: string) => void;
  removeItem: (productId: string, selectedFragrance?: string, selectedColor?: string) => void;
  updateItemQuantity: (productId: string, selectedFragrance: string | undefined, selectedColor: string | undefined, quantity: number) => void;
  clearCart: () => void;
  toggleCart: () => void;
  getItemQuantity: (productId: string, selectedFragrance?: string, selectedColor?: string) => number;
}

const initialState: CartState = {
  items: [],
  totalItems: 0,
  totalPrice: 0,
  isCartOpen: false,
};

type CartAction =
  | { type: 'ADD_ITEM'; payload: { product: Product; quantity: number; selectedFragrance?: string; selectedColor?: string } }
  | { type: 'REMOVE_ITEM'; payload: { productId: string; selectedFragrance?: string; selectedColor?: string } }
  | { type: 'UPDATE_ITEM_QUANTITY'; payload: { productId: string; selectedFragrance?: string; selectedColor?: string; quantity: number } }
  | { type: 'CLEAR_CART' }
  | { type: 'TOGGLE_CART' }
  | { type: 'LOAD_CART'; payload: CartState };


const cartReducer = (state: CartState, action: CartAction): CartState => {
  let newState: CartState;
  switch (action.type) {
    case 'ADD_ITEM': {
      const { product, quantity, selectedFragrance, selectedColor } = action.payload;
      const existingItemIndex = state.items.findIndex(
        item => item.id === product.id && item.selectedFragrance === selectedFragrance && item.selectedColor === selectedColor
      );
      let updatedItems;
      if (existingItemIndex > -1) {
        updatedItems = state.items.map((item, index) =>
          index === existingItemIndex ? { ...item, quantity: item.quantity + quantity } : item
        );
      } else {
        const newItem: CartItem = {
          ...product, 
          quantity,
          selectedFragrance,
          selectedColor,
        };
        updatedItems = [...state.items, newItem];
      }
      newState = { ...state, items: updatedItems };
      break;
    }
    case 'REMOVE_ITEM': {
      const { productId, selectedFragrance, selectedColor } = action.payload;
      newState = { 
        ...state, 
        items: state.items.filter(item => !(item.id === productId && item.selectedFragrance === selectedFragrance && item.selectedColor === selectedColor)) 
      };
      break;
    }
    case 'UPDATE_ITEM_QUANTITY': {
      const { productId, selectedFragrance, selectedColor, quantity } = action.payload;
      if (quantity <= 0) {
        newState = { 
          ...state, 
          items: state.items.filter(item => !(item.id === productId && item.selectedFragrance === selectedFragrance && item.selectedColor === selectedColor)) 
        };
      } else {
        newState = {
          ...state,
          items: state.items.map(item =>
            (item.id === productId && item.selectedFragrance === selectedFragrance && item.selectedColor === selectedColor) 
            ? { ...item, quantity } 
            : item
          ),
        };
      }
      break;
    }
    case 'CLEAR_CART':
      newState = { ...initialState, isCartOpen: state.isCartOpen };
      break;
    case 'TOGGLE_CART':
      newState = { ...state, isCartOpen: !state.isCartOpen };
      break;
    case 'LOAD_CART':
      return action.payload;
    default:
      newState = state;
  }

  if (['ADD_ITEM', 'REMOVE_ITEM', 'UPDATE_ITEM_QUANTITY', 'CLEAR_CART'].includes(action.type)) {
    newState.totalItems = newState.items.reduce((sum, item) => sum + item.quantity, 0);
    newState.totalPrice = newState.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    
    if (typeof window !== 'undefined') {
        localStorage.setItem('cart', JSON.stringify(newState));
    }
  }
  return newState;
};

const [ProviderComponent, useSafeCartContext] = createSafeContext<CartContextType>();
export { useSafeCartContext as useCart };

export const CartProvider = ({ children }: { children: ReactNode }) => {
  const [state, dispatch] = useReducer(cartReducer, initialState);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const storedCart = localStorage.getItem('cart');
      if (storedCart) { 
        try {
          const parsedData = JSON.parse(storedCart);
          if (typeof parsedData === 'object' && parsedData !== null && Array.isArray(parsedData.items)) {
            const loadedCartState: CartState = {
              items: parsedData.items.map((item: any) => ({ 
                id: item.id,
                name: item.name,
                price: item.price,
                imageUrl: item.imageUrl,
                categorySlug: item.categorySlug,
                stock: item.stock, 
                fragrances: item.fragrances,
                colorSelections: item.colorSelections, // Load colorSelections
                hasSelectableColors: item.hasSelectableColors, // Load hasSelectableColors
                quantity: typeof item.quantity === 'number' ? item.quantity : 1,
                selectedFragrance: item.selectedFragrance,
                selectedColor: item.selectedColor, // Load selectedColor
              })),
              totalItems: typeof parsedData.totalItems === 'number' ? parsedData.totalItems : 0,
              totalPrice: typeof parsedData.totalPrice === 'number' ? parsedData.totalPrice : 0,
              isCartOpen: typeof parsedData.isCartOpen === 'boolean' ? parsedData.isCartOpen : false,
            };
            dispatch({ type: 'LOAD_CART', payload: loadedCartState });
          } else {
            console.warn("Cart data in localStorage was not valid. Resetting cart.");
            localStorage.removeItem('cart');
            dispatch({ type: 'LOAD_CART', payload: initialState });
          }
        } catch (error) {
          console.error("Failed to parse cart from localStorage. Resetting cart.", error);
          localStorage.removeItem('cart');
          dispatch({ type: 'LOAD_CART', payload: initialState });
        }
      } else {
         dispatch({ type: 'LOAD_CART', payload: initialState });
      }
    }
  }, []);


  const addItem = useCallback((product: Product, quantity = 1, selectedFragrance?: string, selectedColor?: string) => {
    dispatch({ type: 'ADD_ITEM', payload: { product, quantity, selectedFragrance, selectedColor } });
  }, []);

  const removeItem = useCallback((productId: string, selectedFragrance?: string, selectedColor?: string) => {
    dispatch({ type: 'REMOVE_ITEM', payload: { productId, selectedFragrance, selectedColor } });
  }, []);

  const updateItemQuantity = useCallback((productId: string, selectedFragrance: string | undefined, selectedColor: string | undefined, quantity: number) => {
    dispatch({ type: 'UPDATE_ITEM_QUANTITY', payload: { productId, selectedFragrance, selectedColor, quantity } });
  }, []);

  const clearCart = useCallback(() => {
    dispatch({ type: 'CLEAR_CART' });
  }, []);

  const toggleCart = useCallback(() => {
    dispatch({ type: 'TOGGLE_CART' });
  }, []);
  
  const getItemQuantity = useCallback((productId: string, selectedFragrance?: string, selectedColor?: string): number => {
    const item = state.items.find(i => i.id === productId && i.selectedFragrance === selectedFragrance && i.selectedColor === selectedColor);
    return item ? item.quantity : 0;
  }, [state.items]);


  const contextPayload = {
    ...state,
    addItem,
    removeItem,
    updateItemQuantity,
    clearCart,
    toggleCart,
    getItemQuantity,
  };
  
  // This component (ProviderComponent) is what createSafeContext returns as its first array element.
  // It is defined in createSafeContext to accept a prop named 'value'.
  return <ProviderComponent value={contextPayload}>{children}</ProviderComponent>;
};

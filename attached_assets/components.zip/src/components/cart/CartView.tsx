
"use client";

import Link from 'next/link';
import { useCart } from '@/hooks/useCart';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { CartItemCard } from './CartItemCard';
import { Separator } from '@/components/ui/separator';
import { ShoppingBag, Trash2 } from 'lucide-react';

export function CartView() {
  const { items, totalItems, totalPrice, clearCart } = useCart();

  if (items.length === 0) {
    return (
      <Card className="shadow-lg">
        <CardContent className="p-8 text-center">
          <ShoppingBag className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
          <h2 className="text-2xl font-semibold mb-2">Vaša košarica je prazna</h2>
          <p className="text-muted-foreground mb-6">Dodajte proizvode u košaricu kako biste ih vidjeli ovdje.</p>
          <Button asChild>
            <Link href="/products">Pregledajte proizvode</Link>
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid md:grid-cols-3 gap-8">
      <div className="md:col-span-2 space-y-6">
        {items.map((item) => (
          <CartItemCard key={item.id} item={item} />
        ))}
      </div>

      <div className="md:col-span-1">
        <Card className="shadow-lg sticky top-20">
          <CardHeader>
            <CardTitle>Sažetak košarice</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between">
              <span>Ukupno stavki:</span>
              <span>{totalItems}</span>
            </div>
            <div className="flex justify-between font-semibold text-lg">
              <span>Ukupna cijena:</span>
              <span>{totalPrice.toFixed(2)} €</span>
            </div>
            <Separator />
             <p className="text-xs text-muted-foreground">
              Troškovi dostave bit će izračunati na sljedećem koraku.
            </p>
          </CardContent>
          <CardFooter className="flex flex-col gap-3">
            <Button className="w-full" asChild size="lg">
              <Link href="/checkout">Nastavi na plaćanje</Link>
            </Button>
            <Button variant="outline" className="w-full" onClick={clearCart}>
              <Trash2 className="mr-2 h-4 w-4" /> Isprazni košaricu
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}

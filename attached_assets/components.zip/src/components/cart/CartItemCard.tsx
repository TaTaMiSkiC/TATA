
"use client";

import Image from 'next/image';
import Link from 'next/link';
import type { CartItem } from '@/hooks/useCart'; // Use CartItem from useCart
import { useCart } from '@/hooks/useCart';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Minus, Plus, X, Palette } from 'lucide-react'; // Added Palette

interface CartItemCardProps {
  item: CartItem;
}

export function CartItemCard({ item }: CartItemCardProps) {
  const { updateItemQuantity, removeItem } = useCart();

  const handleQuantityChange = (newQuantity: number) => {
    if (newQuantity < 1) {
      removeItem(item.id, item.selectedFragrance, item.selectedColor);
    } else {
      updateItemQuantity(item.id, item.selectedFragrance, item.selectedColor, newQuantity);
    }
  };

  return (
    <Card className="shadow-md overflow-hidden">
      <CardContent className="p-4 flex gap-4 items-start">
        <Link href={`/products/${item.id}`} className="flex-shrink-0">
          <Image
            src={item.imageUrl}
            alt={item.name}
            width={100}
            height={100}
            className="rounded-md object-cover aspect-square"
            data-ai-hint="svijeća košarica"
          />
        </Link>
        <div className="flex-grow">
          <div className="flex justify-between items-start">
            <div>
              <Link href={`/products/${item.id}`}>
                <h3 className="text-lg font-semibold hover:text-primary">{item.name}</h3>
              </Link>
              {item.selectedFragrance && (
                <p className="text-sm text-muted-foreground">Miris: {item.selectedFragrance}</p>
              )}
              {item.selectedColor && ( // Display selected color
                <p className="text-sm text-muted-foreground flex items-center">
                  <Palette className="mr-1 h-4 w-4" /> Boja: {item.selectedColor}
                </p>
              )}
              <p className="text-sm text-muted-foreground">Kategorija: {item.categorySlug}</p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="text-muted-foreground hover:text-destructive -mt-1 -mr-1"
              onClick={() => removeItem(item.id, item.selectedFragrance, item.selectedColor)}
              aria-label="Ukloni proizvod"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
          
          <div className="flex items-center justify-between mt-3">
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="icon"
                className="h-8 w-8"
                onClick={() => handleQuantityChange(item.quantity - 1)}
                disabled={item.quantity <= 1}
              >
                <Minus className="h-4 w-4" />
              </Button>
              <Input
                type="number"
                className="h-8 w-14 text-center"
                value={item.quantity}
                onChange={(e) => {
                  const val = parseInt(e.target.value, 10);
                  if (!isNaN(val) && val > 0) {
                    handleQuantityChange(val);
                  } else if (e.target.value === "") {
                    // Allow empty input for user to type
                  }
                }}
                onBlur={(e) => {
                    if (e.target.value === "") handleQuantityChange(1);
                }}
                min="1"
              />
              <Button
                variant="outline"
                size="icon"
                className="h-8 w-8"
                onClick={() => handleQuantityChange(item.quantity + 1)}
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-lg font-semibold text-primary">
              {(item.price * item.quantity).toFixed(2)} €
            </p>
          </div>
           <p className="text-xs text-muted-foreground text-right mt-1">
              ({item.price.toFixed(2)} € / kom)
            </p>
        </div>
      </CardContent>
    </Card>
  );
}

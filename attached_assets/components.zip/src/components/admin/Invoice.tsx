
"use client";

import type { Order, BankAccountConfig } from '@/lib/types';
import Image from 'next/image';

interface InvoiceProps {
  order: Order;
  companyDetails: {
    name: string;
    address: string;
    email: string;
    phone: string;
    logoUrl: string;
  };
  bankDetails?: BankAccountConfig;
  language: 'hr' | 'en' | 'de';
}

const translations = {
  hr: {
    invoiceTitle: "RAČUN",
    invoiceNumber: "Broj računa:",
    invoiceDate: "Datum računa:",
    customerInfoTitle: "Podaci o kupcu:",
    customerName: "Ime i prezime:",
    customerEmail: "Email:",
    shippingAddress: "Adresa za dostavu:",
    orderItemsTitle: "Stavke narudžbe:",
    productColumn: "Proizvod",
    quantityColumn: "Količina",
    pricePerItemColumn: "Cijena/kom",
    totalColumn: "Ukupno",
    fragranceLabel: "Miris:",
    colorLabel: "Boja:",
    subtotal: "Međuzbroj:",
    shipping: "Dostava:",
    freeShipping: "0.00 €", 
    grandTotal: "UKUPNO:",
    paymentInfoTitle: "Informacije o plaćanju:",
    paymentMethod: "Način plaćanja:",
    bankTransferDetails: "Podaci za uplatu:",
    bankName: "Naziv banke:",
    accountHolder: "Nositelj računa:",
    iban: "IBAN:",
    bicSwift: "BIC/SWIFT:",
    referenceNumber: "Poziv na broj:",
    paymentStatus: "Status plaćanja:",
    paid: "Plaćeno",
    pending: "U obradi", 
    thankYouMessage: "Hvala Vam na narudžbi!",
    invoiceFooterNote: "Ovo je automatski generirani račun i valjan je bez potpisa i pečata.",
    companyPhoneLabel: "Telefon:"
  },
  en: {
    invoiceTitle: "INVOICE",
    invoiceNumber: "Invoice No.:",
    invoiceDate: "Invoice Date:",
    customerInfoTitle: "Customer Details:",
    customerName: "Name:",
    customerEmail: "Email:",
    shippingAddress: "Shipping Address:",
    orderItemsTitle: "Order Items:",
    productColumn: "Product",
    quantityColumn: "Quantity",
    pricePerItemColumn: "Price/Item",
    totalColumn: "Total",
    fragranceLabel: "Fragrance:",
    colorLabel: "Color:",
    subtotal: "Subtotal:",
    shipping: "Shipping:",
    freeShipping: "0.00 €",
    grandTotal: "GRAND TOTAL:",
    paymentInfoTitle: "Payment Information:",
    paymentMethod: "Payment Method:",
    bankTransferDetails: "Bank Transfer Details:",
    bankName: "Bank Name:",
    accountHolder: "Account Holder:",
    iban: "IBAN:",
    bicSwift: "BIC/SWIFT:",
    referenceNumber: "Reference Number:",
    paymentStatus: "Payment Status:",
    paid: "Paid",
    pending: "Pending",
    thankYouMessage: "Thank you for your order!",
    invoiceFooterNote: "This is an automatically generated invoice and is valid without signature and seal.",
    companyPhoneLabel: "Phone:"
  },
  de: {
    invoiceTitle: "RECHNUNG",
    invoiceNumber: "Rechnungsnr.:",
    invoiceDate: "Rechnungsdatum:",
    customerInfoTitle: "Kundeninformationen:",
    customerName: "Name:",
    customerEmail: "Email:",
    shippingAddress: "Lieferadresse:",
    orderItemsTitle: "Bestellpositionen:",
    productColumn: "Produkt",
    quantityColumn: "Menge",
    pricePerItemColumn: "Preis/Stück",
    totalColumn: "Gesamt",
    fragranceLabel: "Duft:",
    colorLabel: "Farbe:",
    subtotal: "Zwischensumme:",
    shipping: "Versand:",
    freeShipping: "0.00 €",
    grandTotal: "GESAMT:",
    paymentInfoTitle: "Zahlungsinformationen:",
    paymentMethod: "Zahlungsmethode:",
    bankTransferDetails: "Bankverbindung:",
    bankName: "Bankname:",
    accountHolder: "Kontoinhaber:",
    iban: "IBAN:",
    bicSwift: "BIC/SWIFT:",
    referenceNumber: "Verwendungszweck:",
    paymentStatus: "Zahlungsstatus:",
    paid: "Bezahlt",
    pending: "Ausstehend",
    thankYouMessage: "Vielen Dank für Ihre Bestellung!",
    invoiceFooterNote: "Dies ist eine automatisch generierte Rechnung und ist ohne Unterschrift und Stempel gültig.",
    companyPhoneLabel: "Telefon:"
  }
};

const localeMap = {
  hr: 'hr-HR',
  en: 'en-US',
  de: 'de-DE',
};

export function Invoice({ order, companyDetails, bankDetails, language }: InvoiceProps) {
  const t = translations[language];
  const currentLocale = localeMap[language];

  return (
    <div className="bg-white text-gray-800 p-6 md:p-8 max-w-4xl mx-auto font-sans printable-content"> {/* Reduced padding */}
      {/* Header */}
      <header className="flex justify-between items-start mb-8"> {/* Reduced mb-12 to mb-8 */}
        <div className="flex items-center">
          <Image 
            src={companyDetails.logoUrl} 
            alt={`${companyDetails.name} Logo`} 
            width={80} // Reduced logo size
            height={80} 
            className="object-contain"
            data-ai-hint="company logo" 
            priority
          />
          <div className="ml-3"> {/* Reduced ml-4 to ml-3 */}
            <h1 className="text-2xl font-bold text-primary">{companyDetails.name}</h1> {/* Reduced text-3xl to text-2xl */}
            <p className="text-xs">{companyDetails.address}</p> {/* Reduced text-sm to text-xs */}
            <p className="text-xs">Email: {companyDetails.email}</p>
          </div>
        </div>
        <div className="text-right">
          <h2 className="text-xl font-semibold">{t.invoiceTitle}</h2> {/* Reduced text-2xl to text-xl */}
          <p className="text-sm">{t.invoiceNumber} <span className="font-medium">{order.id}</span></p>
          <p className="text-sm">{t.invoiceDate} <span className="font-medium">{new Date(order.orderDate).toLocaleDateString(currentLocale)}</span></p>
        </div>
      </header>

      {/* Customer Details */}
      <section className="mb-6"> {/* Reduced mb-10 to mb-6 */}
        <h3 className="text-md font-semibold border-b pb-1 mb-1 text-gray-700">{t.customerInfoTitle}</h3> {/* Reduced text-lg, pb-1, mb-2 */}
        <p className="text-sm"><span className="font-medium">{t.customerName}</span> {order.customerName}</p>
        <p className="text-sm"><span className="font-medium">{t.customerEmail}</span> {order.customerEmail}</p>
        <p className="text-sm"><span className="font-medium">{t.shippingAddress}</span> {order.shippingAddress}</p>
      </section>

      {/* Order Items Table */}
      <section className="mb-6"> {/* Reduced mb-10 to mb-6 */}
        <h3 className="text-md font-semibold border-b pb-1 mb-2 text-gray-700">{t.orderItemsTitle}</h3> {/* Reduced text-lg, mb-3 */}
        <table className="w-full text-left border-collapse text-sm"> {/* Added text-sm */}
          <thead>
            <tr className="bg-gray-100">
              <th className="border p-1.5">{t.productColumn}</th> {/* Reduced p-2 to p-1.5 */}
              <th className="border p-1.5 text-center">{t.quantityColumn}</th>
              <th className="border p-1.5 text-right">{t.pricePerItemColumn}</th>
              <th className="border p-1.5 text-right">{t.totalColumn}</th>
            </tr>
          </thead>
          <tbody>
            {order.items.map((item, index) => (
              <tr key={`${item.id}-${index}`} className="hover:bg-gray-50">
                <td className="border p-1.5">
                  {item.name}
                  {item.selectedFragrance && <span className="block text-xs text-gray-500">{t.fragranceLabel} {item.selectedFragrance}</span>}
                  {item.selectedColor && <span className="block text-xs text-gray-500">{t.colorLabel} {item.selectedColor}</span>}
                </td>
                <td className="border p-1.5 text-center">{item.quantity}</td>
                <td className="border p-1.5 text-right">{item.price.toFixed(2)} €</td>
                <td className="border p-1.5 text-right font-medium">{(item.price * item.quantity).toFixed(2)} €</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      {/* Totals */}
      <section className="flex justify-end mb-6"> {/* Reduced mb-10 to mb-6 */}
        <div className="w-full max-w-xs space-y-0.5 text-sm"> {/* Reduced space-y-1 */}
          <div className="flex justify-between">
            <span>{t.subtotal}</span>
            <span>{order.items.reduce((sum, item) => sum + item.price * item.quantity, 0).toFixed(2)} €</span>
          </div>
          <div className="flex justify-between">
            <span>{t.shipping}</span>
            <span>{t.freeShipping}</span>
          </div>
          <div className="flex justify-between text-md font-bold pt-1 border-t mt-1"> {/* Reduced text-lg, pt-2, mt-2 */}
            <span>{t.grandTotal}</span>
            <span className="text-primary">{order.totalAmount.toFixed(2)} €</span>
          </div>
        </div>
      </section>

      {/* Payment Information */}
      <section className="mb-6"> {/* Reduced mb-10 to mb-6 */}
        <h3 className="text-md font-semibold border-b pb-1 mb-1 text-gray-700">{t.paymentInfoTitle}</h3> {/* Reduced text-lg, mb-2 */}
        <p className="text-sm"><span className="font-medium">{t.paymentMethod}</span> {order.paymentMethod}</p>
        {order.paymentMethod === 'Bankovni Transfer' && bankDetails && ( 
          <div className="mt-1 p-2 border rounded-md bg-gray-50 text-xs"> {/* Reduced mt-2, p-3, text-sm */}
            <p className="font-medium mb-0.5">{t.bankTransferDetails}</p> {/* Reduced mb-1 */}
            <p>{t.bankName} {bankDetails.bankName}</p>
            <p>{t.accountHolder} {bankDetails.accountHolder}</p>
            <p>{t.iban} {bankDetails.iban}</p>
            {bankDetails.bic && <p>{t.bicSwift} {bankDetails.bic}</p>}
            <p className="mt-0.5">{t.referenceNumber} {order.id}</p> {/* Reduced mt-1 */}
          </div>
        )}
         <p className="text-sm"><span className="font-medium">{t.paymentStatus}</span> <span className={`font-semibold ${order.status === 'Plaćeno' || order.status === 'Paid' || order.status === 'Bezahlt' ? 'text-green-600' : 'text-orange-500'}`}>{language === 'hr' ? order.status : (order.status === 'Plaćeno' ? t.paid : t.pending)}</span></p>
      </section>

      {/* Footer */}
      <footer className="text-center text-xs text-gray-500 pt-4 border-t"> {/* Reduced pt-8 to pt-4 */}
        <p>{t.thankYouMessage}</p>
        <p>{companyDetails.name} | {companyDetails.address} | Email: {companyDetails.email} | {t.companyPhoneLabel} {companyDetails.phone}</p>
        <p className="mt-0.5">{t.invoiceFooterNote}</p> {/* Reduced mt-1 */}
      </footer>
    </div>
  );
}


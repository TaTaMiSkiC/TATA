
import { APP_NAME } from '@/lib/constants';
import Link from 'next/link';

export function SiteFooter() {
  return (
    <footer className="border-t">
      <div className="container py-8">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} {APP_NAME} by Dani. Sva prava pridržana. {/* Changed to Dani */}
          </p>
          <nav className="flex gap-4 mt-4 md:mt-0 flex-wrap justify-center">
            <Link href="/about" className="text-sm hover:text-primary">O nama</Link>
            <Link href="/payment-info" className="text-sm hover:text-primary">Informacije o plaćanju</Link>
            <Link href="/privacy" className="text-sm hover:text-primary">Pravila privatnosti</Link>
            <Link href="/fragrance-info" className="text-sm hover:text-primary">Informacije mirisa</Link>
          </nav>
        </div>
      </div>
    </footer>
  );
}



"use client";

import Link from 'next/link';
import { ShoppingCart, UserCircle, Search, Menu, Languages, Info, LogIn, UserPlus, ListOrderedIcon, ShieldCheck, LogOutIcon, Settings, User as UserIcon, Flame, Phone } from 'lucide-react'; // Added Flame icon and Phone
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { APP_NAME } from '@/lib/constants';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { ThemeToggle } from '@/components/ThemeToggle'; 
import { useAuth } from '@/hooks/useAuth';
import { useRouter } from 'next/navigation';
import { useCart } from '@/hooks/useCart'; 
import { useState } from 'react'; // Import useState for search query

// Dummy data for categories - replace with actual data fetching
const categories = [
  { name: 'Mirisne svijeće', slug: 'mirisne-svijece' },
  { name: 'Ukrasne svijeće', slug: 'ukrasne-svijece' },
  { name: 'Poklon setovi', slug: 'poklon-setovi' },
  { name: 'Pribor za svijeće', slug: 'pribor-za-svijece' },
];

const availableLanguages = [
  { code: 'de', name: 'Deutsch' },
  { code: 'en', name: 'English' },
  { code: 'hr', name: 'Hrvatski' },
  { code: 'it', name: 'Italiano' },
  { code: 'fr', name: 'Français' },
];

export function SiteHeader() {
  const auth = useAuth();
  const router = useRouter();
  const { totalItems } = useCart(); 
  const [searchQuery, setSearchQuery] = useState(''); // State for search query

  const handleLanguageChange = (langCode: string) => {
    // TODO: Implement actual language switching logic
    alert(`Language selected: ${langCode}. Implement i18n logic here.`);
    console.log(`Selected language: ${langCode}`);
  };

  const handleLogout = () => {
    auth.logout_DEV_ONLY();
    router.push('/'); // Redirect to homepage after logout
  };

  const handleSearchSubmit = () => {
    if (searchQuery.trim()) {
      router.push(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const handleSearchKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter') {
      handleSearchSubmit();
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center">
        <div className="mr-4 hidden md:flex">
          <Link href="/" className="mr-6 flex items-center space-x-1.5">
            <Flame className="h-7 w-7 text-primary" /> {/* Logo Icon */}
            <span className="font-bold text-xl text-primary">{APP_NAME}</span>
            <span className="text-xs text-muted-foreground font-normal">by Dani</span> {/* Changed to Dani */}
          </Link>
          <nav className="flex items-center space-x-6 text-sm font-medium">
            <Link
              href="/"
              className="transition-colors hover:text-foreground/80 text-foreground/60"
            >
              Početna
            </Link>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="transition-colors hover:text-foreground/80 text-foreground/60 px-0">
                  Kategorije
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start">
                {categories.map((category) => (
                  <DropdownMenuItem key={category.slug} asChild>
                    <Link href={`/category/${category.slug}`}>{category.name}</Link>
                  </DropdownMenuItem>
                ))}
                 <DropdownMenuSeparator />
                 <DropdownMenuItem asChild>
                    <Link href="/categories">Sve kategorije</Link>
                  </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Link
              href="/products" 
              className="transition-colors hover:text-foreground/80 text-foreground/60"
            >
              Svi proizvodi
            </Link>
             <Link
              href="/contact" 
              className="transition-colors hover:text-foreground/80 text-foreground/60 flex items-center"
            >
              <Phone className="mr-1 h-4 w-4" /> Kontakt
            </Link>
          </nav>
        </div>

        {/* Mobile Menu */}
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="md:hidden mr-2">
              <Menu className="h-6 w-6" />
              <span className="sr-only">Otvori izbornik</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-full max-w-xs sm:max-w-sm">
            <div className="px-4 py-6">
            <Link href="/" className="flex items-center space-x-1.5 mb-6">
              <Flame className="h-8 w-8 text-primary" /> {/* Logo Icon */}
              <span className="font-bold text-2xl text-primary">{APP_NAME}</span>
              <span className="text-sm text-muted-foreground font-normal">by Dani</span> {/* Changed to Dani */}
            </Link>
            <nav className="grid gap-4">
              <Link href="/" className="text-lg font-medium hover:text-primary">Početna</Link>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="text-lg font-medium hover:text-primary justify-start px-0 py-2 h-auto">Kategorije</Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  {categories.map((category) => (
                    <DropdownMenuItem key={category.slug} asChild>
                      <Link href={`/category/${category.slug}`}>{category.name}</Link>
                    </DropdownMenuItem>
                  ))}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/categories">Sve kategorije</Link>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
               <Link href="/products" className="text-lg font-medium hover:text-primary">Svi proizvodi</Link>
               <Link href="/contact" className="text-lg font-medium hover:text-primary flex items-center"><Phone className="mr-2 h-5 w-5" />Kontakt</Link> 
            </nav>
            </div>
          </SheetContent>
        </Sheet>
        <Link href="/" className="flex items-center space-x-1.5 md:hidden flex-1">
            <Flame className="h-7 w-7 text-primary" /> {/* Logo Icon */}
            <span className="font-bold text-xl text-primary">{APP_NAME}</span>
            <span className="text-xs text-muted-foreground font-normal">by Dani</span> {/* Changed to Dani */}
        </Link>


        <div className="flex flex-1 items-center justify-end space-x-1 sm:space-x-2">
          <div className="hidden sm:flex flex-1 max-w-xs items-center">
            <Input 
              type="search" 
              placeholder="Pretraži svijeće..." 
              className="h-9" 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={handleSearchKeyDown}
            />
            <Button variant="ghost" size="icon" className="ml-1" onClick={handleSearchSubmit}>
              <Search className="h-5 w-5" />
            </Button>
          </div>
          <Button variant="ghost" size="icon" asChild className="relative">
            <Link href="/cart">
              <ShoppingCart className="h-5 w-5" />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-xs font-bold text-white">
                  {totalItems}
                </span>
              )}
              <span className="sr-only">Košarica</span>
            </Link>
          </Button>
          <ThemeToggle /> 
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <Languages className="h-5 w-5" />
                <span className="sr-only">Odaberite jezik</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Jezik</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {availableLanguages.map((lang) => (
                <DropdownMenuItem key={lang.code} onSelect={() => handleLanguageChange(lang.code)}>
                  {lang.name}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <UserCircle className="h-5 w-5" />
                <span className="sr-only">Korisnički račun</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Moj račun</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {!auth.isLoggedIn && (
                <>
                  <DropdownMenuItem asChild>
                    <Link href="/login"><LogIn className="mr-2 h-4 w-4" />Prijava</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/register"><UserPlus className="mr-2 h-4 w-4" />Registracija</Link>
                  </DropdownMenuItem>
                </>
              )}
              {auth.isLoggedIn && (
                <>
                  <DropdownMenuItem asChild>
                    <Link href="/account"><UserIcon className="mr-2 h-4 w-4" />Moj profil</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/account?tab=orders"><ListOrderedIcon className="mr-2 h-4 w-4" />Moje narudžbe</Link>
                  </DropdownMenuItem>
                   <DropdownMenuItem asChild>
                    <Link href="/account?tab=settings"><Settings className="mr-2 h-4 w-4" />Postavke računa</Link>
                  </DropdownMenuItem>
                  {(auth.isAdmin || auth.isModerator) && (
                    <DropdownMenuItem asChild>
                      <Link href="/admin/dashboard"><ShieldCheck className="mr-2 h-4 w-4" />Admin Panel</Link>
                    </DropdownMenuItem>
                  )}
                   <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOutIcon className="mr-2 h-4 w-4" />Odjava
                  </DropdownMenuItem>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}


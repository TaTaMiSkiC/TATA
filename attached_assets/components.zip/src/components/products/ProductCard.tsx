
"use client"; 

import Image from 'next/image';
import Link from 'next/link';
import type { Product } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { ShoppingCart, Plus, Minus, Search, Palette } from 'lucide-react'; // Added Palette
import { useCart } from '@/hooks/useCart'; 
import { useToast } from '@/hooks/use-toast'; 

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const { addItem, updateItemQuantity, getItemQuantity } = useCart();
  const { toast } = useToast();

  // Quantity in cart refers to base product without specific fragrance/color
  const quantityInCart = getItemQuantity(product.id, undefined, undefined); 

  const handleAddToCartDefault = () => {
    // Only for products with NO selectable fragrances AND NO selectable colors
    addItem(product, 1); 
    toast({
      title: "Proizvod dodan u košaricu",
      description: `${product.name} je dodan u vašu košaricu.`,
    });
  };

  const handleIncreaseQuantity = () => {
    if (quantityInCart < product.stock) {
      updateItemQuantity(product.id, undefined, undefined, quantityInCart + 1);
    } else {
      toast({
        title: "Maksimalna količina dosegnuta",
        description: `Ne možete dodati više od ${product.stock} komada ovog proizvoda.`,
        variant: "default" 
      });
    }
  };

  const handleDecreaseQuantity = () => {
    updateItemQuantity(product.id, undefined, undefined, quantityInCart - 1); 
  };

  const hasFragrances = product.fragrances && product.fragrances.length > 0;
  const hasColors = product.hasSelectableColors && product.colorSelections && product.colorSelections.length > 0;

  const needsSelection = hasFragrances || hasColors;

  return (
    <Card className="overflow-hidden flex flex-col h-full shadow-lg hover:shadow-xl transition-shadow duration-300">
      <Link href={`/products/${product.id}`} className="block">
        <CardHeader className="p-0">
          <div className="aspect-[4/3] relative w-full">
            <Image
              src={product.imageUrl}
              alt={product.name}
              fill
              sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
              className="object-cover group-hover:scale-105 transition-transform duration-300"
              data-ai-hint="svijeća slika"
            />
          </div>
        </CardHeader>
      </Link>
      <CardContent className="p-4 flex-grow">
        <Link href={`/products/${product.id}`} className="block">
          <CardTitle className="text-lg font-semibold hover:text-primary transition-colors">
            {product.name}
          </CardTitle>
        </Link>
        <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{product.description}</p>
      </CardContent>
      <CardFooter className="p-4 flex justify-between items-center">
        <p className="text-xl font-bold text-primary">
          {product.price.toFixed(2)} €
        </p>
        {product.stock === 0 ? (
          <Button size="sm" variant="outline" disabled>
            <ShoppingCart className="mr-2 h-4 w-4" />
            Nema na zalihi
          </Button>
        ) : needsSelection ? ( // If fragrances OR colors need selection, go to details
          <Button size="sm" variant="outline" asChild>
            <Link href={`/products/${product.id}`}>
              <Search className="mr-2 h-4 w-4" />
              Detalji i odabir
            </Link>
          </Button>
        ) : quantityInCart === 0 ? ( // No selections needed, can add directly
          <Button 
            size="sm" 
            variant="outline" 
            onClick={handleAddToCartDefault}
          >
            <ShoppingCart className="mr-2 h-4 w-4" />
            Dodaj u košaricu
          </Button>
        ) : ( // No selections needed, already in cart, show quantity controls
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="icon"
              className="h-8 w-8"
              onClick={handleDecreaseQuantity}
              aria-label="Smanji količinu"
            >
              <Minus className="h-4 w-4" />
            </Button>
            <span className="text-sm font-medium w-8 text-center" aria-live="polite" aria-label={`Količina: ${quantityInCart}`}>
              {quantityInCart}
            </span>
            <Button
              variant="outline"
              size="icon"
              className="h-8 w-8"
              onClick={handleIncreaseQuantity}
              disabled={quantityInCart >= product.stock}
              aria-label="Povećaj količinu"
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        )}
      </CardFooter>
    </Card>
  );
}

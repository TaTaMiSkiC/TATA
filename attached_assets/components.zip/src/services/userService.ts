

import type { User } from '@/lib/types';

// Dummy user data
let dummyUsers: User[] = [
  { 
    id: '1', 
    name: 'Pero Perić', 
    email: 'pero.peric@example.com', 
    password: 'password123',
    role: 'admin',
    address: 'Adminova ulica 1, 10000 Zagreb',
    phone: '0991234567',
    bankAccountNumber: 'HR1234567890123456789'
  },
  { 
    id: '2', 
    name: 'Ana Anić', 
    email: 'ana.anic@example.com', 
    password: 'password123',
    role: 'moderator',
    address: 'Moderatorski put 2, 21000 Split',
    phone: '0987654321'
  },
  { 
    id: '3', 
    name: 'Ivo Ivić', 
    email: 'ivo.ivic@example.com', 
    password: 'password123',
    role: 'korisnik',
    address: 'Korisnička cesta 3, 51000 Rijeka',
    phone: '0912345678',
    bankAccountNumber: 'HR0987654321098765432' 
  },
  { 
    id: '4', 
    name: 'Mara Marić', 
    email: 'mara.maric@example.com', 
    password: 'password123',
    role: 'korisnik',
    address: 'Primorska ulica 4, 31000 Osijek',
    phone: '0955555555'
  },
  { 
    id: '5', 
    name: 'Marija Miškić', 
    email: 'v.miskic2@gmail.com', 
    password: 'Marija24', // As per user request
    role: 'admin',
    address: 'Velika Gorica 123, 10410 Velika Gorica',
    phone: '0911122333',
    bankAccountNumber: 'HR2222222222222222222'
  },
   { 
    id: '6', 
    name: 'Admin User', 
    email: 'admin@example.com', 
    password: 'adminpassword',
    role: 'admin',
    address: 'Admin Main St 1, Admin City',
    phone: '0910000000'
  },
  { 
    id: '7', 
    name: 'Moderator User', 
    email: 'moderator@example.com', 
    password: 'moderatorpassword',
    role: 'moderator',
    address: 'Moderat St 2, Mod City',
    phone: '0920000000'
  },
];

export async function getAllUsers(): Promise<User[]> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 300));
  return [...dummyUsers]; // Return a copy
}

export async function getUserById(id: string): Promise<User | undefined> {
  await new Promise(resolve => setTimeout(resolve, 100));
  const user = dummyUsers.find(user => user.id === id);
  if (user) return {...user}; // Return a copy
  return undefined;
}

export async function getUserByEmail(email: string): Promise<User | undefined> {
  await new Promise(resolve => setTimeout(resolve, 100));
  const user = dummyUsers.find(user => user.email.toLowerCase() === email.toLowerCase());
  if (user) return {...user}; // Return a copy
  return undefined;
}

export async function updateUserRole(userId: string, newRole: User['role']): Promise<User | undefined> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  const userIndex = dummyUsers.findIndex(user => user.id === userId);
  if (userIndex !== -1) {
    dummyUsers[userIndex].role = newRole;
    return { ...dummyUsers[userIndex] }; // Return a copy
  }
  return undefined;
}

export async function addUser(user: Omit<User, 'id'>): Promise<User> {
  await new Promise(resolve => setTimeout(resolve, 500));
  if (!user.password) {
    // In a real app, throw an error or handle password generation if not provided.
    // For this mock, we'll assign a default if missing, though registration should ensure it's set.
    console.warn(`Korisniku ${user.email} nije dodijeljena lozinka prilikom kreiranja. Postavljena na 'defaultpassword'.`);
    user.password = 'defaultpassword';
  }
  const newUser = { ...user, id: String(Date.now()) }; // Dummy ID generation
  dummyUsers.push(newUser);
  return { ...newUser };
}

export async function updateUser(userId: string, updates: Partial<User>): Promise<User | undefined> {
  await new Promise(resolve => setTimeout(resolve, 300));
  const userIndex = dummyUsers.findIndex(user => user.id === userId);
  if (userIndex > -1) {
    dummyUsers[userIndex] = { ...dummyUsers[userIndex], ...updates };
    return { ...dummyUsers[userIndex] };
  }
  return undefined;
}

// Placeholder for password update - in a real app, this would involve hashing
export async function updateUserPassword(userId: string, newPassword: string): Promise<boolean> {
  await new Promise(resolve => setTimeout(resolve, 300));
  const userIndex = dummyUsers.findIndex(user => user.id === userId);
  if (userIndex > -1) {
    dummyUsers[userIndex].password = newPassword; // In real app, hash this
    return true;
  }
  return false;
}

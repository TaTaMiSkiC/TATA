
import type { Order, CartItem as LibCartItem, Product } from '@/lib/types'; // Using CartItem from lib/types
import type { CartItem as HookCartItem } from '@/hooks/useCart'; // CartItem from useCart hook

// Re-use some products from productService for consistency in CartItems
const dummyProductsForOrders: Product[] = [
  { id: '1', name: 'Mirisna svijeća Lavanda Deluxe', description: 'Opuštajuća svijeća s prirodnim eteričnim uljem lavande. Ručno izrađena.', price: 15.99, imageUrl: 'https://picsum.photos/seed/lavanda-svijeca/400/300', categorySlug: 'mirisne-svijece', stock: 20, fragrances: ['Lavanda Classic', 'Lavanda & Vanilija'], hasSelectableColors: true, colorSelections:['Lila'] },
  { id: '2', name: 'Ukrasna svijeća Pčelinji Saće', description: 'Elegantna svijeća od čistog pčelinjeg voska u obliku saća.', price: 22.50, imageUrl: 'https://picsum.photos/seed/sace-svijeca/400/300', categorySlug: 'ukrasne-svijece', stock: 15 },
  { id: '3', name: 'Poklon set svijeća Citrusni Mix', description: 'Osvježavajući set od tri manje svijeće s mirisima limuna, naranče i grejpa.', price: 35.00, imageUrl: 'https://picsum.photos/seed/citrus-set/400/300', categorySlug: 'poklon-setovi', stock: 10, fragrances: ['Limun', 'Naranča', 'Grejp'], hasSelectableColors: true, colorSelections: ['Žuta', 'Zelena'] },
  { id: '4', name: 'Svijeća Vanilija Bourbon', description: 'Topla i ugodna mirisna svijeća s bogatom aromom vanilije.', price: 18.00, imageUrl: 'https://picsum.photos/seed/vanilija-svijeca/400/300', categorySlug: 'mirisne-svijece', stock: 25, fragrances: ['Vanilija Bourbon', 'Vanilija & Cimet'] , hasSelectableColors: true, colorSelections: ['Bijela']},
];

let currentOrderIdNumber = 503; // Start from 503 so next new order is i504

const dummyOrders: Order[] = [
  {
    id: 'i500', // Updated ID
    userId: 'cust1', 
    customerName: 'Pero Perić',
    customerEmail: 'pero.peric@example.com',
    items: [
      { ...dummyProductsForOrders[0], quantity: 2, selectedFragrance: 'Lavanda Classic', selectedColor: 'Lila' } as LibCartItem,
      { ...dummyProductsForOrders[1], quantity: 1 } as LibCartItem, 
    ],
    totalAmount: (15.99 * 2) + 22.50,
    status: 'Plaćeno',
    orderDate: '2024-05-20T10:30:00Z',
    shippingAddress: 'Ilica 1, 10000 Zagreb, Hrvatska',
    paymentMethod: 'PayPal',
    notes: 'Molim brzu dostavu.'
  },
  {
    id: 'i501', // Updated ID
    userId: 'cust2', 
    customerName: 'Ana Anić',
    customerEmail: 'ana.anic@example.com',
    items: [
      { ...dummyProductsForOrders[3], quantity: 1, selectedFragrance: 'Vanilija & Cimet', selectedColor: 'Bijela' } as LibCartItem,
    ],
    totalAmount: 18.00,
    status: 'Poslano',
    orderDate: '2024-05-18T14:00:00Z',
    shippingAddress: 'Vukovarska 58, 21000 Split, Hrvatska',
    paymentMethod: 'Bankovni Transfer',
  },
  {
    id: 'i502', // Updated ID
    userId: 'cust3', 
    customerName: 'Ivo Ivić',
    customerEmail: 'ivo.ivic@example.com',
    items: [
      { ...dummyProductsForOrders[2], quantity: 1, selectedFragrance: 'Limun', selectedColor: 'Žuta' } as LibCartItem,
      { ...dummyProductsForOrders[0], quantity: 1, selectedFragrance: 'Lavanda & Vanilija', selectedColor: 'Lila'} as LibCartItem,
    ],
    totalAmount: 35.00 + 15.99,
    status: 'U obradi',
    orderDate: '2024-05-21T09:15:00Z',
    shippingAddress: 'Trg Bana Jelačića 15, 10000 Zagreb, Hrvatska',
    paymentMethod: 'Pouzeće',
  },
  {
    id: 'i503', // Updated ID
    userId: 'cust1', 
    customerName: 'Pero Perić',
    customerEmail: 'pero.peric@example.com',
    items: [
      { ...dummyProductsForOrders[1], quantity: 3 } as LibCartItem, 
    ],
    totalAmount: 22.50 * 3,
    status: 'Dostavljeno',
    orderDate: '2024-04-15T11:00:00Z',
    shippingAddress: 'Ilica 1, 10000 Zagreb, Hrvatska',
    paymentMethod: 'PayPal',
  },
];

export async function getAllOrders(): Promise<Order[]> {
  await new Promise(resolve => setTimeout(resolve, 500));
  return dummyOrders.map(o => ({...o, items: o.items.map(i => ({...i}))}));
}

export async function getOrderById(id: string): Promise<Order | undefined> {
  await new Promise(resolve => setTimeout(resolve, 300));
  const order = dummyOrders.find(order => order.id === id);
  return order ? {...order, items: order.items.map(i => ({...i}))} : undefined;
}

export async function getOrdersByUserId(userId: string): Promise<Order[]> {
  await new Promise(resolve => setTimeout(resolve, 300));
  return dummyOrders.filter(order => order.userId === userId).map(o => ({...o, items: o.items.map(i => ({...i}))}));
}


export async function updateOrderStatus(orderId: string, newStatus: Order['status']): Promise<Order | undefined> {
  await new Promise(resolve => setTimeout(resolve, 400));
  const orderIndex = dummyOrders.findIndex(order => order.id === orderId);
  if (orderIndex !== -1) {
    dummyOrders[orderIndex].status = newStatus;
    const order = dummyOrders[orderIndex];
    return {...order, items: order.items.map(i => ({...i}))};
  }
  return undefined;
}


interface CreateOrderData {
  userId: string;
  customerName: string;
  customerEmail: string;
  items: HookCartItem[]; // Items from useCart hook
  totalAmount: number;
  shippingAddress: string;
  paymentMethod: string;
  notes?: string;
}

export async function createOrder(orderData: CreateOrderData): Promise<Order> {
  await new Promise(resolve => setTimeout(resolve, 600)); 
  
  // Map HookCartItem to LibCartItem for storing in the order
  const orderItems: LibCartItem[] = orderData.items.map(item => ({
    id: item.id, // This is productId
    name: item.name,
    price: item.price,
    imageUrl: item.imageUrl,
    categorySlug: item.categorySlug,
    quantity: item.quantity,
    selectedFragrance: item.selectedFragrance,
    selectedColor: item.selectedColor, // Include selectedColor
    // Product specific fields that are part of CartItemTypeFromLib via Product
    stock: item.stock,
    description: item.description,
    fragrances: item.fragrances,
    hasSelectableColors: item.hasSelectableColors,
    colorSelections: item.colorSelections,
  }));

  const newOrder: Order = {
    id: `i${++currentOrderIdNumber}`, // Updated ID generation
    userId: orderData.userId,
    customerName: orderData.customerName,
    customerEmail: orderData.customerEmail,
    items: orderItems,
    totalAmount: orderData.totalAmount,
    status: 'U obradi', 
    orderDate: new Date().toISOString(),
    shippingAddress: orderData.shippingAddress,
    paymentMethod: orderData.paymentMethod,
    notes: orderData.notes,
  };

  dummyOrders.push(newOrder);
  console.log("Nova narudžba kreirana:", newOrder);
  return {...newOrder, items: newOrder.items.map(i => ({...i}))};
}


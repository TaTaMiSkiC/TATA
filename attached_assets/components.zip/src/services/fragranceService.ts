
import type { Fragrance } from '@/lib/types';

let dummyFragrances: Fragrance[] = [
  { id: 'f1', name: 'Vanilija', description: 'Slatki i topli miris vanilije.' },
  { id: 'f2', name: 'Lavanda', description: 'Opuštajući i umirujući miris lavande.' },
  { id: 'f3', name: 'Citrus', description: 'Osvježavajući miris limuna, naranče i grejpa.' },
  { id: 'f4', name: 'Ruža', description: 'Klasičan i romantičan miris ruže.' },
  { id: 'f5', name: 'Sandalovina', description: 'Drvenast i egzotičan miris sandalovine.' },
  { id: 'f6', name: 'Cimet', description: 'Topao i začinski miris cimeta, idealan za zimu.' },
  { id: 'f7', name: 'Eukaliptus', description: 'Osvježavajući i pročišćavajući miris eukaliptusa.' },
];

export async function getAllFragrances(): Promise<Fragrance[]> {
  await new Promise(resolve => setTimeout(resolve, 200));
  return [...dummyFragrances.map(f => ({ ...f }))];
}

export async function getFragranceById(id: string): Promise<Fragrance | undefined> {
  await new Promise(resolve => setTimeout(resolve, 100));
  const fragrance = dummyFragrances.find(f => f.id === id);
  return fragrance ? { ...fragrance } : undefined;
}

export async function addFragrance(fragranceData: Omit<Fragrance, 'id'>): Promise<Fragrance> {
  await new Promise(resolve => setTimeout(resolve, 300));
  const newFragrance: Fragrance = {
    ...fragranceData,
    id: `f${Date.now()}`,
  };
  dummyFragrances.push(newFragrance);
  return { ...newFragrance };
}

export async function updateFragrance(fragranceId: string, updates: Partial<Omit<Fragrance, 'id'>>): Promise<Fragrance | undefined> {
  await new Promise(resolve => setTimeout(resolve, 300));
  const index = dummyFragrances.findIndex(f => f.id === fragranceId);
  if (index !== -1) {
    dummyFragrances[index] = { ...dummyFragrances[index], ...updates };
    return { ...dummyFragrances[index] };
  }
  return undefined;
}

export async function deleteFragrance(fragranceId: string): Promise<boolean> {
  await new Promise(resolve => setTimeout(resolve, 300));
  const initialLength = dummyFragrances.length;
  dummyFragrances = dummyFragrances.filter(f => f.id !== fragranceId);
  return dummyFragrances.length < initialLength;
}

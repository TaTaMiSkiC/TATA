
import type { ColorOption } from '@/lib/types';

let dummyColors: ColorOption[] = [
  { id: 'c1', name: 'Bijela', hexCode: '#FFFFFF', description: 'Klasična bijela boja.' },
  { id: 'c2', name: 'Crvena', hexCode: '#FF0000', description: 'Jarka crvena boja.' },
  { id: 'c3', name: 'Plava', hexCode: '#0000FF', description: 'Duboka plava boja.' },
  { id: 'c4', name: 'Zelena', hexCode: '#008000', description: 'Prirodna zelena boja.' },
  { id: 'c5', name: 'Žuta', hexCode: '#FFFF00', description: 'Svijetla žuta boja.' },
  { id: 'c6', name: 'Lila', hexCode: '#C8A2C8', description: 'Nježna lila boja.' },
  { id: 'c7', name: 'Roza', hexCode: '#FFC0CB', description: 'Svijetlo roza boja.' },
];

export async function getAllColors(): Promise<ColorOption[]> {
  await new Promise(resolve => setTimeout(resolve, 200));
  return [...dummyColors.map(c => ({ ...c }))];
}

export async function getColorById(id: string): Promise<ColorOption | undefined> {
  await new Promise(resolve => setTimeout(resolve, 100));
  const color = dummyColors.find(c => c.id === id);
  return color ? { ...color } : undefined;
}

export async function addColor(colorData: Omit<ColorOption, 'id'>): Promise<ColorOption> {
  await new Promise(resolve => setTimeout(resolve, 300));
  const newColor: ColorOption = {
    ...colorData,
    id: `c${Date.now()}`,
  };
  dummyColors.push(newColor);
  return { ...newColor };
}

export async function updateColor(colorId: string, updates: Partial<Omit<ColorOption, 'id'>>): Promise<ColorOption | undefined> {
  await new Promise(resolve => setTimeout(resolve, 300));
  const index = dummyColors.findIndex(c => c.id === colorId);
  if (index !== -1) {
    dummyColors[index] = { ...dummyColors[index], ...updates };
    return { ...dummyColors[index] };
  }
  return undefined;
}

export async function deleteColor(colorId: string): Promise<boolean> {
  await new Promise(resolve => setTimeout(resolve, 300));
  const initialLength = dummyColors.length;
  dummyColors = dummyColors.filter(c => c.id !== colorId);
  return dummyColors.length < initialLength;
}

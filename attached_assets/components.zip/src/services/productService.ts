

import type { Product, Category } from '@/lib/types';

// Dummy data - prevedeno na hrvatski i tematski prilagođeno svijećama
let dummyProducts: Product[] = [
  { 
    id: '1', 
    name: 'Mirisna svijeća Lavanda Deluxe', 
    description: 'Opuštajuća svijeća s prirodnim eteričnim uljem lavande. Ručno izrađena.', 
    price: 15.99, 
    imageUrl: 'https://picsum.photos/seed/lavanda-svijeca/400/300', 
    categorySlug: 'mirisne-svijece', 
    stock: 20, 
    fragrances: ['Lavanda Classic', 'Lavanda & Vanilija'], 
    hasSelectableColors: true, 
    colorSelections: ['Bijela', 'Lila'] 
  },
  { 
    id: '2', 
    name: 'Ukrasna svijeća Pčelinji Saće', 
    description: 'Elegantna svijeća od čistog pčelinjeg voska u obliku saća.', 
    price: 22.50, 
    imageUrl: 'https://picsum.photos/seed/sace-svijeca/400/300', 
    categorySlug: 'ukrasne-svijece', 
    stock: 15,
    hasSelectableColors: false, // Example: This candle has a fixed color
  },
  { 
    id: '3', 
    name: 'Poklon set svijeća Citrusni Mix', 
    description: 'Osvježavajući set od tri manje svijeće s mirisima limuna, naranče i grejpa.', 
    price: 35.00, 
    imageUrl: 'https://picsum.photos/seed/citrus-set/400/300', 
    categorySlug: 'poklon-setovi', 
    stock: 10, 
    fragrances: ['Limun', 'Naranča', 'Grejp'],
    hasSelectableColors: true,
    colorSelections: ['Žuta', 'Zelena', 'Bijela']
  },
  { 
    id: '4', 
    name: 'Svijeća Vanilija Bourbon', 
    description: 'Topla i ugodna mirisna svijeća s bogatom aromom vanilije.', 
    price: 18.00, 
    imageUrl: 'https://picsum.photos/seed/vanilija-svijeca/400/300', 
    categorySlug: 'mirisne-svijece', 
    stock: 25, 
    fragrances: ['Vanilija Bourbon', 'Vanilija & Cimet'],
    hasSelectableColors: true,
    colorSelections: ['Bijela', 'Žuta']
  },
  { 
    id: '5', 
    name: 'Stupna svijeća Boja Bjelokosti', 
    description: 'Klasična stupna svijeća, idealna za dekoraciju ili kao središnji dio stola.', 
    price: 12.99, 
    imageUrl: 'https://picsum.photos/seed/stupna-svijeca/400/300', 
    categorySlug: 'ukrasne-svijece', 
    stock: 30,
    hasSelectableColors: false, // Fixed color
  },
  { 
    id: '6', 
    name: 'Set lučica Sandalovina', 
    description: 'Pakiranje od 12 lučica s umirujućim mirisom sandalovine.', 
    price: 9.50, 
    imageUrl: 'https://picsum.photos/seed/lucice-sandalovina/400/300', 
    categorySlug: 'mirisne-svijece', 
    stock: 50,
    hasSelectableColors: false, // Lučice usually don't have color options or are standard
  },
  { 
    id: '7', 
    name: 'Svijeća Eukaliptus i Metvica', 
    description: 'Osvježavajuća i pročišćavajuća mirisna svijeća za vaš dom.', 
    price: 17.50, 
    imageUrl: 'https://picsum.photos/seed/eukaliptus-svijeca/400/300', 
    categorySlug: 'mirisne-svijece', 
    stock: 18, 
    fragrances: ['Eukaliptus Fresh', 'Eukaliptus & Nana'],
    hasSelectableColors: true,
    colorSelections: ['Bijela', 'Zelena', 'Plava']
  },
  { 
    id: '8', 
    name: 'Personalizirana svijeća s porukom', 
    description: 'Unikatna svijeća s mogućnošću personalizacije teksta ili slike.', 
    price: 28.00, 
    imageUrl: 'https://picsum.photos/seed/personalizirana-svijeca/400/300', 
    categorySlug: 'poklon-setovi', 
    stock: 7,
    hasSelectableColors: true, // Personalization might include color choice
    colorSelections: ['Bijela', 'Roza', 'Plava', 'Lila']
  },
];

const dummyCategories: Category[] = [
  { id: '1', name: 'Mirisne svijeće', slug: 'mirisne-svijece', description: 'Svijeće s bogatim aromama za svaki ugođaj.' },
  { id: '2', name: 'Ukrasne svijeće', slug: 'ukrasne-svijece', description: 'Elegantne svijeće koje uljepšavaju prostor.' },
  { id: '3', name: 'Poklon setovi', slug: 'poklon-setovi', description: 'Savršeni pokloni za ljubitelje svijeća.' },
  { id: '4', name: 'Pribor za svijeće', slug: 'pribor-za-svijece', description: 'Trimeri za fitilj, gasila i podmetači.' },
];

export async function getAllProducts(): Promise<Product[]> {
  // Simuliraj kašnjenje API-ja
  await new Promise(resolve => setTimeout(resolve, 500));
  return dummyProducts.map(p => ({...p}));
}

export async function getProductById(id: string): Promise<Product | undefined> {
  await new Promise(resolve => setTimeout(resolve, 300));
  const product = dummyProducts.find(p => p.id === id);
  return product ? {...product} : undefined;
}

export async function getProductsByCategory(categorySlug: string): Promise<Product[]> {
  await new Promise(resolve => setTimeout(resolve, 400));
  return dummyProducts.filter(p => p.categorySlug === categorySlug).map(p => ({...p}));
}

export async function getAllCategories(): Promise<Category[]> {
  await new Promise(resolve => setTimeout(resolve, 200));
  return dummyCategories.map(c => ({...c}));
}

export async function getCategoryBySlug(slug: string): Promise<Category | undefined> {
  await new Promise(resolve => setTimeout(resolve, 100));
  const category = dummyCategories.find(c => c.slug === slug);
  return category ? {...category} : undefined;
}

export async function addProduct(productData: Omit<Product, 'id'>): Promise<Product> {
  console.log('Admin: Dodavanje proizvoda', productData);
  await new Promise(resolve => setTimeout(resolve, 500));
  
  const newProduct: Product = { 
    ...productData, 
    id: String(Date.now()), 
    fragrances: productData.fragrances && productData.fragrances.length > 0 ? productData.fragrances : undefined,
    colorSelections: productData.colorSelections && productData.colorSelections.length > 0 ? productData.colorSelections : undefined,
    // hasSelectableColors is already part of productData
  };
  dummyProducts.push(newProduct);
  return {...newProduct};
}

export async function updateProduct(productId: string, updates: Partial<Omit<Product, 'id'>>): Promise<Product | undefined> {
  console.log('Admin: Ažuriranje proizvoda', productId, updates);
  await new Promise(resolve => setTimeout(resolve, 500));
  const productIndex = dummyProducts.findIndex(p => p.id === productId);
  if (productIndex > -1) {
    const existingProduct = dummyProducts[productIndex];
    
    dummyProducts[productIndex] = { 
      ...existingProduct, 
      ...updates,
      fragrances: updates.hasOwnProperty('fragrances') ? (updates.fragrances && updates.fragrances.length > 0 ? updates.fragrances : undefined) : existingProduct.fragrances,
      colorSelections: updates.hasOwnProperty('colorSelections') ? (updates.colorSelections && updates.colorSelections.length > 0 ? updates.colorSelections : undefined) : existingProduct.colorSelections,
      // hasSelectableColors updates directly from 'updates' if present
    };
    return {...dummyProducts[productIndex]};
  }
  return undefined;
}

export async function deleteProduct(productId: string): Promise<boolean> {
  console.log('Admin: Brisanje proizvoda', productId);
  await new Promise(resolve => setTimeout(resolve, 500));
  const initialLength = dummyProducts.length;
  const index = dummyProducts.findIndex(p => p.id === productId);
  if (index !== -1) {
    dummyProducts.splice(index, 1);
    return true;
  }
  return false;
}


export async function addCategory(category: Omit<Category, 'id' | 'slug'>): Promise<Category> {
  console.log('Admin: Dodavanje kategorije', category);
  await new Promise(resolve => setTimeout(resolve, 500));
  const newCategory: Category = { 
    ...category, 
    id: String(Date.now()), 
    slug: category.name.toLowerCase().replace(/\s+/g, '-').replace(/[čćđšž]/g, c => ({'č':'c','ć':'c','đ':'d','š':'s','ž':'z'}[c] || c)) 
  };
  dummyCategories.push(newCategory);
  return {...newCategory};
}

export async function updateCategory(categoryId: string, updates: Partial<Category>): Promise<Category | undefined> {
  console.log('Admin: Ažuriranje kategorije', categoryId, updates);
  await new Promise(resolve => setTimeout(resolve, 500));
  const categoryIndex = dummyCategories.findIndex(c => c.id === categoryId);
  if (categoryIndex > -1) {
    dummyCategories[categoryIndex] = { ...dummyCategories[categoryIndex], ...updates };
    if (updates.name && !updates.slug) { 
      dummyCategories[categoryIndex].slug = updates.name.toLowerCase().replace(/\s+/g, '-').replace(/[čćđšž]/g, c => ({'č':'c','ć':'c','đ':'d','š':'s','ž':'z'}[c] || c));
    }
    return {...dummyCategories[categoryIndex]};
  }
  return undefined;
}

export async function deleteCategory(categoryId: string): Promise<boolean> {
  console.log('Admin: Brisanje kategorije', categoryId);
  await new Promise(resolve => setTimeout(resolve, 500));
  const index = dummyCategories.findIndex(c => c.id === categoryId);
  if (index !== -1) {
    const categorySlug = dummyCategories[index].slug;
    dummyProducts.forEach(product => {
      if (product.categorySlug === categorySlug) {
        console.warn(`Proizvod ${product.id} bio je u obrisanoj kategoriji ${categorySlug}. Razmislite o premještanju.`);
      }
    });
    dummyCategories.splice(index, 1);
    return true;
  }
  return false;
}

export async function getCategoryById(id: string): Promise<Category | undefined> {
  await new Promise(resolve => setTimeout(resolve, 100));
  const category = dummyCategories.find(c => c.id === id);
  return category ? {...category} : undefined;
}

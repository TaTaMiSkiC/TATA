

import type { Customer } from '@/lib/types';

// Dummy customer data - na hrvatskom
let dummyCustomers: Customer[] = [ // Changed to let to allow modification
  { 
    id: 'cust1', 
    userId: '1', 
    name: 'Pero Perić', 
    email: 'pero.peric@example.com', 
    totalOrders: 3, 
    totalSpent: 125.50, 
    lastOrderDate: '2024-05-10',
    address: 'Adminova ulica 1, 10000 Zagreb',
    phone: '0991234567',
    nextPurchaseDiscountPercentage: null,
  },
  { 
    id: 'cust2', 
    userId: '2', 
    name: 'Ana Anić', 
    email: 'ana.anic@example.com', 
    totalOrders: 1, 
    totalSpent: 45.00, 
    lastOrderDate: '2024-04-22',
    address: 'Moderatorski put 2, 21000 Split',
    phone: '0987654321',
    nextPurchaseDiscountPercentage: 10, // Example: Ana has a 10% discount
  },
  { 
    id: 'cust3', 
    userId: '3', 
    name: 'Ivo Ivić', 
    email: 'ivo.ivic@example.com', 
    totalOrders: 5, 
    totalSpent: 280.75, 
    lastOrderDate: '2024-05-18',
    address: 'Korisnička cesta 3, 51000 Rijeka',
    phone: '0912345678',
    nextPurchaseDiscountPercentage: null,
  },
  { 
    id: 'cust4', 
    userId: '4', 
    name: 'Mara Marić', 
    email: 'mara.maric@example.com', 
    totalOrders: 0, 
    totalSpent: 0,
    address: 'Primorska ulica 4, 31000 Osijek',
    phone: '0955555555',
    nextPurchaseDiscountPercentage: null,
  },
];

export async function getAllCustomers(): Promise<Customer[]> {
  // Simuliraj API kašnjenje
  await new Promise(resolve => setTimeout(resolve, 400));
  return [...dummyCustomers.map(c => ({...c}))]; // Vrati kopiju
}

export async function getCustomerById(id: string): Promise<Customer | undefined> {
  await new Promise(resolve => setTimeout(resolve, 200));
  const customer = dummyCustomers.find(customer => customer.id === id || customer.userId === id);
  if (customer) return {...customer}; // Return a copy
  return undefined;
}

export async function updateCustomerDiscount(customerId: string, discountPercentage: number | null): Promise<Customer | undefined> {
  await new Promise(resolve => setTimeout(resolve, 300));
  const customerIndex = dummyCustomers.findIndex(c => c.id === customerId || c.userId === customerId);
  if (customerIndex > -1) {
    dummyCustomers[customerIndex].nextPurchaseDiscountPercentage = discountPercentage;
    return { ...dummyCustomers[customerIndex] };
  }
  return undefined;
}

// Ovdje se mogu dodati druge funkcije prema potrebi, npr. updateCustomer, deleteCustomer.
// Za sada, getAllCustomers je dovoljan za prikaz popisa.


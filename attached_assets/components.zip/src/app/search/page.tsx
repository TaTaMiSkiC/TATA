
"use client";

import { useEffect, useState, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { SiteHeader } from '@/components/layout/SiteHeader';
import { SiteFooter } from '@/components/layout/SiteFooter';
import { ProductList } from '@/components/products/ProductList';
import { getAllProducts } from '@/services/productService';
import type { Product } from '@/lib/types';
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from '@/components/ui/breadcrumb';
import { Loader2, SearchIcon } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

function SearchPageContent() {
  const searchParams = useSearchParams();
  const query = searchParams.get('q') || '';

  const [searchResults, setSearchResults] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [initialSearchDone, setInitialSearchDone] = useState(false);

  useEffect(() => {
    const fetchAndFilterProducts = async () => {
      setIsLoading(true);
      try {
        const allProducts = await getAllProducts();
        if (query) {
          const lowerCaseQuery = query.toLowerCase();
          const filtered = allProducts.filter(
            product =>
              product.name.toLowerCase().includes(lowerCaseQuery) ||
              product.description.toLowerCase().includes(lowerCaseQuery)
          );
          setSearchResults(filtered);
        } else {
          setSearchResults([]);
        }
      } catch (error) {
        console.error("Greška pri pretraživanju proizvoda:", error);
        setSearchResults([]);
        // Optionally show a toast message for the error
      } finally {
        setIsLoading(false);
        setInitialSearchDone(true);
      }
    };

    fetchAndFilterProducts();
  }, [query]);

  return (
    <div className="flex flex-col min-h-screen">
      <SiteHeader />
      <main className="flex-grow container mx-auto py-8 px-4">
        <Breadcrumb className="mb-8">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/">Početna</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>Rezultati pretrage</BreadcrumbPage>
            </BreadcrumbItem>
            {query && (
              <>
                <BreadcrumbSeparator />
                <BreadcrumbItem>
                  <BreadcrumbPage>&quot;{query}&quot;</BreadcrumbPage>
                </BreadcrumbItem>
              </>
            )}
          </BreadcrumbList>
        </Breadcrumb>

        <h1 className="text-3xl font-bold mb-2">
          {query ? `Rezultati pretrage za "${query}"` : "Pretraga proizvoda"}
        </h1>
        
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-12 w-12 animate-spin text-primary" />
            <p className="ml-4 text-lg">Traženje proizvoda...</p>
          </div>
        ) : !query && initialSearchDone ? (
            <Card className="shadow-lg mt-8">
                <CardContent className="p-8 text-center">
                    <SearchIcon className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
                    <h2 className="text-2xl font-semibold mb-2">Unesite pojam za pretragu</h2>
                    <p className="text-muted-foreground">Molimo unesite naziv ili opis proizvoda koji tražite u tražilicu na vrhu stranice.</p>
                </CardContent>
            </Card>
        ) : searchResults.length === 0 && initialSearchDone ? (
          <Card className="shadow-lg mt-8">
            <CardContent className="p-8 text-center">
                <SearchIcon className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
                <h2 className="text-2xl font-semibold mb-2">Nema rezultata</h2>
                <p className="text-muted-foreground">Nismo pronašli proizvode koji odgovaraju vašoj pretrazi za &quot;{query}&quot;.</p>
                <p className="text-sm text-muted-foreground mt-2">Pokušajte s drugim pojmom ili provjerite pravopis.</p>
            </CardContent>
          </Card>
        ) : (
          <ProductList products={searchResults} />
        )}
      </main>
      <SiteFooter />
    </div>
  );
}

export default function SearchPage() {
  return (
    <Suspense fallback={
      <div className="flex flex-col min-h-screen">
        <SiteHeader />
        <main className="flex-grow flex items-center justify-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </main>
        <SiteFooter />
      </div>
    }>
      <SearchPageContent />
    </Suspense>
  );
}

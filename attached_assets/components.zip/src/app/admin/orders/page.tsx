
"use client";

import { useEffect, useState } from 'react';
import Link from 'next/link';
import type { Order } from '@/lib/types';
import { getAllOrders } from '@/services/orderService';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from '@/hooks/use-toast';
import { Loader2, Eye, FileText } from 'lucide-react';

export default function AdminOrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    async function fetchOrders() {
      setIsLoading(true);
      try {
        const fetchedOrders = await getAllOrders();
        setOrders(fetchedOrders);
      } catch (error) {
        console.error("Greška pri dohvaćanju narudžbi:", error);
        toast({ title: "Greška", description: "Nije uspjelo dohvaćanje narudžbi.", variant: "destructive" });
      } finally {
        setIsLoading(false);
      }
    }
    fetchOrders();
  }, [toast]);

  const getStatusBadgeVariant = (status: Order['status']) => {
    switch (status) {
      case 'Plaćeno':
      case 'Dostavljeno':
        return 'default'; // Greenish (primary)
      case 'Poslano':
        return 'secondary'; // Bluish/grayish
      case 'U obradi':
        return 'outline'; // Yellowish/orangish (accent or custom)
      case 'Otkazano':
        return 'destructive'; // Reddish
      default:
        return 'outline';
    }
  };


  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="ml-2">Učitavanje narudžbi...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Upravljanje narudžbama</h1>
        {/* Optional: Add New Order button if manual creation is needed */}
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle>Popis narudžbi</CardTitle>
          <CardDescription>Pregledajte i upravljajte svim narudžbama.</CardDescription>
        </CardHeader>
        <CardContent>
          {orders.length === 0 ? (
            <div className="py-12 flex flex-col items-center justify-center text-center">
                <FileText className="h-16 w-16 text-muted-foreground mb-4" />
                <p className="text-xl font-semibold text-muted-foreground">Nema zaprimljenih narudžbi.</p>
                <p className="text-sm text-muted-foreground mt-1">Kada stigne prva narudžba, pojavit će se ovdje.</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID Narudžbe</TableHead>
                  <TableHead>Kupac</TableHead>
                  <TableHead className="hidden md:table-cell">Datum</TableHead>
                  <TableHead className="text-right">Ukupno</TableHead>
                  <TableHead className="text-center">Status</TableHead>
                  <TableHead className="text-right">Akcije</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {orders.map((order) => (
                  <TableRow key={order.id}>
                    <TableCell className="font-mono text-xs">{order.id}</TableCell>
                    <TableCell>
                        <div>{order.customerName}</div>
                        <div className="text-xs text-muted-foreground">{order.customerEmail}</div>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      {new Date(order.orderDate).toLocaleDateString('hr-HR', { day: '2-digit', month: '2-digit', year: 'numeric' })}
                    </TableCell>
                    <TableCell className="text-right font-medium">{order.totalAmount.toFixed(2)} €</TableCell>
                    <TableCell className="text-center">
                      <Badge variant={getStatusBadgeVariant(order.status)} className="capitalize">
                        {order.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="outline" size="sm" asChild>
                        <Link href={`/admin/orders/${order.id}`}>
                          <Eye className="mr-2 h-4 w-4" /> Pregledaj
                        </Link>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}


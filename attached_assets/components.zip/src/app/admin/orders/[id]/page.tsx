
"use client";

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import Image from 'next/image';
import type { Order, CartItem, BankAccountConfig } from '@/lib/types';
import { getOrderById, updateOrderStatus } from '@/services/orderService';
import { getAdminPaymentSettings } from '@/services/payment';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from '@/hooks/use-toast';
import { Loader2, ArrowLeft, User, Mail, Home, CalendarDays, ShoppingBag, CreditCard, DollarSign, Package, ListChecks, StickyNote, Palette, Printer, Languages } from 'lucide-react'; 
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Invoice } from '@/components/admin/Invoice';
import { APP_NAME } from '@/lib/constants';
import html2pdf from 'html2pdf.js';

export default function OrderDetailPage() {
  const params = useParams();
  const router = useRouter();
  const orderId = params.id as string;
  const { toast } = useToast();

  const [order, setOrder] = useState<Order | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);
  const [showInvoice, setShowInvoice] = useState(false);
  const [bankDetailsForInvoice, setBankDetailsForInvoice] = useState<BankAccountConfig | undefined>(undefined);
  const [isLoadingBankDetails, setIsLoadingBankDetails] = useState(false);
  const [selectedInvoiceLanguage, setSelectedInvoiceLanguage] = useState<'hr' | 'en' | 'de'>('hr');

  const companyDetailsForInvoice = {
    name: `${APP_NAME} by Dani`, 
    address: "Ossiacher Zeile 30, 9500 Villach, Österreich",
    email: "daniela.svoboda2@gmail.com",
    phone: "00436603878221",
    logoUrl: "https://i.imgur.com/eZK28fm.png" 
  };


  useEffect(() => {
    if (orderId) {
      const fetchOrder = async () => {
        setIsLoading(true);
        try {
          const fetchedOrder = await getOrderById(orderId);
          if (fetchedOrder) {
            setOrder(fetchedOrder);
          } else {
            toast({ title: "Greška", description: "Narudžba nije pronađena.", variant: "destructive" });
            router.push('/admin/orders');
          }
        } catch (error) {
          console.error("Greška pri dohvaćanju narudžbe:", error);
          toast({ title: "Greška", description: "Nije uspjelo dohvaćanje podataka o narudžbi.", variant: "destructive" });
        } finally {
          setIsLoading(false);
        }
      };
      fetchOrder();
    }
  }, [orderId, router, toast]);

  useEffect(() => {
    if (showInvoice && order?.paymentMethod === 'Bankovni Transfer') {
      const fetchBankDetails = async () => {
        setIsLoadingBankDetails(true);
        try {
          const settings = await getAdminPaymentSettings();
          if (settings?.bank?.active) {
            setBankDetailsForInvoice(settings.bank);
          }
        } catch (error) {
          console.error("Greška pri dohvaćanju bankovnih podataka:", error);
          toast({ title: "Greška", description: "Nije uspjelo dohvaćanje bankovnih podataka za račun.", variant: "destructive" });
        } finally {
          setIsLoadingBankDetails(false);
        }
      };
      fetchBankDetails();
    }
  }, [showInvoice, order?.paymentMethod, toast]);

  const handleStatusChange = async (newStatus: Order['status']) => {
    if (!order) return;
    setIsUpdatingStatus(true);
    try {
      const updatedOrder = await updateOrderStatus(order.id, newStatus);
      if (updatedOrder) {
        setOrder(updatedOrder);
        toast({
          title: "Status ažuriran",
          description: `Status narudžbe ${order.id} je promijenjen u "${newStatus}".`,
        });
      }
    } catch (error) {
      console.error("Greška pri ažuriranju statusa:", error);
      toast({ title: "Greška", description: "Nije uspjelo ažuriranje statusa.", variant: "destructive" });
    } finally {
      setIsUpdatingStatus(false);
    }
  };
  
  const getStatusBadgeVariant = (status: Order['status']) => {
    switch (status) {
      case 'Plaćeno':
      case 'Dostavljeno':
        return 'default';
      case 'Poslano':
        return 'secondary';
      case 'U obradi':
        return 'outline'; 
      case 'Otkazano':
        return 'destructive';
      default:
        return 'outline';
    }
  };

  const handleDownloadInvoiceAsPdf = () => {
    if (!order) return;
    const invoiceElement = document.getElementById('printable-invoice-area');
    if (invoiceElement) {
      const opt = {
        margin: [0.2, 0.2, 0.2, 0.2], // Reduced margins (top, right, bottom, left in inches)
        filename: `racun-${order.id}.pdf`,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true, logging: true, scrollY: -window.scrollY },
        jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' },
        pagebreak: { mode: ['avoid-all', 'css', 'legacy'] }
      };
      html2pdf().from(invoiceElement).set(opt).save();
    } else {
      toast({ title: "Greška", description: "Element računa nije pronađen za PDF generiranje.", variant: "destructive" });
    }
  };


  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="ml-2">Učitavanje detalja narudžbe...</p>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="flex flex-col items-center justify-center h-screen">
        <p className="text-xl text-muted-foreground mb-4">Narudžba nije pronađena.</p>
        <Button asChild variant="outline">
          <Link href="/admin/orders">
            <ArrowLeft className="mr-2 h-4 w-4" /> Povratak na popis narudžbi
          </Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {!showInvoice && (
        <>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
                <Button variant="outline" size="icon" asChild>
                <Link href="/admin/orders">
                    <ArrowLeft className="h-4 w-4" />
                </Link>
                </Button>
                <h1 className="text-3xl font-bold">Narudžba #{order.id}</h1>
            </div>
            <div className="flex items-center gap-2">
                <Select value={selectedInvoiceLanguage} onValueChange={(lang) => setSelectedInvoiceLanguage(lang as 'hr' | 'en' | 'de')}>
                  <SelectTrigger className="w-[180px]">
                    <Languages className="mr-2 h-4 w-4 text-muted-foreground" />
                    <SelectValue placeholder="Jezik računa" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hr">Hrvatski</SelectItem>
                    <SelectItem value="en">Engleski</SelectItem>
                    <SelectItem value="de">Njemački</SelectItem>
                  </SelectContent>
                </Select>
                <Button onClick={() => setShowInvoice(true)} variant="outline">
                    <Printer className="mr-2 h-4 w-4"/> Generiraj Račun
                </Button>
                <Badge variant={getStatusBadgeVariant(order.status)} className="text-sm px-3 py-1 capitalize">
                    {order.status}
                </Badge>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <Card className="md:col-span-2 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <ShoppingBag className="mr-3 h-6 w-6 text-primary" />
                  Stavke narudžbe
                </CardTitle>
              </CardHeader>
              <CardContent>
                {order.items.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="hidden sm:table-cell">Slika</TableHead>
                        <TableHead>Proizvod</TableHead>
                        <TableHead className="text-center">Količina</TableHead>
                        <TableHead className="text-right">Cijena/kom</TableHead>
                        <TableHead className="text-right">Ukupno</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {order.items.map((item) => (
                        <TableRow key={`${item.id}-${item.selectedFragrance || 'default'}-${item.selectedColor || 'default'}`}>
                          <TableCell className="hidden sm:table-cell">
                            <Image
                              src={item.imageUrl}
                              alt={item.name}
                              width={48}
                              height={48}
                              className="rounded-md aspect-square object-cover"
                              data-ai-hint="svijeća minijatura"
                            />
                          </TableCell>
                          <TableCell>
                            <Link href={`/products/${item.id}`} className="font-medium hover:text-primary">{item.name}</Link>
                            {item.selectedFragrance && (
                              <p className="text-xs text-muted-foreground">Miris: {item.selectedFragrance}</p>
                            )}
                            {item.selectedColor && ( 
                              <p className="text-xs text-muted-foreground flex items-center"><Palette className="mr-1 h-3 w-3"/>Boja: {item.selectedColor}</p>
                            )}
                            <p className="text-xs text-muted-foreground">Kategorija: {item.categorySlug}</p>
                          </TableCell>
                          <TableCell className="text-center">{item.quantity}</TableCell>
                          <TableCell className="text-right">{item.price.toFixed(2)} €</TableCell>
                          <TableCell className="text-right font-semibold">{(item.price * item.quantity).toFixed(2)} €</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <p className="text-muted-foreground">Nema stavki u ovoj narudžbi.</p>
                )}
              </CardContent>
              <CardFooter className="bg-muted/50 p-6 flex justify-end">
                <div className="text-right">
                    <p className="text-sm text-muted-foreground">Međuzbroj: {order.items.reduce((sum, item) => sum + item.price * item.quantity, 0).toFixed(2)} €</p>
                    <p className="text-sm text-muted-foreground">Dostava: 0.00 €</p> 
                    <p className="text-xl font-bold text-primary mt-1">Ukupno: {order.totalAmount.toFixed(2)} €</p>
                </div>
              </CardFooter>
            </Card>

            <div className="space-y-6">
              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <ListChecks className="mr-3 h-6 w-6 text-primary" />
                    Status narudžbe
                  </CardTitle>
                </CardHeader>
                <CardContent>
                    <Select
                        value={order.status}
                        onValueChange={(newStatus: Order['status']) => handleStatusChange(newStatus)}
                        disabled={isUpdatingStatus}
                    >
                        <SelectTrigger className="w-full">
                        <SelectValue placeholder="Promijeni status" />
                        </SelectTrigger>
                        <SelectContent>
                        {(['U obradi', 'Plaćeno', 'Poslano', 'Dostavljeno', 'Otkazano'] as Order['status'][]).map(s => (
                            <SelectItem key={s} value={s}>{s}</SelectItem>
                        ))}
                        </SelectContent>
                    </Select>
                    {isUpdatingStatus && <p className="text-xs text-muted-foreground mt-2 flex items-center"><Loader2 className="h-3 w-3 animate-spin mr-1"/> Ažuriranje...</p>}
                </CardContent>
              </Card>

              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <User className="mr-3 h-6 w-6 text-primary" />
                    Podaci o kupcu
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <InfoItem icon={<User className="h-4 w-4" />} label="Ime" value={order.customerName} />
                  <InfoItem icon={<Mail className="h-4 w-4" />} label="Email" value={order.customerEmail} />
                  <InfoItem icon={<Home className="h-4 w-4" />} label="Adresa za dostavu" value={order.shippingAddress} />
                </CardContent>
              </Card>

              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <CreditCard className="mr-3 h-6 w-6 text-primary" />
                    Detalji plaćanja
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <InfoItem icon={<CalendarDays className="h-4 w-4" />} label="Datum narudžbe" value={new Date(order.orderDate).toLocaleString('hr-HR')} />
                  <InfoItem icon={<CreditCard className="h-4 w-4" />} label="Način plaćanja" value={order.paymentMethod || 'N/A'} />
                  <InfoItem icon={<DollarSign className="h-4 w-4" />} label="Ukupan iznos" value={`${order.totalAmount.toFixed(2)} €`} />
                </CardContent>
              </Card>

              {order.notes && (
                <Card className="shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <StickyNote className="mr-3 h-6 w-6 text-primary" />
                      Napomene kupca
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">{order.notes}</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>

          <div className="flex justify-start mt-6">
            <Button variant="outline" onClick={() => router.push('/admin/orders')}>
              <ArrowLeft className="mr-2 h-4 w-4" /> Povratak na popis narudžbi
            </Button>
          </div>
        </>
      )}

      {showInvoice && (
        isLoadingBankDetails ? (
          <div className="flex justify-center items-center h-64">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="ml-2">Učitavanje podataka za račun...</p>
          </div>
        ) : order && (
          <>
            <div id="printable-invoice-area" className="my-4 bg-white shadow-2xl rounded-lg"> {/* Reduced my-8 to my-4 */}
                <Invoice order={order} companyDetails={companyDetailsForInvoice} bankDetails={bankDetailsForInvoice} language={selectedInvoiceLanguage} />
            </div>
            <div className="text-center mt-4 pb-6 no-print"> {/* Reduced margins/paddings */}
              <Button onClick={handleDownloadInvoiceAsPdf} variant="default" size="lg" className="mr-4">
                <Printer className="mr-2 h-5 w-5" /> Ispis Računa (Preuzmi PDF)
              </Button>
              <Button onClick={() => setShowInvoice(false)} variant="outline" size="lg">
                Zatvori Pregled Računa
              </Button>
            </div>
          </>
        )
      )}
    </div>
  );
}

interface InfoItemProps {
  icon: React.ReactNode;
  label: string;
  value?: string | number;
}

function InfoItem({ icon, label, value }: InfoItemProps) {
  return (
    <div className="flex items-center text-sm">
      <span className="flex-shrink-0 w-5 mr-2 text-muted-foreground">{icon}</span>
      <span className="font-medium text-muted-foreground min-w-[120px]">{label}:</span>
      <span className="text-foreground ml-2 break-all">{value}</span>
    </div>
  );
}



"use client";

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useForm, type SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { ArrowLeft, Save, Palette, Bell, ShieldCheck, Loader2 } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Separator } from '@/components/ui/separator';
import { ThemeToggle } from '@/components/ThemeToggle'; 
import { useAuth } from '@/hooks/useAuth'; 
import { useRouter } from 'next/navigation';
import { APP_NAME } from '@/lib/constants';

// Mock data and functions for settings - replace with actual service calls
interface AdminSettings {
  siteName: string;
  adminEmail: string;
  enableMaintenanceMode: boolean;
  notificationPreferences: {
    newOrders: boolean;
    lowStock: boolean;
  };
  // Add more settings as needed
}

const mockGetAdminSettings = async (): Promise<AdminSettings> => {
  await new Promise(resolve => setTimeout(resolve, 500)); 
  return {
    siteName: `${APP_NAME} by Dani`, // Changed to Dani
    adminEmail: "admin@kerzenwelt.com",
    enableMaintenanceMode: false,
    notificationPreferences: {
      newOrders: true,
      lowStock: true,
    },
  };
};

const mockSaveAdminSettings = async (settings: AdminSettings): Promise<void> => {
  await new Promise(resolve => setTimeout(resolve, 500)); 
  console.log("Spremanje postavki:", settings);
};


const settingsSchema = z.object({
  siteName: z.string().min(3, "Naziv stranice mora imati najmanje 3 znaka."),
  adminEmail: z.string().email("Unesite važeću email adresu."),
  enableMaintenanceMode: z.boolean().default(false),
  notificationPreferences: z.object({
    newOrders: z.boolean().default(true),
    lowStock: z.boolean().default(true),
  }),
});

type SettingsFormData = z.infer<typeof settingsSchema>;

export default function AdminSettingsPage() {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(true);
  const auth = useAuth();
  const router = useRouter();

  const form = useForm<SettingsFormData>({
    resolver: zodResolver(settingsSchema),
    defaultValues: {
      siteName: "",
      adminEmail: "",
      enableMaintenanceMode: false,
      notificationPreferences: {
        newOrders: true,
        lowStock: true,
      },
    },
  });

  useEffect(() => {
    if (!auth.isLoading && !auth.isAdmin) {
      router.push('/admin/dashboard'); 
      return;
    }

    const fetchSettings = async () => {
      if(auth.isAdmin) {
        setIsLoading(true);
        try {
          const settings = await mockGetAdminSettings();
          form.reset(settings);
        } catch (error) {
          console.error("Greška pri dohvaćanju postavki:", error);
          toast({
            title: "Greška",
            description: "Nije uspjelo dohvaćanje postavki.",
            variant: "destructive",
          });
        } finally {
          setIsLoading(false);
        }
      } else {
         setIsLoading(false);
      }
    };
    if(!auth.isLoading){
        fetchSettings();
    }
  }, [form, toast, auth.isAdmin, auth.isLoading, router]);

  const onSubmit: SubmitHandler<SettingsFormData> = async (data) => {
    if (!auth.isAdmin) {
      toast({ title: "Neovlašteno", description: "Samo administratori mogu mijenjati ove postavke.", variant: "destructive"});
      return;
    }
    try {
      await mockSaveAdminSettings(data);
      toast({
        title: "Postavke spremljene",
        description: "Vaše administrativne postavke su uspješno spremljene.",
      });
    } catch (error) {
      console.error("Greška pri spremanju postavki:", error);
      toast({
        title: "Greška",
        description: "Nije uspjelo spremanje postavki. Molimo pokušajte ponovno.",
        variant: "destructive",
      });
    }
  };

  if (isLoading || auth.isLoading) {
    return (
      <div className="flex justify-center items-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="ml-2">Učitavanje postavki...</p>
      </div>
    );
  }

   if (!auth.isAdmin) {
     return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Administrativne postavke</h1>
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Pristup odbijen</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">Nemate ovlasti za pristup ovoj stranici.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" asChild>
          <Link href="/admin/dashboard">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <h1 className="text-3xl font-bold">Administrativne postavke</h1>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Palette className="mr-3 h-6 w-6 text-primary" />
                Opće postavke
              </CardTitle>
              <CardDescription>Osnovne informacije i postavke vaše trgovine.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <FormField
                control={form.control}
                name="siteName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Naziv stranice</FormLabel>
                    <FormControl>
                      <Input placeholder={`${APP_NAME} by Dani`} {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="adminEmail"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Admin email</FormLabel>
                    <FormControl>
                      <Input type="email" placeholder="admin@primjer.com" {...field} />
                    </FormControl>
                    <FormDescription>Email adresa za administrativne obavijesti.</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="enableMaintenanceMode"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                    <div className="space-y-0.5">
                      <FormLabel>Način održavanja</FormLabel>
                      <FormDescription>
                        Privremeno onemogućite pristup javnoj stranici.
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
               <div className="flex items-center space-x-2">
                <Label htmlFor="theme-toggle-settings">Odabir Teme</Label>
                <ThemeToggle />
              </div>
            </CardContent>
          </Card>
          
          <Separator />

          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Bell className="mr-3 h-6 w-6 text-primary" />
                Obavijesti
              </CardTitle>
              <CardDescription>Postavke za email obavijesti.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="notificationPreferences.newOrders"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                    <div className="space-y-0.5">
                      <FormLabel>Nove narudžbe</FormLabel>
                      <FormDescription>
                        Primajte email obavijesti za svaku novu narudžbu.
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="notificationPreferences.lowStock"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                    <div className="space-y-0.5">
                      <FormLabel>Niska zaliha</FormLabel>
                      <FormDescription>
                        Primajte email upozorenja kada je zaliha proizvoda niska.
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <Separator />

           <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center">
                <ShieldCheck className="mr-3 h-6 w-6 text-primary" />
                Sigurnost i Privatnost
              </CardTitle>
              <CardDescription>Postavke vezane uz sigurnost i privatnost podataka.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">
                    Ovdje će biti dostupne napredne postavke sigurnosti i privatnosti. Trenutno u razvoju.
                </p>
                 <Button type="button" variant="outline" disabled>Konfiguriraj pravila privatnosti</Button>
            </CardContent>
          </Card>


          <div className="flex justify-end pt-4">
            <Button type="submit" disabled={form.formState.isSubmitting}>
              {form.formState.isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Spremanje...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Spremi postavke
                </>
              )}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}



"use client";

import { useEffect, useState } from 'react';
import type { User } from '@/lib/types';
import { getAllUsers, updateUserRole } from '@/services/userService';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth'; // Import useAuth

export default function AdminUsersPage() {
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();
  const auth = useAuth(); // Get auth state

  const fetchUsers = async () => {
    setIsLoading(true);
    try {
      const fetchedUsers = await getAllUsers();
      setUsers(fetchedUsers);
    } catch (error) {
      console.error("Failed to fetch users:", error);
      toast({ title: "Greška", description: "Nije uspjelo dohvaćanje korisnika.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    // Only fetch users if the current user is an admin
    if (auth.isAdmin) {
      fetchUsers();
    } else if (!auth.isLoading) {
      // If not admin and not loading, means they shouldn't be here.
      // The AdminLayout should handle redirection, but as a fallback:
      setIsLoading(false); 
      // Optionally, redirect or show an access denied message if AdminLayout fails
      // router.push('/admin/dashboard'); // Or some other safe page
    }
  }, [auth.isAdmin, auth.isLoading]);

  const handleRoleChange = async (userId: string, newRole: User['role']) => {
    if (!auth.isAdmin) {
      toast({ title: "Neovlašteno", description: "Samo administratori mogu mijenjati uloge.", variant: "destructive" });
      return;
    }
    try {
      const updatedUser = await updateUserRole(userId, newRole);
      if (updatedUser) {
        setUsers(currentUsers =>
          currentUsers.map(user => (user.id === userId ? updatedUser : user))
        );
        toast({
          title: "Uloga ažurirana",
          description: `Uloga za korisnika ${updatedUser.name || updatedUser.email} je promijenjena u ${newRole}.`,
        });
      } else {
        toast({ title: "Greška", description: "Korisnik nije pronađen.", variant: "destructive" });
      }
    } catch (error) {
      console.error("Failed to update user role:", error);
      toast({ title: "Greška", description: "Nije uspjelo ažuriranje uloge korisnika.", variant: "destructive" });
    }
  };

  if (isLoading || auth.isLoading) {
    return (
      <div className="flex justify-center items-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="ml-2">Učitavanje korisnika...</p>
      </div>
    );
  }

  // If the user is not an admin, show an access denied message or redirect.
  // This is a secondary check; AdminLayout should be the primary gatekeeper.
  if (!auth.isAdmin) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Upravljanje korisnicima</h1>
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Pristup odbijen</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">Nemate ovlasti za pristup ovoj stranici.</p>
          </CardContent>
        </Card>
      </div>
    );
  }


  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Upravljanje korisnicima</h1>
        {/* TODO: Add "Add New User" button if needed, ensure only admin can use it */}
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle>Popis korisnika</CardTitle>
          <CardDescription>Pregledajte i upravljajte korisničkim ulogama.</CardDescription>
        </CardHeader>
        <CardContent>
          {users.length === 0 ? (
             <p className="text-center text-muted-foreground py-8">Nema korisnika.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Ime</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Uloga</TableHead>
                  <TableHead className="text-right">Akcije</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">{user.name || 'N/A'}</TableCell>
                    <TableCell>{user.email}</TableCell>
                    <TableCell>{user.role.charAt(0).toUpperCase() + user.role.slice(1)}</TableCell>
                    <TableCell className="text-right">
                      <Select
                        value={user.role}
                        onValueChange={(newRole: User['role']) => handleRoleChange(user.id, newRole)}
                        disabled={!auth.isAdmin || user.id === auth.role} // Admin cannot change their own role via this UI for safety
                      >
                        <SelectTrigger className="w-[150px]" disabled={!auth.isAdmin}>
                          <SelectValue placeholder="Promijeni ulogu" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="korisnik">Korisnik</SelectItem>
                          <SelectItem value="moderator">Moderator</SelectItem>
                          <SelectItem value="admin">Admin</SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}


"use client";

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import type { Customer, Order } from '@/lib/types';
import { getCustomerById, updateCustomerDiscount } from '@/services/customerService';
import { getOrdersByUserId } from '@/services/orderService';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from '@/hooks/use-toast';
import { Loader2, ArrowLeft, User, Mail, ShoppingBag, BarChart2, CalendarDays, Eye, FileText, Percent, Save, XCircle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useAuth } from '@/hooks/useAuth';
import { useForm, type SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";

const discountSchema = z.object({
  discountPercentage: z.preprocess(
    (val) => (val === "" || val === undefined ? null : Number(val)), // Allow empty string to become null
    z.number().min(5, "Popust mora biti najmanje 5%.").max(75, "Popust mora biti najviše 75%.").nullable()
  )
});
type DiscountFormData = z.infer<typeof discountSchema>;

export default function CustomerDetailPage() {
  const params = useParams();
  const router = useRouter();
  const customerId = params.id as string;
  const { toast } = useToast();
  const auth = useAuth();

  const [customer, setCustomer] = useState<Customer | null>(null);
  const [customerOrders, setCustomerOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isLoadingOrders, setIsLoadingOrders] = useState(true);
  const [isUpdatingDiscount, setIsUpdatingDiscount] = useState(false);

  const discountForm = useForm<DiscountFormData>({
    resolver: zodResolver(discountSchema),
    defaultValues: {
      discountPercentage: null,
    },
  });

  useEffect(() => {
    if (customerId) {
      const fetchCustomerData = async () => {
        setIsLoading(true);
        setIsLoadingOrders(true);
        try {
          const fetchedCustomer = await getCustomerById(customerId);
          if (fetchedCustomer) {
            setCustomer(fetchedCustomer);
            discountForm.reset({ discountPercentage: fetchedCustomer.nextPurchaseDiscountPercentage || null });
            const fetchedOrders = await getOrdersByUserId(fetchedCustomer.userId || fetchedCustomer.id);
            setCustomerOrders(fetchedOrders);
          } else {
            toast({ title: "Greška", description: "Kupac nije pronađen.", variant: "destructive" });
            router.push('/admin/customers');
          }
        } catch (error) {
          console.error("Greška pri dohvaćanju podataka o kupcu ili narudžbama:", error);
          toast({ title: "Greška", description: "Nije uspjelo dohvaćanje podataka.", variant: "destructive" });
        } finally {
          setIsLoading(false);
          setIsLoadingOrders(false);
        }
      };
      fetchCustomerData();
    }
  }, [customerId, router, toast, discountForm]);

  const getOrderStatusBadgeVariant = (status: Order['status']) => {
    switch (status) {
      case 'Plaćeno': case 'Dostavljeno': return 'default';
      case 'Poslano': return 'secondary';
      case 'U obradi': return 'outline';
      case 'Otkazano': return 'destructive';
      default: return 'outline';
    }
  };

  const handleDiscountSubmit: SubmitHandler<DiscountFormData> = async (data) => {
    if (!customer || !auth.isAdmin) return;
    setIsUpdatingDiscount(true);
    try {
      const updatedCustomer = await updateCustomerDiscount(customer.id, data.discountPercentage);
      if (updatedCustomer) {
        setCustomer(updatedCustomer); // Update local state
        discountForm.reset({ discountPercentage: updatedCustomer.nextPurchaseDiscountPercentage || null });
        toast({ title: "Popust ažuriran", description: `Popust za kupca ${customer.name} je uspješno postavljen.` });
      } else {
        toast({ title: "Greška", description: "Nije uspjelo ažuriranje popusta.", variant: "destructive" });
      }
    } catch (error) {
      toast({ title: "Greška", description: "Dogodila se greška prilikom ažuriranja popusta.", variant: "destructive" });
    } finally {
      setIsUpdatingDiscount(false);
    }
  };
  
  const handleClearDiscount = async () => {
    if (!customer || !auth.isAdmin) return;
    setIsUpdatingDiscount(true);
    try {
      const updatedCustomer = await updateCustomerDiscount(customer.id, null);
      if (updatedCustomer) {
        setCustomer(updatedCustomer);
        discountForm.reset({ discountPercentage: null });
        toast({ title: "Popust uklonjen", description: `Popust za kupca ${customer.name} je uklonjen.` });
      } else {
        toast({ title: "Greška", description: "Nije uspjelo uklanjanje popusta.", variant: "destructive" });
      }
    } catch (error) {
       toast({ title: "Greška", description: "Dogodila se greška prilikom uklanjanja popusta.", variant: "destructive" });
    } finally {
      setIsUpdatingDiscount(false);
    }
  };


  if (isLoading || auth.isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="ml-2">Učitavanje detalja kupca...</p>
      </div>
    );
  }

  if (!customer) {
    return (
      <div className="flex flex-col items-center justify-center h-screen">
        <p className="text-xl text-muted-foreground mb-4">Kupac nije pronađen.</p>
        <Button asChild variant="outline">
          <Link href="/admin/customers">
            <ArrowLeft className="mr-2 h-4 w-4" /> Povratak na popis kupaca
          </Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" asChild>
          <Link href="/admin/customers">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <h1 className="text-3xl font-bold">Detalji kupca: {customer.name || `ID: ${customer.id}`}</h1>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
            <Card className="shadow-lg">
            <CardHeader>
                <CardTitle className="flex items-center">
                <User className="mr-3 h-6 w-6 text-primary" />
                Informacije o kupcu
                </CardTitle>
                <CardDescription>Pregled svih dostupnih podataka za kupca.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <InfoItem icon={<User className="h-5 w-5 text-primary" />} label="Ime i Prezime" value={customer.name || 'N/A'} />
                <InfoItem icon={<Mail className="h-5 w-5 text-primary" />} label="Email adresa" value={customer.email} />
                </div>
                
                <Separator />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <InfoItem icon={<ShoppingBag className="h-5 w-5 text-primary" />} label="Ukupno narudžbi">
                    <Badge variant={customer.totalOrders > 0 ? "default" : "secondary"}>{customer.totalOrders}</Badge>
                </InfoItem>
                <InfoItem icon={<BarChart2 className="h-5 w-5 text-primary" />} label="Ukupno potrošeno" value={`${customer.totalSpent.toFixed(2)} €`} />
                </div>
                
                <Separator />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <InfoItem icon={<CalendarDays className="h-5 w-5 text-primary" />} label="Datum zadnje narudžbe" value={customer.lastOrderDate ? new Date(customer.lastOrderDate).toLocaleDateString('hr-HR') : 'N/A'} />
                <InfoItem icon={<User className="h-5 w-5 text-muted-foreground" />} label="Korisnički ID (ako postoji)" value={customer.userId || 'N/A'} />
                </div>
                 <InfoItem icon={<Percent className="h-5 w-5 text-primary" />} label="Popust za sljedeću kupnju" value={customer.nextPurchaseDiscountPercentage ? `${customer.nextPurchaseDiscountPercentage}%` : 'Nema popusta'} />
            </CardContent>
            </Card>

            <Card className="shadow-lg">
                <CardHeader>
                    <CardTitle className="flex items-center">
                        <ShoppingBag className="mr-2 h-5 w-5 text-primary" />
                        Povijest narudžbi
                    </CardTitle>
                </CardHeader>
                <CardContent>
                {isLoadingOrders ? (
                    <div className="flex items-center">
                        <Loader2 className="h-5 w-5 animate-spin text-primary mr-2" />
                        <p>Učitavanje narudžbi...</p>
                    </div>
                ) : customerOrders.length === 0 ? (
                    <div className="py-8 flex flex-col items-center justify-center text-center bg-muted/50 rounded-md">
                        <FileText className="h-12 w-12 text-muted-foreground mb-3" />
                        <p className="text-md font-semibold text-muted-foreground">Kupac nema prethodnih narudžbi.</p>
                    </div>
                ) : (
                    <Table>
                    <TableHeader>
                        <TableRow>
                        <TableHead>ID Narudžbe</TableHead>
                        <TableHead>Datum</TableHead>
                        <TableHead className="text-right">Ukupno</TableHead>
                        <TableHead className="text-center">Status</TableHead>
                        <TableHead className="text-right">Akcije</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {customerOrders.map((order) => (
                        <TableRow key={order.id}>
                            <TableCell className="font-mono text-xs">{order.id}</TableCell>
                            <TableCell>
                            {new Date(order.orderDate).toLocaleDateString('hr-HR', { day: '2-digit', month: '2-digit', year: 'numeric' })}
                            </TableCell>
                            <TableCell className="text-right font-medium">{order.totalAmount.toFixed(2)} €</TableCell>
                            <TableCell className="text-center">
                            <Badge variant={getOrderStatusBadgeVariant(order.status)} className="capitalize">
                                {order.status}
                            </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                            <Button variant="outline" size="sm" asChild>
                                <Link href={`/admin/orders/${order.id}`}>
                                <Eye className="mr-2 h-4 w-4" /> Pregledaj
                                </Link>
                            </Button>
                            </TableCell>
                        </TableRow>
                        ))}
                    </TableBody>
                    </Table>
                )}
                </CardContent>
            </Card>
        </div>

        {auth.isAdmin && (
          <div className="md:col-span-1 space-y-6">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Percent className="mr-3 h-6 w-6 text-primary" />
                  Popust za sljedeću kupnju
                </CardTitle>
                <CardDescription>Postavite postotak popusta za sljedeću kupnju ovog kupca.</CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...discountForm}>
                  <form onSubmit={discountForm.handleSubmit(handleDiscountSubmit)} className="space-y-4">
                    <FormField
                      control={discountForm.control}
                      name="discountPercentage"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Postotak popusta (5-75%)</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              placeholder="Npr. 10 za 10%" 
                              {...field} 
                              value={field.value === null ? '' : field.value} // Show empty string for null
                              onChange={e => field.onChange(e.target.value === '' ? null : Number(e.target.value))}
                            />
                          </FormControl>
                          <FormDescription>Ostavite prazno za uklanjanje popusta.</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="flex gap-2">
                        <Button type="submit" disabled={isUpdatingDiscount || !discountForm.formState.isDirty}>
                        {isUpdatingDiscount ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                        Spremi popust
                        </Button>
                        {customer?.nextPurchaseDiscountPercentage !== null && (
                             <Button type="button" variant="outline" onClick={handleClearDiscount} disabled={isUpdatingDiscount}>
                                <XCircle className="mr-2 h-4 w-4" /> Ukloni popust
                            </Button>
                        )}
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>
        )}
      </div>

      <div className="flex justify-end mt-6">
        <Button variant="outline" onClick={() => router.push('/admin/customers')}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Povratak na popis kupaca
        </Button>
      </div>
    </div>
  );
}

interface InfoItemProps {
  icon: React.ReactNode;
  label: string;
  value?: string | number | React.ReactNode;
  children?: React.ReactNode;
}

function InfoItem({ icon, label, value, children }: InfoItemProps) {
  return (
    <div className="flex items-start space-x-3">
      <span className="flex-shrink-0 mt-1">{icon}</span>
      <div>
        <p className="text-sm font-medium text-muted-foreground">{label}</p>
        {value !== undefined && <p className="font-semibold text-lg">{value}</p>}
        {children}
      </div>
    </div>
  );
}


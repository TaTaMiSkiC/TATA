
"use client";

import { useEffect, useState } from 'react';
import type { Customer } from '@/lib/types';
import { getAllCustomers } from '@/services/customerService'; // Pretpostavljamo da postoji customerService
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from '@/hooks/use-toast';
import { Loader2, Eye, Trash2, Percent } from 'lucide-react'; // Dodani Eye i Trash2 za akcije, Percent for discount
import { Badge } from '@/components/ui/badge';
import Link from 'next/link';

export default function AdminCustomersPage() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    async function fetchCustomers() {
      setIsLoading(true);
      try {
        const fetchedCustomers = await getAllCustomers();
        setCustomers(fetchedCustomers);
      } catch (error) {
        console.error("Greška pri dohvaćanju kupaca:", error);
        toast({ title: "Greška", description: "Nije uspjelo dohvaćanje kupaca.", variant: "destructive" });
      } finally {
        setIsLoading(false);
      }
    }
    fetchCustomers();
  }, [toast]);

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="ml-2">Učitavanje kupaca...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Upravljanje kupcima</h1>
        {/* TODO: Dodati gumb "Dodaj novog kupca" ako je potrebno */}
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle>Popis kupaca</CardTitle>
          <CardDescription>Pregledajte i upravljajte podacima o kupcima.</CardDescription>
        </CardHeader>
        <CardContent>
          {customers.length === 0 ? (
             <p className="text-center text-muted-foreground py-8">Nema registriranih kupaca.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Ime</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead className="text-center hidden md:table-cell">Ukupno narudžbi</TableHead>
                  <TableHead className="text-right hidden md:table-cell">Ukupno potrošeno</TableHead>
                  <TableHead className="hidden lg:table-cell">Zadnja narudžba</TableHead>
                  <TableHead className="text-center">Popust</TableHead>
                  <TableHead className="text-right">Akcije</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {customers.map((customer) => (
                  <TableRow key={customer.id}>
                    <TableCell className="font-mono text-xs">{customer.id}</TableCell>
                    <TableCell className="font-medium">{customer.name || 'N/A'}</TableCell>
                    <TableCell>{customer.email}</TableCell>
                    <TableCell className="text-center hidden md:table-cell">
                      <Badge variant={customer.totalOrders > 0 ? "default" : "secondary"}>
                        {customer.totalOrders}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right hidden md:table-cell">
                        {customer.totalSpent.toFixed(2)} €
                    </TableCell>
                    <TableCell className="hidden lg:table-cell">
                        {customer.lastOrderDate ? new Date(customer.lastOrderDate).toLocaleDateString('hr-HR') : 'N/A'}
                    </TableCell>
                    <TableCell className="text-center">
                      {customer.nextPurchaseDiscountPercentage ? (
                        <Badge variant="outline" className="text-primary border-primary">
                          <Percent className="mr-1 h-3 w-3" />
                          {customer.nextPurchaseDiscountPercentage}%
                        </Badge>
                      ) : (
                        <span className="text-xs text-muted-foreground">-</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button variant="outline" size="icon" asChild title="Pregledaj kupca">
                          <Link href={`/admin/customers/${customer.id}`}>
                            <Eye className="h-4 w-4" />
                          </Link>
                        </Button>
                        <Button variant="destructive" size="icon" title="Obriši kupca" onClick={() => alert(`Brisanje kupca ${customer.id} još nije implementirano.`)}>
                            <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

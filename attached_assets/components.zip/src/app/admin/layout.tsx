"use client"; 

import type { ReactNode } from 'react';
import {
  SidebarProvider,
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarFooter,
  SidebarTrigger,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarMenuSub,
  SidebarMenuSubItem,
  SidebarMenuSubButton,
  SidebarInset,
} from '@/components/ui/sidebar';
import { Home, Package, Tag, ListOrdered, Users, Settings, CreditCard, LogOut, UsersRound, Globe, Loader2, SprayCan, Palette, Flame } from 'lucide-react'; // Added Flame
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { APP_NAME } from '@/lib/constants';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useAuth } from '@/hooks/useAuth';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';


export default function AdminLayout({ children }: { children: ReactNode }) {
  const auth = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (typeof window !== 'undefined' && !window.auth) {
        // @ts-ignore
        window.auth = auth; // For easier testing in browser console
    }
    if (!auth.isLoading) {
      if (!auth.isAdmin && !auth.isModerator) {
        router.push('/login'); 
      }
    }
  }, [auth, router]);

  if (auth.isLoading) {
    return (
      <div className="flex flex-col min-h-screen items-center justify-center bg-background">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
        <p className="mt-4 text-lg text-foreground">Provjera autorizacije...</p>
         <p className="mt-2 text-sm text-muted-foreground">Ako ovo potraje, pokušajte postaviti ulogu u konzoli:</p>
        <code className="mt-1 text-xs bg-muted p-1 rounded">localStorage.setItem('mockUserRole', 'admin');</code>
        <p className="mt-1 text-xs text-muted-foreground">i osvježite stranicu.</p>
      </div>
    );
  }

  if (!auth.isAdmin && !auth.isModerator) {
    // User is not authorized and not loading, redirect should have happened.
    // Return null or a minimal message to avoid rendering admin UI.
    return null; 
  }

  return (
    <SidebarProvider defaultOpen>
      <Sidebar variant="inset" collapsible="icon" side="left">
        <SidebarHeader className="items-center p-4">
          <Link href="/admin/dashboard" className="flex items-center gap-2 group-data-[collapsible=icon]:justify-center">
            <Flame className="h-7 w-7 text-primary" /> {/* Logo Icon */}
            <span className="font-semibold text-lg text-primary group-data-[collapsible=icon]:hidden">{APP_NAME} Admin</span>
          </Link>
          <SidebarTrigger className="group-data-[collapsible=icon]:hidden ml-auto" />
        </SidebarHeader>
        <SidebarContent className="p-2">
          <SidebarMenu>
            <SidebarMenuItem>
              <SidebarMenuButton asChild isActive={false} tooltip="Nadzorna ploča">
                <Link href="/admin/dashboard"><Home />Nadzorna ploča</Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
            <SidebarMenuItem>
              <SidebarMenuButton asChild tooltip="Početna stranica">
                <Link href="/"><Globe />Početna stranica</Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
            <SidebarMenuItem>
              <SidebarMenuButton asChild tooltip="Proizvodi">
                <Link href="/admin/products"><Package />Proizvodi</Link>
              </SidebarMenuButton>
              <SidebarMenuSub>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton asChild><Link href="/admin/products">Svi proizvodi</Link></SidebarMenuSubButton>
                </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton asChild><Link href="/admin/products/new">Dodaj novi</Link></SidebarMenuSubButton>
                </SidebarMenuSubItem>
              </SidebarMenuSub>
            </SidebarMenuItem>
            <SidebarMenuItem>
              <SidebarMenuButton asChild tooltip="Kategorije">
                <Link href="/admin/categories"><Tag />Kategorije</Link>
              </SidebarMenuButton>
               <SidebarMenuSub>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton asChild><Link href="/admin/categories">Sve kategorije</Link></SidebarMenuSubButton>
                </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton asChild><Link href="/admin/categories/new">Dodaj novu</Link></SidebarMenuSubButton>
                </SidebarMenuSubItem>
              </SidebarMenuSub>
            </SidebarMenuItem>
            <SidebarMenuItem>
              <SidebarMenuButton asChild tooltip="Mirisi">
                <Link href="/admin/fragrances"><SprayCan />Mirisi</Link>
              </SidebarMenuButton>
               <SidebarMenuSub>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton asChild><Link href="/admin/fragrances">Svi mirisi</Link></SidebarMenuSubButton>
                </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton asChild><Link href="/admin/fragrances/new">Dodaj novi</Link></SidebarMenuSubButton>
                </SidebarMenuSubItem>
              </SidebarMenuSub>
            </SidebarMenuItem>
            <SidebarMenuItem>
              <SidebarMenuButton asChild tooltip="Boje">
                <Link href="/admin/colors"><Palette />Boje</Link>
              </SidebarMenuButton>
               <SidebarMenuSub>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton asChild><Link href="/admin/colors">Sve boje</Link></SidebarMenuSubButton>
                </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton asChild><Link href="/admin/colors/new">Dodaj novu</Link></SidebarMenuSubButton>
                </SidebarMenuSubItem>
              </SidebarMenuSub>
            </SidebarMenuItem>
             {auth.isAdmin && ( // Only Admin can see Users
                <SidebarMenuItem>
                <SidebarMenuButton asChild tooltip="Korisnici">
                    <Link href="/admin/users"><UsersRound />Korisnici</Link>
                </SidebarMenuButton>
                </SidebarMenuItem>
             )}
            <SidebarMenuItem>
              <SidebarMenuButton asChild tooltip="Narudžbe">
                <Link href="/admin/orders"><ListOrdered />Narudžbe</Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
            <SidebarMenuItem>
              <SidebarMenuButton asChild tooltip="Kupci">
                <Link href="/admin/customers"><Users />Kupci</Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
            {auth.isAdmin && ( // Only Admin can see Payment Accounts
              <SidebarMenuItem>
                <SidebarMenuButton asChild tooltip="Računi za plaćanje">
                  <Link href="/admin/payment-accounts"><CreditCard />Računi za plaćanje</Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            )}
          </SidebarMenu>
        </SidebarContent>
        <SidebarFooter className="p-2">
           <SidebarMenu>
            {auth.isAdmin && ( // Only Admin can see Settings
                <SidebarMenuItem>
                    <SidebarMenuButton asChild tooltip="Postavke">
                        <Link href="/admin/settings"><Settings />Postavke</Link>
                    </SidebarMenuButton>
                </SidebarMenuItem>
            )}
            <SidebarMenuItem>
                <SidebarMenuButton 
                  asChild={false} // Needs to be a button for onClick
                  tooltip="Odjava" 
                  onClick={() => {
                    auth.logout_DEV_ONLY();
                    router.push('/login');
                  }}
                >
                  <LogOut />Odjava
                </SidebarMenuButton>
            </SidebarMenuItem>
           </SidebarMenu>
        </SidebarFooter>
      </Sidebar>
      <SidebarInset>
        <header className="sticky top-0 z-40 flex h-14 items-center gap-4 border-b bg-background px-4 sm:static sm:h-auto sm:border-0 sm:bg-transparent sm:px-6 py-2">
            <SidebarTrigger className="sm:hidden"/>
            <div className="ml-auto flex items-center gap-2">
            <DropdownMenu>
                <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="icon" className="overflow-hidden rounded-full">
                        <Avatar>
                            <AvatarImage src="https://picsum.photos/40/40?random=admin" alt="Admin Avatar" data-ai-hint="administrator avatar" />
                            <AvatarFallback>{auth.role ? auth.role.substring(0,2).toUpperCase() : 'AD'}</AvatarFallback>
                        </Avatar>
                    </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                    <DropdownMenuLabel>{auth.isAdmin ? 'Admin' : 'Moderator'} račun</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    {auth.isAdmin && <DropdownMenuItem asChild><Link href="/admin/settings">Postavke</Link></DropdownMenuItem>}
                    <DropdownMenuItem>Podrška</DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => {
                        auth.logout_DEV_ONLY();
                        router.push('/login');
                    }}>
                        Odjava
                    </DropdownMenuItem>
                </DropdownMenuContent>
            </DropdownMenu>
            </div>
        </header>
        <main className="flex-1 p-4 sm:p-6 overflow-auto">
            {children}
        </main>
      </SidebarInset>
    </SidebarProvider>
  );
}
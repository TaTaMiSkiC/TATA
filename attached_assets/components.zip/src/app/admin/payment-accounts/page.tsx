
"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm, type SubmitHandler } from "react-hook-form";
import * as z from "zod";
import { useEffect, useState } from "react";
import Link from "next/link";
import { ArrowLeft, Loader2, Save } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import type { AdminPaymentSettings, BankAccountConfig, PayPalConfig } from "@/services/payment";
import { getAdminPaymentSettings, saveAdminPaymentSettings } from "@/services/payment";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/hooks/useAuth"; // Import useAuth
import { useRouter } from "next/navigation";

const paymentSettingsSchema = z.object({
  bank: z.object({
    bankName: z.string().optional(),
    accountHolder: z.string().optional(),
    iban: z.string().optional(),
    bic: z.string().optional(),
    active: z.boolean().default(false),
  }).optional(),
  paypal: z.object({
    email: z.string().email({ message: "Unesite važeću PayPal email adresu." }).optional().or(z.literal("")),
    active: z.boolean().default(false),
  }).optional(),
}).refine(data => {
    if (data.bank?.active) {
        return !!data.bank.bankName && !!data.bank.accountHolder && !!data.bank.iban && !!data.bank.bic;
    }
    return true;
}, {
    message: "Sva polja za bankovni račun su obavezna ako je bankovni transfer aktivan.",
    path: ["bank"],
})
.refine(data => {
    if (data.paypal?.active) {
        return !!data.paypal.email;
    }
    return true;
}, {
    message: "PayPal email adresa je obavezna ako je PayPal plaćanje aktivno.",
    path: ["paypal", "email"],
});


type PaymentSettingsFormData = z.infer<typeof paymentSettingsSchema>;

export default function PaymentAccountsPage() {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(true);
  const auth = useAuth();
  const router = useRouter();


  const form = useForm<PaymentSettingsFormData>({
    resolver: zodResolver(paymentSettingsSchema),
    defaultValues: {
      bank: {
        bankName: "",
        accountHolder: "",
        iban: "",
        bic: "",
        active: false,
      },
      paypal: {
        email: "",
        active: false,
      },
    },
  });

  useEffect(() => {
    if (!auth.isLoading && !auth.isAdmin) {
      router.push('/admin/dashboard'); // Redirect if not admin
      return;
    }

    async function fetchSettings() {
      if (auth.isAdmin) {
        setIsLoading(true);
        try {
          const settings = await getAdminPaymentSettings();
          if (settings) {
            form.reset({
              bank: settings.bank || { bankName: "", accountHolder: "", iban: "", bic: "", active: false },
              paypal: settings.paypal || { email: "", active: false },
            });
          }
        } catch (error) {
          console.error("Greška pri dohvaćanju postavki plaćanja:", error);
          toast({
            title: "Greška",
            description: "Nije uspjelo dohvaćanje postavki plaćanja.",
            variant: "destructive",
          });
        } finally {
          setIsLoading(false);
        }
      } else {
        setIsLoading(false); // Not admin, no need to load
      }
    }
    if (!auth.isLoading) {
       fetchSettings();
    }
  }, [form, toast, auth.isAdmin, auth.isLoading, router]);

  const onSubmit: SubmitHandler<PaymentSettingsFormData> = async (data) => {
    if (!auth.isAdmin) {
      toast({ title: "Neovlašteno", description: "Samo administratori mogu mijenjati ove postavke.", variant: "destructive"});
      return;
    }
    try {
      await saveAdminPaymentSettings(data as AdminPaymentSettings);
      toast({
        title: "Postavke spremljene",
        description: "Vaše postavke plaćanja su uspješno spremljene.",
      });
    } catch (error) {
      console.error("Greška pri spremanju postavki plaćanja:", error);
      toast({
        title: "Greška",
        description: "Nije uspjelo spremanje postavki. Molimo pokušajte ponovno.",
        variant: "destructive",
      });
    }
  };

  if (isLoading || auth.isLoading) {
    return (
      <div className="flex justify-center items-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="ml-2">Učitavanje postavki...</p>
      </div>
    );
  }

  if (!auth.isAdmin) {
     return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Računi za plaćanje</h1>
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Pristup odbijen</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">Nemate ovlasti za pristup ovoj stranici.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" asChild>
          <Link href="/admin/dashboard">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <h1 className="text-3xl font-bold">Računi za plaćanje</h1>
      </div>
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle>Konfiguracija metoda plaćanja</CardTitle>
          <CardDescription>
            Unesite podatke za bankovni račun i PayPal kako bi kupci mogli izvršiti uplatu.
            Ove informacije će biti prikazane kupcima na stranici s informacijama o plaćanju.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              
              {/* Bank Account Settings */}
              <section className="space-y-4 p-4 border rounded-md">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold">Bankovni Transfer</h2>
                  <FormField
                    control={form.control}
                    name="bank.active"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center space-x-2 space-y-0">
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <FormLabel className="font-normal">
                          Aktiviraj bankovni transfer
                        </FormLabel>
                      </FormItem>
                    )}
                  />
                </div>
                {form.watch("bank.active") && (
                  <div className="space-y-4 mt-4">
                    <FormField
                      control={form.control}
                      name="bank.bankName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Naziv banke</FormLabel>
                          <FormControl>
                            <Input placeholder="npr. Moja Banka d.d." {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="bank.accountHolder"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nositelj računa</FormLabel>
                          <FormControl>
                            <Input placeholder="npr. Pero Perić ili Naziv Tvrtke" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="bank.iban"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>IBAN</FormLabel>
                          <FormControl>
                            <Input placeholder="HR1234567890123456789" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="bank.bic"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>BIC/SWIFT</FormLabel>
                          <FormControl>
                            <Input placeholder="BANKHR2X" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                )}
                {form.formState.errors.bank && typeof form.formState.errors.bank === 'object' && !form.formState.errors.bank.root && (
                    <FormMessage>{form.formState.errors.bank.message}</FormMessage>
                 )}
              </section>

              <Separator />

              {/* PayPal Settings */}
              <section className="space-y-4 p-4 border rounded-md">
                 <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold">PayPal</h2>
                  <FormField
                    control={form.control}
                    name="paypal.active"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center space-x-2 space-y-0">
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <FormLabel className="font-normal">
                          Aktiviraj PayPal plaćanje
                        </FormLabel>
                      </FormItem>
                    )}
                  />
                </div>
                {form.watch("paypal.active") && (
                  <FormField
                    control={form.control}
                    name="paypal.email"
                    render={({ field }) => (
                      <FormItem className="mt-4">
                        <FormLabel>PayPal Email Adresa</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="vas.paypal@primjer.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}
              </section>

              <div className="flex justify-end pt-4">
                <Button type="submit" disabled={form.formState.isSubmitting}>
                  {form.formState.isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Spremanje...
                    </>
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" />
                      Spremi postavke
                    </>
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}

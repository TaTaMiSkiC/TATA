
"use client";

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { useForm, type SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { getProductById, updateProduct, getAllCategories } from '@/services/productService';
import { getAllFragrances } from '@/services/fragranceService';
import { getAllColors } from '@/services/colorService'; // Added color service
import type { Product, Category, Fragrance, ColorOption } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { useRouter, useParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { ArrowLeft, Loader2 } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';

const productSchema = z.object({
  name: z.string().min(3, "Naziv proizvoda mora imati najmanje 3 znaka."),
  description: z.string().min(10, "Opis mora imati najmanje 10 znakova."),
  price: z.coerce.number().positive("Cijena mora biti pozitivan broj."),
  categorySlug: z.string().min(1, "Odaberite kategoriju."),
  stock: z.coerce.number().int().min(0, "Zaliha ne može biti negativna."),
  imageUrl: z.string().url("Unesite važeći URL slike.").or(z.string().min(1, "URL slike je obavezan.")),
  hasSelectableFragrances: z.boolean().default(false),
  fragranceSelections: z.array(z.string()).optional(),
  hasSelectableColors: z.boolean().default(false), // New field
  colorSelections: z.array(z.string()).optional(), // New field
}).refine(data => {
  if (data.hasSelectableFragrances) {
    return data.fragranceSelections && data.fragranceSelections.length > 0;
  }
  return true;
}, {
  message: "Ako proizvod ima odabir mirisa, morate odabrati barem jedan miris.",
  path: ["fragranceSelections"],
}).refine(data => { // New refinement for colors
  if (data.hasSelectableColors) {
    return data.colorSelections && data.colorSelections.length > 0;
  }
  return true;
}, {
  message: "Ako proizvod ima odabir boje, morate odabrati barem jednu boju.",
  path: ["colorSelections"],
});

type ProductFormData = z.infer<typeof productSchema>;

export default function EditProductPage() {
  const { toast } = useToast();
  const router = useRouter();
  const params = useParams();
  const productId = params.id as string;
  const auth = useAuth();

  const [product, setProduct] = useState<Product | null>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [allFragrances, setAllFragrances] = useState<Fragrance[]>([]);
  const [allColors, setAllColors] = useState<ColorOption[]>([]); // New state for colors
  const [isLoading, setIsLoading] = useState(true);
  const [isLoadingCategories, setIsLoadingCategories] = useState(true);
  const [isLoadingFragrances, setIsLoadingFragrances] = useState(true);
  const [isLoadingColors, setIsLoadingColors] = useState(true); // New loading state for colors


  const form = useForm<ProductFormData>({
    resolver: zodResolver(productSchema),
    defaultValues: {
      name: "",
      description: "",
      price: 0,
      categorySlug: "",
      stock: 0,
      imageUrl: "",
      hasSelectableFragrances: false,
      fragranceSelections: [],
      hasSelectableColors: false, // Default for new field
      colorSelections: [], // Default for new field
    },
  });

  useEffect(() => {
    if (!auth.isLoading && !auth.isAdmin && !auth.isModerator) {
      router.push('/login'); 
      return;
    }

    const fetchInitialData = async () => {
      setIsLoadingCategories(true);
      setIsLoadingFragrances(true);
      setIsLoadingColors(true);
      try {
        const [fetchedCategories, fetchedFragrances, fetchedColors] = await Promise.all([
          getAllCategories(),
          getAllFragrances(),
          getAllColors()
        ]);
        setCategories(fetchedCategories);
        setAllFragrances(fetchedFragrances);
        setAllColors(fetchedColors);
      } catch (error) {
        console.error("Failed to fetch categories, fragrances or colors:", error);
        toast({ title: "Greška", description: "Nije uspjelo učitavanje kategorija, mirisa ili boja.", variant: "destructive" });
      } finally {
        setIsLoadingCategories(false);
        setIsLoadingFragrances(false);
        setIsLoadingColors(false);
      }
    };
    
    if(!auth.isLoading && (auth.isAdmin || auth.isModerator)) {
        fetchInitialData();
    } else if (!auth.isLoading) {
        setIsLoadingCategories(false);
        setIsLoadingFragrances(false);
        setIsLoadingColors(false);
    }

  }, [toast, auth.isAdmin, auth.isModerator, auth.isLoading, router]);

  useEffect(() => {
     if (!auth.isLoading && !auth.isAdmin && !auth.isModerator) {
      return;
    }
    if (productId && !auth.isLoading && (auth.isAdmin || auth.isModerator) && !isLoadingCategories && !isLoadingFragrances && !isLoadingColors) { 
      const fetchProduct = async () => {
        setIsLoading(true);
        try {
          const fetchedProduct = await getProductById(productId);
          if (fetchedProduct) {
            setProduct(fetchedProduct);
            form.reset({
              name: fetchedProduct.name,
              description: fetchedProduct.description,
              price: fetchedProduct.price,
              categorySlug: fetchedProduct.categorySlug,
              stock: fetchedProduct.stock,
              imageUrl: fetchedProduct.imageUrl,
              hasSelectableFragrances: !!(fetchedProduct.fragrances && fetchedProduct.fragrances.length > 0),
              fragranceSelections: fetchedProduct.fragrances || [],
              hasSelectableColors: !!(fetchedProduct.colorSelections && fetchedProduct.colorSelections.length > 0), // Set based on product data
              colorSelections: fetchedProduct.colorSelections || [], // Set based on product data
            });
          } else {
            toast({ title: "Greška", description: "Proizvod nije pronađen.", variant: "destructive" });
            router.push('/admin/products');
          }
        } catch (error) {
          console.error("Failed to fetch product:", error);
          toast({ title: "Greška", description: "Nije uspjelo učitavanje podataka o proizvodu.", variant: "destructive" });
        } finally {
          setIsLoading(false);
        }
      };
      fetchProduct();
    } else if (!auth.isLoading) {
        setIsLoading(false);
    }
  }, [productId, form, router, toast, auth.isAdmin, auth.isModerator, auth.isLoading, isLoadingCategories, isLoadingFragrances, isLoadingColors]);
  
  const onSubmit: SubmitHandler<ProductFormData> = async (data) => {
    if (!product) return;
    if (!auth.isAdmin && !auth.isModerator) {
        toast({ title: "Neovlašteno", description: "Nemate ovlasti za ovu akciju.", variant: "destructive"});
        return;
    }

    const { hasSelectableFragrances, fragranceSelections, hasSelectableColors, colorSelections, ...restOfData } = data;
    
    let productPrice = Number(restOfData.price);
    let productStock = Number(restOfData.stock);

    if (auth.isModerator && !auth.isAdmin) {
        if (productPrice !== product.price) {
             toast({ title: "Upozorenje", description: "Moderatori ne mogu mijenjati cijenu. Cijena nije ažurirana.", variant: "default"});
             productPrice = product.price;
        }
        if (productStock !== product.stock) {
            toast({ title: "Upozorenje", description: "Moderatori ne mogu mijenjati zalihu. Zaliha nije ažurirana.", variant: "default"});
            productStock = product.stock;
        }
    }
    
    const productPayload: Partial<Omit<Product, 'id'>> = {
      ...restOfData,
      price: productPrice,
      stock: productStock,
      fragrances: hasSelectableFragrances ? fragranceSelections : undefined,
      hasSelectableColors: hasSelectableColors,
      colorSelections: hasSelectableColors ? colorSelections : undefined,
    };


    try {
      const updated = await updateProduct(product.id, productPayload);
      toast({
        title: "Proizvod ažuriran",
        description: `Proizvod "${updated?.name}" je uspješno ažuriran.`,
      });
      router.push('/admin/products');
    } catch (error) {
      console.error("Failed to update product:", error);
      toast({
        title: "Greška",
        description: "Nije uspjelo ažuriranje proizvoda. Molimo pokušajte ponovno.",
        variant: "destructive",
      });
    }
  };

  const isLoadingInitialData = isLoading || isLoadingCategories || isLoadingFragrances || isLoadingColors || auth.isLoading;

  if (isLoadingInitialData) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="ml-2">Učitavanje {isLoading ? "detalja proizvoda" : isLoadingCategories ? "kategorija" : isLoadingFragrances ? "mirisa" : isLoadingColors ? "boja" : "autorizacije"}...</p>
      </div>
    );
  }

  if (!auth.isAdmin && !auth.isModerator) {
     return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Uredi proizvod</h1>
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Pristup odbijen</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">Nemate ovlasti za pristup ovoj stranici.</p>
             <Button onClick={() => router.push('/login')} className="mt-4">Prijava</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!product) {
     return <p>Proizvod nije pronađen.</p>; 
  }

  const canEditSensitiveFields = auth.isAdmin;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
         <Button variant="outline" size="icon" asChild>
            <Link href="/admin/products">
                <ArrowLeft className="h-4 w-4" />
            </Link>
        </Button>
        <h1 className="text-3xl font-bold">Uredi proizvod: {form.getValues('name')}</h1>
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle>Detalji proizvoda</CardTitle>
          <CardDescription>Ažurirajte informacije za ovaj proizvod.</CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Naziv proizvoda</FormLabel>
                    <FormControl>
                      <Input placeholder="npr., Mirisna svijeća Lavanda" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Opis</FormLabel>
                    <FormControl>
                      <Textarea rows={5} placeholder="Detaljan opis proizvoda..." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="price"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Cijena (€)</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.01" placeholder="npr., 19.99" {...field} disabled={!canEditSensitiveFields} />
                      </FormControl>
                      {!canEditSensitiveFields && <FormDescription>Samo administratori mogu mijenjati cijenu.</FormDescription>}
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="stock"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Zaliha</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="npr., 50" {...field} disabled={!canEditSensitiveFields} />
                      </FormControl>
                       {!canEditSensitiveFields && <FormDescription>Samo administratori mogu mijenjati zalihu.</FormDescription>}
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="categorySlug"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Kategorija</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value} disabled={isLoadingCategories}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder={isLoadingCategories ? "Učitavanje kategorija..." : "Odaberite kategoriju"} />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {isLoadingCategories ? (
                           <div className="flex items-center justify-center p-4">
                            <Loader2 className="h-5 w-5 animate-spin mr-2" /> Učitavanje...
                          </div>
                        ) : (
                          categories.map(category => (
                            <SelectItem key={category.slug} value={category.slug}>
                              {category.name}
                            </SelectItem>
                          ))
                        )}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="imageUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>URL Slike</FormLabel>
                    <FormControl>
                      <Input type="text" placeholder="https://primjer.com/slika.jpg" {...field} />
                    </FormControl>
                    <FormDescription>Unesite puni URL do slike proizvoda.</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="hasSelectableFragrances"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                    <div className="space-y-0.5">
                      <FormLabel>Proizvod ima odabir mirisa?</FormLabel>
                       <FormDescription>
                        Ako je uključeno, moći ćete odabrati dostupne mirise za ovaj proizvod.
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              {form.watch("hasSelectableFragrances") && (
                <FormField
                  control={form.control}
                  name="fragranceSelections"
                  render={({ field }) => (
                    <FormItem className="p-4 border rounded-md">
                      <FormLabel className="text-base font-semibold">Dostupni mirisi za ovaj proizvod</FormLabel>
                       <FormDescription>Odaberite jedan ili više mirisa koje kupci mogu izabrati.</FormDescription>
                      <FormControl>
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 mt-2">
                          {isLoadingFragrances ? (
                            <div className="col-span-full flex items-center justify-center p-4">
                              <Loader2 className="h-5 w-5 animate-spin mr-2" /> Učitavanje mirisa...
                            </div>
                           ) : allFragrances.length === 0 ? (
                             <p className="col-span-full text-muted-foreground">Nema definiranih mirisa. <Link href="/admin/fragrances/new" className="underline text-primary">Dodajte mirise</Link> prvo.</p>
                          ) : (
                            allFragrances.map((fragrance) => (
                              <FormItem key={fragrance.id} className="flex items-center space-x-2 p-2 border rounded-md hover:bg-muted/50">
                                <FormControl>
                                  <Checkbox
                                    id={`fragrance-${fragrance.id}`}
                                    checked={field.value?.includes(fragrance.name)}
                                    onCheckedChange={(checked) => {
                                      const currentSelections = field.value || [];
                                      if (checked) {
                                        field.onChange([...currentSelections, fragrance.name]);
                                      } else {
                                        field.onChange(currentSelections.filter(name => name !== fragrance.name));
                                      }
                                    }}
                                  />
                                </FormControl>
                                <FormLabel htmlFor={`fragrance-${fragrance.id}`} className="font-normal cursor-pointer flex-grow">
                                  {fragrance.name}
                                </FormLabel>
                              </FormItem>
                            ))
                          )}
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {/* New Color Selection Section */}
              <FormField
                control={form.control}
                name="hasSelectableColors"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                    <div className="space-y-0.5">
                      <FormLabel>Proizvod ima odabir boje?</FormLabel>
                      <FormDescription>
                        Ako je uključeno, moći ćete odabrati dostupne boje za ovaj proizvod. Ako ne, proizvod će imati standardnu boju.
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              {form.watch("hasSelectableColors") && (
                <FormField
                  control={form.control}
                  name="colorSelections"
                  render={({ field }) => (
                    <FormItem className="p-4 border rounded-md">
                      <FormLabel className="text-base font-semibold">Dostupne boje za ovaj proizvod</FormLabel>
                       <FormDescription>Odaberite jednu ili više boja koje kupci mogu izabrati.</FormDescription>
                      <FormControl>
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 mt-2">
                          {isLoadingColors ? (
                            <div className="col-span-full flex items-center justify-center p-4">
                              <Loader2 className="h-5 w-5 animate-spin mr-2" /> Učitavanje boja...
                            </div>
                          ) : allColors.length === 0 ? (
                             <p className="col-span-full text-muted-foreground">Nema definiranih boja. <Link href="/admin/colors/new" className="underline text-primary">Dodajte boje</Link> prvo.</p>
                          ) : (
                            allColors.map((color) => (
                              <FormItem key={color.id} className="flex items-center space-x-2 p-2 border rounded-md hover:bg-muted/50">
                                <FormControl>
                                  <Checkbox
                                    id={`color-${color.id}`}
                                    checked={field.value?.includes(color.name)}
                                    onCheckedChange={(checked) => {
                                      const currentSelections = field.value || [];
                                      if (checked) {
                                        field.onChange([...currentSelections, color.name]);
                                      } else {
                                        field.onChange(currentSelections.filter(name => name !== color.name));
                                      }
                                    }}
                                  />
                                </FormControl>
                                <FormLabel htmlFor={`color-${color.id}`} className="font-normal cursor-pointer flex-grow flex items-center">
                                  {color.hexCode && <span className="w-4 h-4 rounded-full mr-2 border" style={{ backgroundColor: color.hexCode }}></span>}
                                  {color.name}
                                </FormLabel>
                              </FormItem>
                            ))
                          )}
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}


              <div className="flex justify-end gap-2 pt-4">
                <Button type="button" variant="outline" onClick={() => router.back()}>
                  Odustani
                </Button>
                <Button type="submit" disabled={form.formState.isSubmitting || isLoadingCategories || isLoadingFragrances || isLoadingColors}>
                  {form.formState.isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Spremanje...
                    </>
                  ) : "Spremi promjene"}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}


"use client"; 

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { getAllProducts, deleteProduct } from "@/services/productService"; // Added deleteProduct
import type { Product } from "@/lib/types";
import Link from "next/link";
import Image from "next/image";
import { PlusCircle, Edit, Trash2, Loader2 } from "lucide-react"; 
import { Badge } from "@/components/ui/badge";
import { useEffect, useState } from "react"; 
import { useAuth } from "@/hooks/useAuth"; // Import useAuth
import { useToast } from "@/hooks/use-toast"; // Import useToast
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";


export default function AdminProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const auth = useAuth();
  const { toast } = useToast();
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);

  useEffect(() => {
    async function fetchData() {
      setIsLoading(true);
      try {
        const fetchedProducts = await getAllProducts();
        setProducts(fetchedProducts);
      } catch (error) {
        console.error("Failed to fetch products:", error);
        toast({ title: "Greška", description: "Nije uspjelo dohvaćanje proizvoda.", variant: "destructive" });
      } finally {
        setIsLoading(false);
      }
    }
    // Fetch data only if user is authorized (admin or moderator)
    if (!auth.isLoading && (auth.isAdmin || auth.isModerator)) {
      fetchData();
    } else if (!auth.isLoading) {
      setIsLoading(false); // Not authorized, stop loading
    }
  }, [auth.isLoading, auth.isAdmin, auth.isModerator, toast]);

  const handleDeleteProduct = async () => {
    if (!productToDelete) return;
    if (!auth.isAdmin && !auth.isModerator) {
      toast({ title: "Neovlašteno", description: "Nemate ovlasti za brisanje proizvoda.", variant: "destructive" });
      return;
    }

    try {
      await deleteProduct(productToDelete.id);
      setProducts(products.filter(p => p.id !== productToDelete.id));
      toast({ title: "Proizvod obrisan", description: `Proizvod "${productToDelete.name}" je uspješno obrisan.` });
    } catch (error) {
      console.error("Failed to delete product:", error);
      toast({ title: "Greška", description: "Nije uspjelo brisanje proizvoda.", variant: "destructive" });
    } finally {
      setProductToDelete(null);
    }
  };


  if (isLoading || auth.isLoading) {
    return (
      <div className="flex justify-center items-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="ml-2">Učitavanje proizvoda...</p>
      </div>
    );
  }

  if (!auth.isAdmin && !auth.isModerator) {
     return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Upravljanje proizvodima</h1>
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Pristup odbijen</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">Nemate ovlasti za pristup ovoj stranici.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Upravljanje proizvodima</h1>
        <Button asChild>
          <Link href="/admin/products/new">
            <PlusCircle className="mr-2 h-4 w-4" /> Dodaj novi proizvod
          </Link>
        </Button>
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle>Popis proizvoda</CardTitle>
          <CardDescription>Pregledajte, uredite ili obrišite proizvode.</CardDescription>
        </CardHeader>
        <CardContent>
          {products.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">Još nema proizvoda. Dodajte svoj prvi proizvod!</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="hidden w-[100px] sm:table-cell">Slika</TableHead>
                  <TableHead>Naziv</TableHead>
                  <TableHead>Kategorija</TableHead>
                  <TableHead className="hidden md:table-cell">Cijena</TableHead>
                  <TableHead className="hidden md:table-cell">Zaliha</TableHead>
                  <TableHead>
                    <span className="sr-only">Akcije</span>
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {products.map((product) => (
                  <TableRow key={product.id}>
                    <TableCell className="hidden sm:table-cell">
                      <Image
                        alt={product.name}
                        className="aspect-square rounded-md object-cover"
                        height="64"
                        src={product.imageUrl}
                        width="64"
                        data-ai-hint="svijeća minijatura"
                      />
                    </TableCell>
                    <TableCell className="font-medium">{product.name}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{product.categorySlug}</Badge>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">{product.price.toFixed(2)} €</TableCell> 
                    <TableCell className="hidden md:table-cell">{product.stock}</TableCell>
                    <TableCell>
                      <div className="flex items-center justify-end gap-2">
                        <Button variant="outline" size="icon" asChild title="Uredi proizvod">
                          <Link href={`/admin/products/edit/${product.id}`}>
                            <Edit className="h-4 w-4" />
                          </Link>
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                             <Button variant="destructive" size="icon" title="Obriši proizvod" onClick={() => setProductToDelete(product)}>
                                <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          {productToDelete && productToDelete.id === product.id && (
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Jeste li sigurni?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Ova akcija će trajno obrisati proizvod "{productToDelete.name}". Ne možete poništiti ovu radnju.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel onClick={() => setProductToDelete(null)}>Odustani</AlertDialogCancel>
                                <AlertDialogAction onClick={handleDeleteProduct}>Obriši</AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          )}
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}


"use client";

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useForm, type SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { getColorById, updateColor } from '@/services/colorService';
import type { ColorOption } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { useRouter, useParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { ArrowLeft, Loader2, Palette } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';

const colorSchema = z.object({
  name: z.string().min(2, "Naziv boje mora imati najmanje 2 znaka."),
  hexCode: z.string().regex(/^#([0-9a-fA-F]{3}){1,2}$/, "Unesite važeći hex kod (npr. #FF0000 ili #F00).").optional().or(z.literal("")),
  description: z.string().optional(),
});

type ColorFormData = z.infer<typeof colorSchema>;

export default function EditColorPage() {
  const { toast } = useToast();
  const router = useRouter();
  const params = useParams();
  const colorId = params.id as string;
  const auth = useAuth();

  const [color, setColor] = useState<ColorOption | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const form = useForm<ColorFormData>({
    resolver: zodResolver(colorSchema),
    defaultValues: { name: "", hexCode: "", description: "" },
  });

  useEffect(() => {
    if (!auth.isLoading && !auth.isAdmin && !auth.isModerator) {
      router.push('/login');
      return;
    }
    if (colorId && !auth.isLoading && (auth.isAdmin || auth.isModerator)) {
      const fetchColor = async () => {
        setIsLoading(true);
        try {
          const fetchedColor = await getColorById(colorId);
          if (fetchedColor) {
            setColor(fetchedColor);
            form.reset({
              name: fetchedColor.name,
              hexCode: fetchedColor.hexCode || "",
              description: fetchedColor.description || "",
            });
          } else {
            toast({ title: "Greška", description: "Boja nije pronađena.", variant: "destructive" });
            router.push('/admin/colors');
          }
        } catch (error) {
          console.error("Failed to fetch color:", error);
          toast({ title: "Greška", description: "Nije uspjelo učitavanje podataka o boji.", variant: "destructive" });
        } finally {
          setIsLoading(false);
        }
      };
      fetchColor();
    } else if (!auth.isLoading) {
      setIsLoading(false);
    }
  }, [colorId, form, router, toast, auth.isLoading, auth.isAdmin, auth.isModerator]);
  
  const onSubmit: SubmitHandler<ColorFormData> = async (data) => {
    if (!color) return;
    if (!auth.isAdmin && !auth.isModerator) {
      toast({ title: "Neovlašteno", description: "Nemate ovlasti za ovu akciju.", variant: "destructive"});
      return;
    }
    try {
      const updated = await updateColor(color.id, data);
      toast({
        title: "Boja ažurirana",
        description: `Boja "${updated?.name}" je uspješno ažurirana.`,
      });
      router.push('/admin/colors');
    } catch (error) {
      console.error("Failed to update color:", error);
      toast({
        title: "Greška",
        description: "Nije uspjelo ažuriranje boje. Molimo pokušajte ponovno.",
        variant: "destructive",
      });
    }
  };

  if (isLoading || auth.isLoading) {
    return (
      <div className="flex justify-center items-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="ml-2">Učitavanje detalja boje...</p>
      </div>
    );
  }
  
  if (!auth.isAdmin && !auth.isModerator) {
     return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Uredi boju</h1>
        <Card className="shadow-lg">
          <CardHeader><CardTitle>Pristup odbijen</CardTitle></CardHeader>
          <CardContent><p className="text-muted-foreground">Nemate ovlasti za pristup ovoj stranici.</p></CardContent>
        </Card>
      </div>
    );
  }

  if (!color) {
     return <p>Boja nije pronađena.</p>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
         <Button variant="outline" size="icon" asChild>
            <Link href="/admin/colors">
                <ArrowLeft className="h-4 w-4" />
            </Link>
        </Button>
        <h1 className="text-3xl font-bold flex items-center"><Palette className="mr-3 h-8 w-8"/>Uredi boju: {color.name}</h1>
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle>Detalji boje</CardTitle>
          <CardDescription>Ažurirajte informacije za ovu boju.</CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Naziv boje</FormLabel>
                    <FormControl>
                      <Input placeholder="npr., Crvena, Svijetlo plava" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="hexCode"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Hex kod (Opcionalno)</FormLabel>
                    <FormControl>
                      <Input placeholder="#FF0000" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Opis (Opcionalno)</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Kratki opis boje." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => router.back()}>
                  Odustani
                </Button>
                <Button type="submit" disabled={form.formState.isSubmitting}>
                  {form.formState.isSubmitting ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Spremanje...</> : "Spremi promjene"}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}


"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { getAllColors, deleteColor } from '@/services/colorService';
import type { ColorOption } from "@/lib/types";
import Link from "next/link";
import { PlusCircle, Edit, Trash2, Loader2, Palette } from "lucide-react";
import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from '@/hooks/useAuth';
import { useRouter } from "next/navigation";

export default function AdminColorsPage() {
  const [colors, setColors] = useState<ColorOption[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [colorToDelete, setColorToDelete] = useState<ColorOption | null>(null);
  const { toast } = useToast();
  const auth = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!auth.isLoading && !auth.isAdmin && !auth.isModerator) {
      router.push('/login');
      return;
    }
    async function fetchData() {
      setIsLoading(true);
      try {
        const fetchedColors = await getAllColors();
        setColors(fetchedColors);
      } catch (error) {
        console.error("Failed to fetch colors:", error);
        toast({ title: "Greška", description: "Nije uspjelo dohvaćanje boja.", variant: "destructive" });
      } finally {
        setIsLoading(false);
      }
    }
    if (!auth.isLoading && (auth.isAdmin || auth.isModerator)) {
      fetchData();
    } else if (!auth.isLoading) {
      setIsLoading(false);
    }
  }, [auth.isLoading, auth.isAdmin, auth.isModerator, toast, router]);

  const handleDeleteColor = async () => {
    if (!colorToDelete) return;
    if (!auth.isAdmin && !auth.isModerator) {
      toast({ title: "Neovlašteno", description: "Nemate ovlasti za brisanje boja.", variant: "destructive" });
      return;
    }

    try {
      await deleteColor(colorToDelete.id);
      setColors(colors.filter(c => c.id !== colorToDelete.id));
      toast({ title: "Boja obrisana", description: `Boja "${colorToDelete.name}" je uspješno obrisana.` });
    } catch (error) {
      console.error("Failed to delete color:", error);
      toast({ title: "Greška", description: "Nije uspjelo brisanje boje.", variant: "destructive" });
    } finally {
      setColorToDelete(null);
    }
  };

  if (isLoading || auth.isLoading) {
    return (
      <div className="flex justify-center items-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="ml-2">Učitavanje boja...</p>
      </div>
    );
  }

  if (!auth.isAdmin && !auth.isModerator) {
    return (
     <div className="space-y-6">
       <h1 className="text-3xl font-bold">Upravljanje bojama</h1>
       <Card className="shadow-lg">
         <CardHeader><CardTitle>Pristup odbijen</CardTitle></CardHeader>
         <CardContent><p className="text-muted-foreground">Nemate ovlasti za pristup ovoj stranici.</p></CardContent>
       </Card>
     </div>
   );
 }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold flex items-center"><Palette className="mr-3 h-8 w-8"/>Upravljanje bojama</h1>
        <Button asChild>
          <Link href="/admin/colors/new">
            <PlusCircle className="mr-2 h-4 w-4" /> Dodaj novu boju
          </Link>
        </Button>
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle>Popis boja</CardTitle>
          <CardDescription>Pregledajte, uredite ili obrišite dostupne boje za proizvode.</CardDescription>
        </CardHeader>
        <CardContent>
          {colors.length === 0 ? (
             <p className="text-center text-muted-foreground py-8">Još nema dodanih boja.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Naziv</TableHead>
                  <TableHead className="hidden md:table-cell">Hex kod</TableHead>
                  <TableHead className="hidden md:table-cell">Primjer</TableHead>
                  <TableHead className="hidden md:table-cell">Opis</TableHead>
                  <TableHead className="text-right">
                    <span className="sr-only">Akcije</span>
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {colors.map((color) => (
                  <TableRow key={color.id}>
                    <TableCell className="font-medium">{color.name}</TableCell>
                    <TableCell className="hidden md:table-cell font-mono">{color.hexCode || 'N/A'}</TableCell>
                    <TableCell className="hidden md:table-cell">
                      {color.hexCode && (
                        <div className="w-6 h-6 rounded-full border" style={{ backgroundColor: color.hexCode }} />
                      )}
                    </TableCell>
                    <TableCell className="hidden md:table-cell truncate max-w-xs">{color.description || 'N/A'}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button variant="outline" size="icon" asChild title="Uredi boju">
                          <Link href={`/admin/colors/edit/${color.id}`}>
                            <Edit className="h-4 w-4" />
                          </Link>
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                             <Button variant="destructive" size="icon" title="Obriši boju" onClick={() => setColorToDelete(color)}>
                                <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          {colorToDelete && colorToDelete.id === color.id && (
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Jeste li sigurni?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Ova akcija će trajno obrisati boju "{colorToDelete.name}". Ne možete poništiti ovu radnju.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel onClick={() => setColorToDelete(null)}>Odustani</AlertDialogCancel>
                                <AlertDialogAction onClick={handleDeleteColor}>Obriši</AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          )}
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}


"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { getAllFragrances, deleteFragrance } from "@/services/fragranceService";
import type { Fragrance } from "@/lib/types";
import Link from "next/link";
import { PlusCircle, Edit, Trash2, Loader2, SprayCan } from "lucide-react";
import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { useRouter } from "next/navigation";

export default function AdminFragrancesPage() {
  const [fragrances, setFragrances] = useState<Fragrance[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [fragranceToDelete, setFragranceToDelete] = useState<Fragrance | null>(null);
  const { toast } = useToast();
  const auth = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!auth.isLoading && !auth.isAdmin && !auth.isModerator) {
      router.push('/login');
      return;
    }
    async function fetchData() {
      setIsLoading(true);
      try {
        const fetchedFragrances = await getAllFragrances();
        setFragrances(fetchedFragrances);
      } catch (error) {
        console.error("Failed to fetch fragrances:", error);
        toast({ title: "Greška", description: "Nije uspjelo dohvaćanje mirisa.", variant: "destructive" });
      } finally {
        setIsLoading(false);
      }
    }
    if (!auth.isLoading && (auth.isAdmin || auth.isModerator)) {
      fetchData();
    } else if (!auth.isLoading) {
      setIsLoading(false);
    }
  }, [auth.isLoading, auth.isAdmin, auth.isModerator, toast, router]);

  const handleDeleteFragrance = async () => {
    if (!fragranceToDelete) return;
    if (!auth.isAdmin && !auth.isModerator) {
      toast({ title: "Neovlašteno", description: "Nemate ovlasti za brisanje mirisa.", variant: "destructive" });
      return;
    }

    try {
      await deleteFragrance(fragranceToDelete.id);
      setFragrances(fragrances.filter(f => f.id !== fragranceToDelete.id));
      toast({ title: "Miris obrisan", description: `Miris "${fragranceToDelete.name}" je uspješno obrisan.` });
    } catch (error) {
      console.error("Failed to delete fragrance:", error);
      toast({ title: "Greška", description: "Nije uspjelo brisanje mirisa.", variant: "destructive" });
    } finally {
      setFragranceToDelete(null);
    }
  };

  if (isLoading || auth.isLoading) {
    return (
      <div className="flex justify-center items-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="ml-2">Učitavanje mirisa...</p>
      </div>
    );
  }

  if (!auth.isAdmin && !auth.isModerator) {
    return (
     <div className="space-y-6">
       <h1 className="text-3xl font-bold">Upravljanje mirisima</h1>
       <Card className="shadow-lg">
         <CardHeader><CardTitle>Pristup odbijen</CardTitle></CardHeader>
         <CardContent><p className="text-muted-foreground">Nemate ovlasti za pristup ovoj stranici.</p></CardContent>
       </Card>
     </div>
   );
 }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold flex items-center"><SprayCan className="mr-3 h-8 w-8"/>Upravljanje mirisima</h1>
        <Button asChild>
          <Link href="/admin/fragrances/new">
            <PlusCircle className="mr-2 h-4 w-4" /> Dodaj novi miris
          </Link>
        </Button>
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle>Popis mirisa</CardTitle>
          <CardDescription>Pregledajte, uredite ili obrišite dostupne mirise za proizvode.</CardDescription>
        </CardHeader>
        <CardContent>
          {fragrances.length === 0 ? (
             <p className="text-center text-muted-foreground py-8">Još nema dodanih mirisa.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Naziv</TableHead>
                  <TableHead className="hidden md:table-cell">Opis</TableHead>
                  <TableHead className="text-right">
                    <span className="sr-only">Akcije</span>
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {fragrances.map((fragrance) => (
                  <TableRow key={fragrance.id}>
                    <TableCell className="font-medium">{fragrance.name}</TableCell>
                    <TableCell className="hidden md:table-cell truncate max-w-xs">{fragrance.description || 'N/A'}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button variant="outline" size="icon" asChild title="Uredi miris">
                          <Link href={`/admin/fragrances/edit/${fragrance.id}`}>
                            <Edit className="h-4 w-4" />
                          </Link>
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                             <Button variant="destructive" size="icon" title="Obriši miris" onClick={() => setFragranceToDelete(fragrance)}>
                                <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          {fragranceToDelete && fragranceToDelete.id === fragrance.id && (
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Jeste li sigurni?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Ova akcija će trajno obrisati miris "{fragranceToDelete.name}". Ne možete poništiti ovu radnju.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel onClick={() => setFragranceToDelete(null)}>Odustani</AlertDialogCancel>
                                <AlertDialogAction onClick={handleDeleteFragrance}>Obriši</AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          )}
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

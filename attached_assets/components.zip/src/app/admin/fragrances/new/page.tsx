
"use client";

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useForm, type SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { addFragrance } from '@/services/fragranceService';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { ArrowLeft, Loader2, SprayCan } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useEffect } from 'react';

const fragranceSchema = z.object({
  name: z.string().min(2, "Naziv mirisa mora imati najmanje 2 znaka."),
  description: z.string().optional(),
});

type FragranceFormData = z.infer<typeof fragranceSchema>;

export default function NewFragrancePage() {
  const { toast } = useToast();
  const router = useRouter();
  const auth = useAuth();

  const form = useForm<FragranceFormData>({
    resolver: zodResolver(fragranceSchema),
    defaultValues: {
      name: "",
      description: "",
    },
  });

  useEffect(() => {
    if (!auth.isLoading && !auth.isAdmin && !auth.isModerator) {
      router.push('/login');
    }
  }, [auth.isLoading, auth.isAdmin, auth.isModerator, router]);

  const onSubmit: SubmitHandler<FragranceFormData> = async (data) => {
     if (!auth.isAdmin && !auth.isModerator) {
      toast({ title: "Neovlašteno", description: "Nemate ovlasti za ovu akciju.", variant: "destructive"});
      return;
    }
    try {
      const newFragrance = await addFragrance(data);
      toast({
        title: "Miris kreiran",
        description: `Miris "${newFragrance.name}" je uspješno kreiran.`,
      });
      router.push('/admin/fragrances');
    } catch (error) {
      console.error("Failed to create fragrance:", error);
      toast({
        title: "Greška",
        description: "Nije uspjelo kreiranje mirisa. Molimo pokušajte ponovno.",
        variant: "destructive",
      });
    }
  };
  
  if (auth.isLoading) {
    return (
      <div className="flex justify-center items-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="ml-2">Učitavanje...</p>
      </div>
    );
  }

  if (!auth.isAdmin && !auth.isModerator) {
     return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Dodaj novi miris</h1>
        <Card className="shadow-lg">
          <CardHeader><CardTitle>Pristup odbijen</CardTitle></CardHeader>
          <CardContent><p className="text-muted-foreground">Nemate ovlasti za pristup ovoj stranici.</p></CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" asChild>
            <Link href="/admin/fragrances">
                <ArrowLeft className="h-4 w-4" />
            </Link>
        </Button>
        <h1 className="text-3xl font-bold flex items-center"><SprayCan className="mr-3 h-8 w-8"/>Dodaj novi miris</h1>
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle>Detalji mirisa</CardTitle>
          <CardDescription>Ispunite informacije za novi miris.</CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Naziv mirisa</FormLabel>
                    <FormControl>
                      <Input placeholder="npr., Vanilija, Lavanda" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Opis (Opcionalno)</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Kratki opis mirisa." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => router.back()}>
                  Odustani
                </Button>
                <Button type="submit" disabled={form.formState.isSubmitting}>
                  {form.formState.isSubmitting ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Kreiranje...</> : "Kreiraj miris"}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}

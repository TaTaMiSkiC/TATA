
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Package, Users, ListOrdered, DollarSign } from "lucide-react";

// Mock data - replace with actual data fetching
const stats = [
  { title: "Ukupno proizvoda", value: "150", icon: Package, change: "+5 ovaj tjedan" },
  { title: "Aktivni korisnici", value: "1,230", icon: Users, change: "+20 novih korisnika" },
  { title: "Narudžbe na čekanju", value: "25", icon: ListOrdered, change: "3 nove danas" },
  { title: "Ukupni prihod", value: "12,580 €", icon: DollarSign, change: "+500 € ovaj mjesec" },
];

export default function AdminDashboardPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Admin nadzorna ploča</h1>
      
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.title} className="shadow-lg">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
              <stat.icon className="h-5 w-5 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <p className="text-xs text-muted-foreground">{stat.change}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Nedavne prodaje</CardTitle>
            <CardDescription>Pregled najnovijih transakcija.</CardDescription>
          </CardHeader>
          <CardContent>
            {/* Placeholder for sales chart or list */}
            <div className="h-64 flex items-center justify-center bg-muted rounded-md">
              <p className="text-muted-foreground">Podaci o prodaji uskoro</p>
            </div>
          </CardContent>
        </Card>
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Top kategorije</CardTitle>
            <CardDescription>Najpopularnije kategorije proizvoda.</CardDescription>
          </CardHeader>
          <CardContent>
            {/* Placeholder for categories chart or list */}
            <div className="h-64 flex items-center justify-center bg-muted rounded-md">
              <p className="text-muted-foreground">Podaci o kategorijama uskoro</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

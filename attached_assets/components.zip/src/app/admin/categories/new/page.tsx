
"use client";

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useForm, type SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { addCategory } from '@/services/productService';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation'; // For redirection
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { ArrowLeft } from 'lucide-react';

const categorySchema = z.object({
  name: z.string().min(2, "Naziv kategorije mora imati najmanje 2 znaka."),
  description: z.string().optional(),
});

type CategoryFormData = z.infer<typeof categorySchema>;

export default function NewCategoryPage() {
  const { toast } = useToast();
  const router = useRouter();
  const form = useForm<CategoryFormData>({
    resolver: zodResolver(categorySchema),
    defaultValues: {
      name: "",
      description: "",
    },
  });

  const onSubmit: SubmitHandler<CategoryFormData> = async (data) => {
    try {
      const newCategory = await addCategory({ name: data.name, description: data.description });
      toast({
        title: "Kategorija kreirana",
        description: `Kategorija "${newCategory.name}" je uspješno kreirana.`,
      });
      router.push('/admin/categories'); // Redirect to categories list
    } catch (error) {
      console.error("Failed to create category:", error);
      toast({
        title: "Greška",
        description: "Nije uspjelo kreiranje kategorije. Molimo pokušajte ponovno.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" asChild>
            <Link href="/admin/categories">
                <ArrowLeft className="h-4 w-4" />
            </Link>
        </Button>
        <h1 className="text-3xl font-bold">Dodaj novu kategoriju</h1>
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle>Detalji kategorije</CardTitle>
          <CardDescription>Ispunite informacije za novu kategoriju.</CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Naziv kategorije</FormLabel>
                    <FormControl>
                      <Input placeholder="npr., Elektronika, Odjeća" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Opis (Opcionalno)</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Kratki opis kategorije." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => router.back()}>
                  Odustani
                </Button>
                <Button type="submit" disabled={form.formState.isSubmitting}>
                  {form.formState.isSubmitting ? "Kreiranje..." : "Kreiraj kategoriju"}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}

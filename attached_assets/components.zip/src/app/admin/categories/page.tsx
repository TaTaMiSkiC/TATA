
"use client"; // Added to make it a Client Component

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { getAllCategories } from "@/services/productService";
import type { Category } from "@/lib/types";
import Link from "next/link";
import { PlusCircle, Edit, Trash2, Loader2 } from "lucide-react"; // Added Loader2
import { useEffect, useState } from "react"; // Added useEffect and useState

export default function AdminCategoriesPage() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      setIsLoading(true);
      try {
        const fetchedCategories = await getAllCategories();
        setCategories(fetchedCategories);
      } catch (error) {
        console.error("Failed to fetch categories:", error);
        // Optionally, show a toast message here
      } finally {
        setIsLoading(false);
      }
    }
    fetchData();
  }, []);

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="ml-2">Učitavanje kategorija...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Upravljanje kategorijama</h1>
        <Button asChild>
          <Link href="/admin/categories/new">
            <PlusCircle className="mr-2 h-4 w-4" /> Dodaj novu kategoriju
          </Link>
        </Button>
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle>Popis kategorija</CardTitle>
          <CardDescription>Pregledajte, uredite ili obrišite kategorije proizvoda.</CardDescription>
        </CardHeader>
        <CardContent>
          {categories.length === 0 ? (
             <p className="text-center text-muted-foreground py-8">Još nema kategorija. Dodajte svoju prvu kategoriju!</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Naziv</TableHead>
                  <TableHead>Slug</TableHead>
                  <TableHead className="hidden md:table-cell">Opis</TableHead>
                  <TableHead>
                    <span className="sr-only">Akcije</span>
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {categories.map((category) => (
                  <TableRow key={category.id}>
                    <TableCell className="font-medium">{category.name}</TableCell>
                    <TableCell>{category.slug}</TableCell>
                    <TableCell className="hidden md:table-cell truncate max-w-xs">{category.description || 'N/A'}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Button variant="outline" size="icon" asChild title="Uredi kategoriju">
                          <Link href={`/admin/categories/edit/${category.id}`}>
                            <Edit className="h-4 w-4" />
                          </Link>
                        </Button>
                         {/* TODO: Implement delete functionality with confirmation */}
                        <Button variant="destructive" size="icon" title="Obriši kategoriju" onClick={() => alert('Funkcionalnost brisanja još nije implementirana.')}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

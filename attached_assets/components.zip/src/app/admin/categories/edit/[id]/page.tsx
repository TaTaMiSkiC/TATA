
"use client";

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useForm, type SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { getCategoryById, updateCategory } from '@/services/productService'; // Assuming getCategoryById exists
import type { Category } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { useRouter, useParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { ArrowLeft, Loader2 } from 'lucide-react';

const categorySchema = z.object({
  name: z.string().min(2, "Naziv kategorije mora imati najmanje 2 znaka."),
  slug: z.string().min(2, "Slug mora imati najmanje 2 znaka.").regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, "Slug mora biti malim slovima, alfanumerički s crticama."),
  description: z.string().optional(),
});

type CategoryFormData = z.infer<typeof categorySchema>;

export default function EditCategoryPage() {
  const { toast } = useToast();
  const router = useRouter();
  const params = useParams();
  const categoryId = params.id as string;

  const [category, setCategory] = useState<Category | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const form = useForm<CategoryFormData>({
    resolver: zodResolver(categorySchema),
    defaultValues: {
      name: "",
      slug: "",
      description: "",
    },
  });

  useEffect(() => {
    if (categoryId) {
      const fetchCategory = async () => {
        setIsLoading(true);
        try {
          const fetchedCategory = await getCategoryById(categoryId);
          if (fetchedCategory) {
            setCategory(fetchedCategory);
            form.reset({
              name: fetchedCategory.name,
              slug: fetchedCategory.slug,
              description: fetchedCategory.description || "",
            });
          } else {
            toast({ title: "Greška", description: "Kategorija nije pronađena.", variant: "destructive" });
            router.push('/admin/categories');
          }
        } catch (error) {
          console.error("Failed to fetch category:", error);
          toast({ title: "Greška", description: "Nije uspjelo učitavanje podataka o kategoriji.", variant: "destructive" });
        } finally {
          setIsLoading(false);
        }
      };
      fetchCategory();
    }
  }, [categoryId, form, router, toast]);
  
  const onSubmit: SubmitHandler<CategoryFormData> = async (data) => {
    if (!category) return;
    try {
      const updatedCategory = await updateCategory(category.id, data);
      toast({
        title: "Kategorija ažurirana",
        description: `Kategorija "${updatedCategory?.name}" je uspješno ažurirana.`,
      });
      router.push('/admin/categories');
    } catch (error) {
      console.error("Failed to update category:", error);
      toast({
        title: "Greška",
        description: "Nije uspjelo ažuriranje kategorije. Molimo pokušajte ponovno.",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="ml-2">Učitavanje detalja kategorije...</p>
      </div>
    );
  }

  if (!category) {
     return <p>Kategorija nije pronađena.</p>; // Should be handled by redirect in useEffect
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
         <Button variant="outline" size="icon" asChild>
            <Link href="/admin/categories">
                <ArrowLeft className="h-4 w-4" />
            </Link>
        </Button>
        <h1 className="text-3xl font-bold">Uredi kategoriju: {category.name}</h1>
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle>Detalji kategorije</CardTitle>
          <CardDescription>Ažurirajte informacije za ovu kategoriju.</CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Naziv kategorije</FormLabel>
                    <FormControl>
                      <Input placeholder="npr., Elektronika, Odjeća" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="slug"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Slug</FormLabel>
                    <FormControl>
                      <Input placeholder="npr., elektronika, ljetna-kolekcija" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Opis (Opcionalno)</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Kratki opis kategorije." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => router.back()}>
                  Odustani
                </Button>
                <Button type="submit" disabled={form.formState.isSubmitting}>
                  {form.formState.isSubmitting ? "Spremanje..." : "Spremi promjene"}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}

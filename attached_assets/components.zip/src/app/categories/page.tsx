
import { SiteHeader } from '@/components/layout/SiteHeader';
import { SiteFooter } from '@/components/layout/SiteFooter';
import { getAllCategories } from '@/services/productService';
import type { Category } from '@/lib/types';
import Link from 'next/link';
import Image from 'next/image';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from '@/components/ui/breadcrumb';

export default async function CategoriesPage() {
  const categories: Category[] = await getAllCategories();

  return (
    <div className="flex flex-col min-h-screen">
      <SiteHeader />
      <main className="flex-grow container mx-auto py-8 px-4">
        <Breadcrumb className="mb-8">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/">Početna</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>Sve kategorije</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
        <h1 className="text-3xl font-bold mb-8">Sve kategorije</h1>
        
        {categories.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">Nema pronađenih kategorija.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {categories.map((category) => (
              <Link key={category.id} href={`/category/${category.slug}`}>
                <Card className="hover:shadow-lg transition-shadow duration-300 group h-full flex flex-col">
                  <CardHeader className="p-0">
                    <div className="aspect-video relative w-full rounded-t-lg overflow-hidden">
                      <Image 
                        src={`https://picsum.photos/seed/catpage-${category.slug}/300/200`} 
                        alt={category.name}
                        fill
                        style={{objectFit: 'cover'}}
                        className="group-hover:scale-105 transition-transform duration-300"
                        data-ai-hint={`${category.name.split(' ')[0].toLowerCase()} svijeće`}
                      />
                    </div>
                  </CardHeader>
                  <CardContent className="p-4 text-center flex-grow flex flex-col justify-center">
                    <CardTitle className="text-xl group-hover:text-primary transition-colors">{category.name}</CardTitle>
                    {category.description && <p className="text-sm text-muted-foreground mt-2">{category.description}</p>}
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </main>
      <SiteFooter />
    </div>
  );
}


"use client"; 

import Image from 'next/image';
import { SiteHeader } from '@/components/layout/SiteHeader';
import { SiteFooter } from '@/components/layout/SiteFooter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { getProductById, getAllProducts } from '@/services/productService';
import type { Product } from '@/lib/types';
import { useParams } from 'next/navigation'; 
import { ShoppingCart, Star, MessageSquare, CheckCircle, Loader2, ChevronDown, Palette } from 'lucide-react'; // Added Palette
import { Separator } from '@/components/ui/separator';
import { ProductList } from '@/components/products/ProductList';
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from '@/components/ui/breadcrumb';
import { useCart } from '@/hooks/useCart'; 
import { useToast } from '@/hooks/use-toast'; 
import { useEffect, useState } from 'react'; 
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from '@/components/ui/label';
import Link from 'next/link';


export default function ProductPage() {
  const params = useParams();
  const productId = params.id as string;

  const [product, setProduct] = useState<Product | null>(null);
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedFragrance, setSelectedFragrance] = useState<string | undefined>(undefined);
  const [selectedColor, setSelectedColor] = useState<string | undefined>(undefined); // New state for selected color

  const { addItem } = useCart();
  const { toast } = useToast();

  useEffect(() => {
    if (productId) {
      const fetchProductData = async () => {
        setIsLoading(true);
        try {
          const fetchedProduct = await getProductById(productId);
          if (!fetchedProduct) {
            setProduct(null); 
          } else {
            setProduct(fetchedProduct);
            // Optionally pre-select if only one option or based on some logic
            // if (fetchedProduct.fragrances && fetchedProduct.fragrances.length > 0) {
            //   setSelectedFragrance(fetchedProduct.fragrances[0]); 
            // }
            // if (fetchedProduct.colorSelections && fetchedProduct.colorSelections.length > 0) {
            //    setSelectedColor(fetchedProduct.colorSelections[0]);
            // }
            const allProducts = await getAllProducts();
            const fetchedRelatedProducts = allProducts
              .filter(p => p.categorySlug === fetchedProduct.categorySlug && p.id !== fetchedProduct.id)
              .slice(0, 4);
            setRelatedProducts(fetchedRelatedProducts);
          }
        } catch (error) {
          console.error("Failed to fetch product data:", error);
        } finally {
          setIsLoading(false);
        }
      };
      fetchProductData();
    }
  }, [productId]);

  const handleAddToCart = () => {
    if (product) {
      if (product.fragrances && product.fragrances.length > 0 && !selectedFragrance) {
        toast({
          title: "Odaberite miris",
          description: "Molimo odaberite miris prije dodavanja u košaricu.",
          variant: "destructive",
        });
        return;
      }
      if (product.hasSelectableColors && product.colorSelections && product.colorSelections.length > 0 && !selectedColor) {
        toast({
          title: "Odaberite boju",
          description: "Molimo odaberite boju prije dodavanja u košaricu.",
          variant: "destructive",
        });
        return;
      }
      addItem(product, 1, selectedFragrance, selectedColor); // Pass selectedColor
      toast({
        title: "Proizvod dodan u košaricu",
        description: `${product.name} ${selectedFragrance ? `(${selectedFragrance})` : ''} ${selectedColor ? `(${selectedColor})` : ''} je dodan u vašu košaricu.`,
      });
    }
  };
  
  if (isLoading) {
    return (
      <div className="flex flex-col min-h-screen">
        <SiteHeader />
        <main className="flex-grow container mx-auto py-8 px-4 flex items-center justify-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
          <p className="ml-4 text-lg">Učitavanje proizvoda...</p>
        </main>
        <SiteFooter />
      </div>
    );
  }

  if (!product) {
    return (
       <div className="flex flex-col min-h-screen">
        <SiteHeader />
        <main className="flex-grow container mx-auto py-8 px-4 text-center">
             <h1 className="text-2xl font-bold mb-4">Proizvod nije pronađen</h1>
             <p className="text-muted-foreground mb-6">Traženi proizvod nije dostupan.</p>
             <Button asChild>
                <Link href="/products">Natrag na proizvode</Link>
             </Button>
        </main>
        <SiteFooter />
      </div>
    );
  }

  const isFragranceRequired = product.fragrances && product.fragrances.length > 0;
  const isColorRequired = product.hasSelectableColors && product.colorSelections && product.colorSelections.length > 0;

  const isAddToCartDisabled = product.stock === 0 ||
    (isFragranceRequired && !selectedFragrance) ||
    (isColorRequired && !selectedColor);


  return (
    <div className="flex flex-col min-h-screen">
      <SiteHeader />
      <main className="flex-grow container mx-auto py-8 px-4">
        <Breadcrumb className="mb-8">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/">Početna</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbLink href="/products">Proizvodi</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
             <BreadcrumbItem>
              <BreadcrumbLink href={`/category/${product.categorySlug}`}>{product.categorySlug.charAt(0).toUpperCase() + product.categorySlug.slice(1)}</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>{product.name}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
          <Card className="overflow-hidden shadow-lg">
            <div className="aspect-square relative w-full">
              <Image
                src={product.imageUrl}
                alt={product.name}
                fill
                sizes="(max-width: 768px) 100vw, 50vw"
                className="object-cover"
                priority 
                data-ai-hint="svijeća detalj"
              />
            </div>
          </Card>
          
          <div className="flex flex-col">
            <Card>
              <CardHeader>
                <CardTitle className="text-3xl font-bold">{product.name}</CardTitle>
                <div className="flex items-center gap-2 text-sm text-muted-foreground mt-2">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className={`h-4 w-4 ${i < 4 ? 'text-accent fill-accent' : 'text-muted-foreground'}`} />
                    ))}
                  </div>
                  <span>(123 Ocjena)</span> 
                  <Separator orientation="vertical" className="h-4" />
                  <Link href={`/category/${product.categorySlug}`} className="hover:text-primary">
                    {product.categorySlug.charAt(0).toUpperCase() + product.categorySlug.slice(1)}
                  </Link>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <CardDescription className="text-base leading-relaxed">{product.description}</CardDescription>
                
                {isFragranceRequired && (
                  <div className="space-y-2">
                    <Label htmlFor="fragrance-select" className="text-base">Odaberite miris:</Label>
                    <Select onValueChange={setSelectedFragrance} value={selectedFragrance}>
                      <SelectTrigger id="fragrance-select" className="w-full sm:w-[250px]">
                        <SelectValue placeholder="Odaberi miris..." />
                      </SelectTrigger>
                      <SelectContent>
                        {product.fragrances!.map((fragrance) => (
                          <SelectItem key={fragrance} value={fragrance}>
                            {fragrance}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {isColorRequired && (
                  <div className="space-y-2">
                    <Label htmlFor="color-select" className="text-base flex items-center">
                      <Palette className="mr-2 h-5 w-5" />
                      Odaberite boju:
                    </Label>
                    <Select onValueChange={setSelectedColor} value={selectedColor}>
                      <SelectTrigger id="color-select" className="w-full sm:w-[250px]">
                        <SelectValue placeholder="Odaberi boju..." />
                      </SelectTrigger>
                      <SelectContent>
                        {product.colorSelections!.map((colorName) => (
                          <SelectItem key={colorName} value={colorName}>
                            {colorName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}


                <p className="text-4xl font-bold text-primary">{product.price.toFixed(2)} €</p>
                {product.stock > 0 ? (
                    <div className="flex items-center text-green-600">
                        <CheckCircle className="h-5 w-5 mr-2" />
                        <span>Na zalihi ({product.stock} dostupno)</span>
                    </div>
                ) : (
                    <p className="text-red-600 font-semibold">Nema na zalihi</p>
                )}
              </CardContent>
              <CardFooter className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  className="w-full sm:w-auto flex-grow bg-accent text-accent-foreground hover:bg-accent/90" 
                  onClick={handleAddToCart}
                  disabled={isAddToCartDisabled}
                >
                  <ShoppingCart className="mr-2 h-5 w-5" />
                   {product.stock === 0 ? "Nema na zalihi" : "Dodaj u košaricu"}
                </Button>
                <Button size="lg" variant="outline" className="w-full sm:w-auto flex-grow">
                  <MessageSquare className="mr-2 h-5 w-5" />
                  Postavi pitanje
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
        
        {relatedProducts.length > 0 && (
            <section className="mt-16">
                <h2 className="text-2xl font-bold mb-6">Slični proizvodi</h2>
                <ProductList products={relatedProducts} />
            </section>
        )}

      </main>
      <SiteFooter />
    </div>
  );
}

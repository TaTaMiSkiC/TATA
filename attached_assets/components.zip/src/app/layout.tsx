
import type { Metadata } from 'next';
import { GeistSans } from 'geist/font/sans';
import './globals.css';
import { Toaster } from "@/components/ui/toaster";
import { APP_NAME } from '@/lib/constants';
import { ThemeProvider } from '@/components/ThemeProvider';
import { CartProvider } from '@/hooks/useCart'; 

const geistSans = GeistSans;

export const metadata: Metadata = {
  title: `${APP_NAME} by Dani`, // Changed to Dani
  description: `${APP_NAME} by Dani - Vaš svijet jedinstvenih, ručno izrađenih svijeća.`, // Changed to Dani
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="hr" className={`${geistSans.variable}`} suppressHydrationWarning>
      <body className="font-sans antialiased">
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <CartProvider>
            {children}
          </CartProvider>
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}


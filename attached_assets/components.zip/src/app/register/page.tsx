
"use client";

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { APP_NAME } from '@/lib/constants';
import { SiteHeader } from '@/components/layout/SiteHeader';
import { SiteFooter } from '@/components/layout/SiteFooter';
import { ArrowLeft, UserPlus, Loader2 } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import * as z from "zod";
import { useForm, type SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';


const registerSchema = z.object({
  name: z.string().min(2, "Ime mora imati najmanje 2 znaka."),
  email: z.string().email("Unesite valjanu email adresu."),
  password: z.string().min(6, "Lozinka mora imati najmanje 6 znakova."),
  confirmPassword: z.string().min(6, "Potvrda lozinke mora imati najmanje 6 znakova."),
  terms: z.boolean().refine(value => value === true, {
    message: "Morate prihvatiti uvjete korištenja."
  })
}).refine(data => data.password === data.confirmPassword, {
  message: "Lozinke se ne podudaraju.",
  path: ["confirmPassword"], // Path of the error
});

type RegisterFormData = z.infer<typeof registerSchema>;


export default function RegisterPage() {
  const auth = useAuth();
  const router = useRouter();
  const { toast } = useToast();
  const [isRegistering, setIsRegistering] = useState(false);

  const form = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      name: "",
      email: "",
      password: "",
      confirmPassword: "",
      terms: false,
    },
  });


  const onSubmit: SubmitHandler<RegisterFormData> = async (data) => {
    setIsRegistering(true);
    try {
      await auth.register_DEV_ONLY({
        name: data.name,
        email: data.email,
        password: data.password,
        // Default role 'korisnik' is handled in useAuth.register_DEV_ONLY
      });
      toast({
        title: "Registracija uspješna",
        description: "Vaš račun je kreiran. Sada se možete prijaviti.",
      });
      router.push('/login');
    } catch (error: any) {
      console.error("Registration error:", error);
      toast({
        title: "Greška pri registraciji",
        description: error.message || "Došlo je do pogreške. Molimo pokušajte ponovno.",
        variant: "destructive",
      });
    } finally {
      setIsRegistering(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      <SiteHeader />
      <main className="flex-grow flex items-center justify-center py-12 px-4">
        <div className="w-full max-w-md space-y-8">
          <Button variant="ghost" asChild className="mb-4">
            <Link href="/">
              <ArrowLeft className="mr-2 h-4 w-4" /> Natrag na početnu
            </Link>
          </Button>
          <Card className="shadow-xl">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl font-bold text-primary">{APP_NAME}</CardTitle>
              <CardDescription>Kreirajte svoj račun</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Puno ime</FormLabel>
                        <FormControl>
                          <Input placeholder="Vaše ime" {...field} disabled={isRegistering} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email adresa</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="vas@primjer.com" {...field} disabled={isRegistering} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Lozinka</FormLabel>
                        <FormControl>
                          <Input type="password" {...field} disabled={isRegistering} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="confirmPassword"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Potvrdite lozinku</FormLabel>
                        <FormControl>
                          <Input type="password" {...field} disabled={isRegistering} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="terms"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                           <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            disabled={isRegistering}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel className="font-normal">
                            Slažem se s{' '}
                            <Link href="/terms" className="underline hover:text-primary">
                              uvjetima korištenja
                            </Link>
                          </FormLabel>
                           <FormMessage />
                        </div>
                      </FormItem>
                    )}
                  />
                  <Button type="submit" className="w-full bg-primary hover:bg-primary/90" disabled={isRegistering}>
                    {isRegistering ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UserPlus className="mr-2 h-4 w-4" />}
                    {isRegistering ? "Kreiranje..." : "Kreiraj račun"}
                  </Button>
                </form>
              </Form>
            </CardContent>
            <CardFooter className="flex flex-col items-center">
              <p className="text-sm text-muted-foreground">
                Već imate račun?{' '}
                <Link href="/login" passHref>
                   <Button variant="link" className="text-primary px-1" disabled={isRegistering}>Prijavite se</Button>
                </Link>
              </p>
            </CardFooter>
          </Card>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}


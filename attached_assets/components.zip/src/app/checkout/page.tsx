
"use client";

import { useEffect, useState, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';
import { useForm, type SubmitHandler, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';

import { SiteHeader } from '@/components/layout/SiteHeader';
import { SiteFooter } from '@/components/layout/SiteFooter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Separator } from '@/components/ui/separator';
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from '@/components/ui/breadcrumb';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useCart, type CartItem } from '@/hooks/useCart'; // Import CartItem from useCart
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import type { PaymentDetails, BankAccountConfig, PayPalConfig, AdminPaymentSettings } from '@/services/payment';
import { getPaymentMethods, getAdminPaymentSettings } from '@/services/payment';
import { createOrder } from '@/services/orderService';
import type { User } from '@/lib/types'; 
import { getUserById } from '@/services/userService';
import { APP_NAME } from '@/lib/constants';

import { Loader2, ShoppingCart, CreditCard, Landmark, ArrowLeft, ShieldCheck, Palette } from 'lucide-react'; // Added Palette

const checkoutSchema = z.object({
  name: z.string().min(2, "Ime i prezime su obavezni."),
  email: z.string().email("Unesite važeću email adresu."),
  address: z.string().min(5, "Adresa je obavezna."),
  city: z.string().min(2, "Grad je obavezan."),
  postalCode: z.string().regex(/^\d{5}$/, "Unesite važeći poštanski broj (npr. 10000)."),
  phone: z.string().min(5, "Broj telefona je obavezan.").regex(/^(\+?\d{1,3}[- ]?)?\d{9,}$/, "Unesite važeći broj telefona."),
  paymentMethod: z.string().min(1, "Odaberite način plaćanja."),
  notes: z.string().optional(),
});

type CheckoutFormData = z.infer<typeof checkoutSchema>;

function CheckoutPageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { items: cartItems, totalPrice, totalItems, clearCart } = useCart();
  const { toast } = useToast();
  const auth = useAuth();

  const [paymentOptions, setPaymentOptions] = useState<string[]>([]);
  const [paypalConfig, setPaypalConfig] = useState<PayPalConfig | null>(null);
  const [isLoadingPayment, setIsLoadingPayment] = useState(true);
  const [isSubmittingOrder, setIsSubmittingOrder] = useState(false);
  const [isClient, setIsClient] = useState(false);


  const form = useForm<CheckoutFormData>({
    resolver: zodResolver(checkoutSchema),
    defaultValues: {
      name: '',
      email: '',
      address: '',
      city: '',
      postalCode: '',
      phone: '',
      paymentMethod: '',
      notes: '',
    },
  });

  useEffect(() => {
    setIsClient(true);
  }, []);

  useEffect(() => {
    if (isClient && totalItems === 0 && !isSubmittingOrder && !searchParams.has('orderId') ) { 
      toast({ title: "Košarica je prazna", description: "Molimo dodajte proizvode u košaricu.", variant: "default" });
      router.push('/cart');
    }
  }, [isClient, totalItems, router, toast, isSubmittingOrder, searchParams]);

  useEffect(() => {
    const fetchPaymentData = async () => {
      setIsLoadingPayment(true);
      try {
        const paymentMethodsDetails = await getPaymentMethods();
        setPaymentOptions(paymentMethodsDetails.paymentMethods);
        
        const adminSettings = await getAdminPaymentSettings();
        if (adminSettings?.paypal?.active) {
          setPaypalConfig(adminSettings.paypal);
        }
      } catch (error) {
        console.error("Greška pri dohvaćanju načina plaćanja:", error);
        toast({ title: "Greška", description: "Nije moguće učitati načine plaćanja.", variant: "destructive" });
      } finally {
        setIsLoadingPayment(false);
      }
    };
    fetchPaymentData();
  }, [toast]);

 useEffect(() => {
    if (auth.isLoggedIn && auth.userId) {
      const fetchUserDetails = async () => {
        try {
          const user = await getUserById(auth.userId!);
          if (user) {
            form.reset({
              name: user.name || '',
              email: user.email || '',
              address: user.address?.split(',')[0]?.trim() || '', 
              city: user.address?.split(',')[1]?.trim() || '',
              postalCode: user.address?.match(/\d{5}/)?.[0] || '',
              phone: user.phone || '',
              paymentMethod: form.getValues('paymentMethod') || '', 
              notes: form.getValues('notes') || '',
            });
          }
        } catch (error) {
          console.error("Error fetching user details for form prefill:", error);
        }
      };
      fetchUserDetails();
    } else if (auth.userEmail) { 
        form.setValue('email', auth.userEmail);
    }
  }, [auth.isLoggedIn, auth.userId, auth.userEmail, form]);

  useEffect(() => {
    const paymentStatus = searchParams.get('payment_status');
    const cancelledOrderId = searchParams.get('orderId');
  
    if (paymentStatus === 'cancelled' && cancelledOrderId) {
      toast({
        title: "Plaćanje otkazano",
        description: `Plaćanje za narudžbu #${cancelledOrderId} je otkazano. Možete pokušati ponovno ili odabrati drugi način plaćanja.`,
        variant: "default",
      });
      const newSearchParams = new URLSearchParams(searchParams.toString());
      newSearchParams.delete('payment_status');
      newSearchParams.delete('orderId');
      router.replace(`/checkout?${newSearchParams.toString()}`, { scroll: false });
    }
  }, [searchParams, router, toast]);


  const onSubmit: SubmitHandler<CheckoutFormData> = async (data) => {
    setIsSubmittingOrder(true);
    try {
      const newOrder = await createOrder({
        userId: auth.userId || 'guest',
        customerName: data.name,
        customerEmail: data.email,
        items: cartItems, 
        totalAmount: totalPrice,
        shippingAddress: `${data.address}, ${data.postalCode} ${data.city}`,
        paymentMethod: data.paymentMethod,
        notes: data.notes,
      });

      if (data.paymentMethod === 'PayPal' && paypalConfig?.email) {
        const paypalBaseUrl = "https://www.sandbox.paypal.com/cgi-bin/webscr"; 
        const params = new URLSearchParams({
          cmd: '_xclick', 
          business: paypalConfig.email,
          item_name: `Narudžba ${newOrder.id} - ${APP_NAME}`,
          amount: totalPrice.toFixed(2),
          currency_code: 'EUR',
          return: `${window.location.origin}/order-confirmation?orderId=${newOrder.id}&payment_status=success`,
          cancel_return: `${window.location.origin}/checkout?orderId=${newOrder.id}&payment_status=cancelled`,
        });
        window.location.href = `${paypalBaseUrl}?${params.toString()}`;
        return; 
      }

      toast({
        title: "Narudžba uspješno kreirana!",
        description: `Vaša narudžba #${newOrder.id} je zaprimljena.`,
      });
      clearCart(); 
      router.push(`/order-confirmation?orderId=${newOrder.id}`);

    } catch (error) {
      console.error("Greška pri kreiranju narudžbe:", error);
      toast({ title: "Greška", description: "Nije uspjelo kreiranje narudžbe. Molimo pokušajte ponovno.", variant: "destructive" });
      setIsSubmittingOrder(false); 
    } 
  };

  if (!isClient || (totalItems === 0 && !isSubmittingOrder && !searchParams.has('orderId'))) {
    return (
        <div className="flex flex-col min-h-screen">
            <SiteHeader />
            <main className="flex-grow flex items-center justify-center">
                <Loader2 className="h-12 w-12 animate-spin text-primary" />
            </main>
            <SiteFooter />
        </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen">
      <SiteHeader />
      <main className="flex-grow container mx-auto py-8 px-4">
        <Breadcrumb className="mb-8">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/">Početna</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbLink href="/cart">Košarica</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>Naplata</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        <h1 className="text-3xl font-bold mb-8">Naplata</h1>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="grid md:grid-cols-3 gap-8">
            <section className="md:col-span-2 space-y-6">
              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle>Podaci za dostavu</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Ime i prezime</FormLabel>
                        <FormControl>
                          <Input placeholder="Vaše ime i prezime" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email adresa</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="vaš@email.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="address"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Ulica i kućni broj</FormLabel>
                        <FormControl>
                          <Input placeholder="Primjer ulica 123" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="city"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Grad</FormLabel>
                          <FormControl>
                            <Input placeholder="Npr. Zagreb" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="postalCode"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Poštanski broj</FormLabel>
                          <FormControl>
                            <Input placeholder="Npr. 10000" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Broj telefona</FormLabel>
                        <FormControl>
                          <Input type="tel" placeholder="Npr. 0912345678" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                   <FormField
                    control={form.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Napomene za narudžbu (opcionalno)</FormLabel>
                        <FormControl>
                          <Input placeholder="Npr. Ostaviti paket kod susjeda." {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>

              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle>Način plaćanja</CardTitle>
                </CardHeader>
                <CardContent>
                  {isLoadingPayment ? (
                    <div className="flex items-center justify-center py-4">
                      <Loader2 className="h-6 w-6 animate-spin text-primary" />
                      <p className="ml-2">Učitavanje načina plaćanja...</p>
                    </div>
                  ) : !paymentOptions || paymentOptions.length === 0 ? (
                    <p>Nema dostupnih načina plaćanja.</p>
                  ) : (
                    <FormField
                      control={form.control}
                      name="paymentMethod"
                      render={({ field }) => (
                        <FormItem className="space-y-3">
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex flex-col space-y-2"
                            >
                              {paymentOptions.map((method) => (
                                <FormItem key={method} className="flex items-center space-x-3 space-y-0 p-3 border rounded-md hover:bg-muted/50 transition-colors">
                                  <FormControl>
                                    <RadioGroupItem value={method} />
                                  </FormControl>
                                  <FormLabel className="font-normal flex items-center cursor-pointer w-full">
                                    {method === 'Bankovni Transfer' && <Landmark className="mr-2 h-5 w-5 text-primary" />}
                                    {method === 'PayPal' && <svg className="mr-2 h-5 w-5 text-primary" role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><title>PayPal</title><path fill="currentColor" d="M7.058 20.999h3.08l.474-2.844c.12-.76.509-1.424.888-1.813.4-.408.95-.712 1.64-.897.69-.19 1.49-.288 2.39-.288 1.89 0 3.1.336 3.81 1.01.69.66.99 1.62.89 2.88-.06 1.08-.53 1.95-1.43 2.62-.89.68-2.06 1.01-3.52 1.01h-.95c-.12 0-.18.02-.18.05 0 .03.01.1.04.2l.68 4.09h-3.29l-1.37-8.237H5.318L4.01 23.999H.727l2.12-12.73H6.73c.39.01.63.05.7.11.08.07.12.26.12.58L7.059 21zm16.17-11.6l-.447 2.75c-.11.75-.5 1.41-.88 1.8-.39.4-.94.71-1.63.9-.69.18-1.48.28-2.38.28-1.89 0-3.1-.33-3.82-1-.69-.67-.99-1.62-.89-2.88.07-1.08.53-1.95 1.43-2.62.9-.68 2.06-1.01 3.52-1.01h.95c.12 0 .18-.02.18-.05s-.01-.1-.04-.2L18.361.05h3.29l-.78 4.69h3.35l-.712 4.26h-3.35z"/></svg>}
                                    {method === 'Pouzeće' && <ShoppingCart className="mr-2 h-5 w-5 text-primary" />} 
                                    {method}
                                  </FormLabel>
                                </FormItem>
                              ))}
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                           <FormDescription>
                            Za detalje o Bankovnom transferu i PayPal-u, posjetite našu <Link href="/payment-info" className="underline hover:text-primary">stranicu s informacijama o plaćanju</Link>.
                          </FormDescription>
                        </FormItem>
                      )}
                    />
                  )}
                </CardContent>
              </Card>
            </section>

            <aside className="md:col-span-1">
              <Card className="shadow-lg sticky top-20">
                <CardHeader>
                  <CardTitle>Sažetak narudžbe</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {cartItems.map((item: CartItem) => ( 
                    <div key={`${item.id}-${item.selectedFragrance || 'default'}-${item.selectedColor || 'default'}`} className="flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        <Image src={item.imageUrl} alt={item.name} width={40} height={40} className="rounded" data-ai-hint="svijeća minijatura"/>
                        <div>
                            <span className="text-sm">{item.name}</span>
                            {item.selectedFragrance && <span className="text-xs text-muted-foreground block">Miris: {item.selectedFragrance}</span>}
                            {item.selectedColor && <span className="text-xs text-muted-foreground block">Boja: {item.selectedColor}</span>} {/* Display selected color */}
                            <span className="text-xs text-muted-foreground block"> (x{item.quantity})</span>
                        </div>
                      </div>
                      <span className="text-sm font-medium">{(item.price * item.quantity).toFixed(2)} €</span>
                    </div>
                  ))}
                  <Separator />
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Međuzbroj:</span>
                    <span>{totalPrice.toFixed(2)} €</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Dostava:</span>
                    <span>Besplatna</span> 
                  </div>
                  <Separator />
                  <div className="flex justify-between text-lg font-bold">
                    <span>Ukupno:</span>
                    <span>{totalPrice.toFixed(2)} €</span>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button type="submit" className="w-full" size="lg" disabled={isSubmittingOrder || isLoadingPayment || totalItems === 0 || !form.formState.isValid}>
                    {isSubmittingOrder ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <ShieldCheck className="mr-2 h-4 w-4" />
                    )}
                    {isSubmittingOrder ? "Slanje narudžbe..." : "Naruči"}
                  </Button>
                </CardFooter>
              </Card>
            </aside>
          </form>
        </Form>
      </main>
      <SiteFooter />
    </div>
  );
}


export default function CheckoutPage() {
  return (
    <Suspense fallback={
      <div className="flex flex-col min-h-screen">
        <SiteHeader />
        <main className="flex-grow flex items-center justify-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </main>
        <SiteFooter />
      </div>
    }>
      <CheckoutPageContent />
    </Suspense>
  );
}


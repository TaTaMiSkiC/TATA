
import { SiteHeader } from '@/components/layout/SiteHeader';
import { SiteFooter } from '@/components/layout/SiteFooter';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { getAllFragrances } from '@/services/fragranceService';
import type { Fragrance } from '@/lib/types';
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from '@/components/ui/breadcrumb';
import { SprayCan } from 'lucide-react';

export default async function FragranceInfoPage() {
  const fragrances: Fragrance[] = await getAllFragrances();

  return (
    <div className="flex flex-col min-h-screen">
      <SiteHeader />
      <main className="flex-grow container mx-auto py-12 px-4">
        <Breadcrumb className="mb-8">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/">Početna</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>Informacije o mirisima</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        <h1 className="text-4xl font-bold mb-8 text-center">Naši Mirisi</h1>
        <p className="text-center text-lg text-muted-foreground mb-12 max-w-2xl mx-auto">
          Otkrijte paletu pažljivo odabranih mirisa koje koristimo u našim svijećama. Svaki miris je dizajniran da stvori jedinstvenu atmosferu u vašem domu.
        </p>

        {fragrances.length === 0 ? (
          <Card className="max-w-lg mx-auto shadow-lg">
            <CardHeader>
              <CardTitle className="text-center flex items-center justify-center">
                <SprayCan className="mr-2 h-6 w-6 text-primary" />
                Nema dostupnih mirisa
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-center text-muted-foreground">
                Trenutno nema detaljnih informacija o mirisima. Molimo provjerite kasnije.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {fragrances.map((fragrance) => (
              <Card key={fragrance.id} className="shadow-lg hover:shadow-xl transition-shadow duration-300">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <SprayCan className="mr-3 h-6 w-6 text-primary" />
                    {fragrance.name}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {fragrance.description ? (
                    <p className="text-muted-foreground">{fragrance.description}</p>
                  ) : (
                    <p className="text-muted-foreground italic">Nema detaljnog opisa za ovaj miris.</p>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
         <div className="mt-12 text-center">
            <p className="text-sm text-muted-foreground">
                Za specifične mirise dostupne za pojedine proizvode, molimo pogledajte detalje na stranici proizvoda.
            </p>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}

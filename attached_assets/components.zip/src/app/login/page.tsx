
"use client";

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { APP_NAME } from '@/lib/constants';
import { SiteHeader } from '@/components/layout/SiteHeader';
import { SiteFooter } from '@/components/layout/SiteFooter';
import { ArrowLeft, LogIn, Loader2 } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useRouter } from 'next/navigation';
import { useState, useRef } from 'react'; // Added useRef
import type { User } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';

export default function LoginPage() {
  const auth = useAuth();
  const router = useRouter();
  const { toast } = useToast();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const formRef = useRef<HTMLFormElement>(null); // Added form ref

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setIsLoggingIn(true);
    
    try {
      const loginResult = await auth.login_DEV_ONLY(email, password);
      
      if (loginResult === 'user_not_found') {
         toast({
          title: "Prijava neuspješna",
          description: "Korisnik s unesenom email adresom nije pronađen.",
          variant: "destructive",
        });
      } else if (loginResult === 'invalid_password') {
        toast({
          title: "Prijava neuspješna",
          description: "Unesena lozinka nije ispravna.",
          variant: "destructive",
        });
      } else if (loginResult) { // loginResult is a role string on success
        toast({
          title: "Prijava uspješna",
          description: `Dobrodošli! Prijavljeni ste kao ${loginResult}.`,
        });

        if (loginResult === 'admin' || loginResult === 'moderator') {
          router.push('/admin/dashboard');
        } else if (loginResult === 'korisnik') {
          router.push('/account'); 
        } else {
          router.push('/'); 
        }
      } else {
         toast({ // Should not happen with new loginResult types, but as a fallback
          title: "Prijava neuspješna",
          description: "Došlo je do nepoznate greške prilikom prijave.",
          variant: "destructive",
        });
      }
    } catch (error) {
        console.error("Login error:", error);
        toast({
          title: "Greška pri prijavi",
          description: "Dogodila se neočekivana greška. Molimo pokušajte ponovno.",
          variant: "destructive",
        });
    } finally {
        setIsLoggingIn(false);
    }
  };

  const handleInputKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter' && !isLoggingIn) {
      event.preventDefault(); // Prevent default Enter key behavior on input
      formRef.current?.requestSubmit(); // Trigger form's onSubmit programmatically
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      <SiteHeader />
      <main className="flex-grow flex items-center justify-center py-12 px-4">
        <div className="w-full max-w-md space-y-8">
           <Button variant="ghost" asChild className="mb-4">
            <Link href="/">
              <ArrowLeft className="mr-2 h-4 w-4" /> Natrag na početnu
            </Link>
          </Button>
          <Card className="shadow-xl">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl font-bold text-primary">{APP_NAME}</CardTitle>
              <CardDescription>Prijavite se na svoj račun</CardDescription>
            </CardHeader>
            <CardContent>
              <form ref={formRef} onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="email">Email adresa</Label>
                  <Input 
                    id="email" 
                    type="email" 
                    placeholder="vas@primjer.com" 
                    required 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    disabled={isLoggingIn}
                    onKeyDown={handleInputKeyDown} // Added onKeyDown
                  />
                  <p className="text-xs text-muted-foreground">
                    Test korisnici: <code className="bg-muted px-1 rounded">admin@example.com</code> (pw: adminpassword), <code className="bg-muted px-1 rounded">v.miskic2@gmail.com</code> (pw: Marija24), <code className="bg-muted px-1 rounded">moderator@example.com</code> (pw: moderatorpassword), <code className="bg-muted px-1 rounded">ivo.ivic@example.com</code> (pw: password123)
                  </p>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="password">Lozinka</Label>
                    <Link href="/forgot-password" passHref>
                      <Button variant="link" size="sm" className="px-0 text-sm" disabled={isLoggingIn}>Zaboravili ste lozinku?</Button>
                    </Link>
                  </div>
                  <Input 
                    id="password" 
                    type="password" 
                    required 
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Unesite vašu lozinku"
                    disabled={isLoggingIn}
                    onKeyDown={handleInputKeyDown} // Added onKeyDown
                  />
                </div>
                <Button type="submit" className="w-full bg-primary hover:bg-primary/90" disabled={isLoggingIn}>
                  {isLoggingIn ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <LogIn className="mr-2 h-4 w-4" />}
                  {isLoggingIn ? "Prijava..." : "Prijava"}
                </Button>
              </form>
            </CardContent>
            <CardFooter className="flex flex-col items-center space-y-2">
              <p className="text-sm text-muted-foreground">
                Nemate račun?{' '}
                <Link href="/register" passHref>
                   <Button variant="link" className="text-primary px-1" disabled={isLoggingIn}>Registrirajte se</Button>
                </Link>
              </p>
            </CardFooter>
          </Card>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}

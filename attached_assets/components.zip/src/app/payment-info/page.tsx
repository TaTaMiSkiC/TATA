
import { SiteHeader } from '@/components/layout/SiteHeader';
import { SiteFooter } from '@/components/layout/SiteFooter';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { getAdminPaymentSettings, type AdminPaymentSettings, type BankAccountConfig, type PayPalConfig } from '@/services/payment';
import { Banknote, CreditCard, Info, Landmark, Mail } from 'lucide-react';
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from '@/components/ui/breadcrumb';

export default async function PaymentInfoPage() {
  const paymentSettings: AdminPaymentSettings | null = await getAdminPaymentSettings();

  const bankDetails = paymentSettings?.bank?.active ? paymentSettings.bank : null;
  const paypalDetails = paymentSettings?.paypal?.active ? paymentSettings.paypal : null;

  return (
    <div className="flex flex-col min-h-screen">
      <SiteHeader />
      <main className="flex-grow container mx-auto py-12 px-4">
        <Breadcrumb className="mb-8">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/">Početna</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>Informacije o plaćanju</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        <h1 className="text-4xl font-bold mb-8 text-center">Informacije o plaćanju</h1>
        
        {!bankDetails && !paypalDetails && (
          <Card className="max-w-lg mx-auto shadow-lg">
            <CardHeader>
              <CardTitle className="text-center flex items-center justify-center">
                <Info className="mr-2 h-6 w-6 text-primary" />
                Kontaktirajte nas
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-center text-muted-foreground">
                Trenutno nisu konfigurirane online metode plaćanja. Molimo vas da nas kontaktirate za dogovor oko plaćanja vaše narudžbe.
              </p>
            </CardContent>
          </Card>
        )}

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {bankDetails && (
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Landmark className="mr-3 h-7 w-7 text-primary" />
                  Bankovni Transfer
                </CardTitle>
                <CardDescription>Podaci za uplatu putem bankovnog transfera.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Naziv banke:</p>
                  <p className="font-semibold">{bankDetails.bankName}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Nositelj računa:</p>
                  <p className="font-semibold">{bankDetails.accountHolder}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">IBAN:</p>
                  <p className="font-semibold">{bankDetails.iban}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">BIC/SWIFT:</p>
                  <p className="font-semibold">{bankDetails.bic}</p>
                </div>
                <div className="pt-2">
                  <p className="text-xs text-muted-foreground">
                    Molimo vas da kao poziv na broj navedete broj vaše narudžbe. Vaša narudžba će biti obrađena nakon vidljive uplate.
                  </p>
                </div>
              </CardContent>
            </Card>
          )}

          {paypalDetails && (
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <svg className="mr-3 h-7 w-7 text-primary" role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><title>PayPal</title><path fill="currentColor" d="M7.058 20.999h3.08l.474-2.844c.12-.76.509-1.424.888-1.813.4-.408.95-.712 1.64-.897.69-.19 1.49-.288 2.39-.288 1.89 0 3.1.336 3.81 1.01.69.66.99 1.62.89 2.88-.06 1.08-.53 1.95-1.43 2.62-.89.68-2.06 1.01-3.52 1.01h-.95c-.12 0-.18.02-.18.05 0 .03.01.1.04.2l.68 4.09h-3.29l-1.37-8.237H5.318L4.01 23.999H.727l2.12-12.73H6.73c.39.01.63.05.7.11.08.07.12.26.12.58L7.059 21zm16.17-11.6l-.447 2.75c-.11.75-.5 1.41-.88 1.8-.39.4-.94.71-1.63.9-.69.18-1.48.28-2.38.28-1.89 0-3.1-.33-3.82-1-.69-.67-.99-1.62-.89-2.88.07-1.08.53-1.95 1.43-2.62.9-.68 2.06-1.01 3.52-1.01h.95c.12 0 .18-.02.18-.05s-.01-.1-.04-.2L18.361.05h3.29l-.78 4.69h3.35l-.712 4.26h-3.35z"/></svg>
                  PayPal
                </CardTitle>
                <CardDescription>Podaci za uplatu putem PayPal-a.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">PayPal Email:</p>
                  <p className="font-semibold flex items-center">
                     <Mail className="mr-2 h-4 w-4 text-muted-foreground" />
                    {paypalDetails.email}
                  </p>
                </div>
                <div className="pt-2">
                  <p className="text-xs text-muted-foreground">
                    Nakon odabira PayPal plaćanja prilikom završetka narudžbe, bit ćete preusmjereni na PayPal stranicu za dovršetak uplate.
                    Alternativno, možete poslati uplatu direktno na gore navedeni email.
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
         { (bankDetails || paypalDetails) && (
            <Card className="mt-8 max-w-4xl mx-auto shadow-lg">
                <CardHeader>
                     <CardTitle className="flex items-center">
                        <CreditCard className="mr-3 h-7 w-7 text-primary"/>
                        Plaćanje karticama
                     </CardTitle>
                     <CardDescription>Informacije o plaćanju kreditnim i debitnim karticama.</CardDescription>
                </CardHeader>
                <CardContent>
                    <p className="text-muted-foreground">
                        Trenutno ne podržavamo direktno plaćanje karticama putem web stranice. Za plaćanje karticom, molimo odaberite PayPal kao metodu plaćanja. Putem PayPal-a možete sigurno platiti svojom karticom čak i ako nemate PayPal račun.
                    </p>
                </CardContent>
            </Card>
         )}
      </main>
      <SiteFooter />
    </div>
  );
}

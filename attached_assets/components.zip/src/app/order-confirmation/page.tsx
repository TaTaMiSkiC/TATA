
"use client";

import { useEffect, useState, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { SiteHeader } from '@/components/layout/SiteHeader';
import { SiteFooter } from '@/components/layout/SiteFooter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Loader2, CheckCircle, ShoppingBag, Palette } from 'lucide-react'; // Added Palette
import type { Order } from '@/lib/types';
import { getOrderById } from '@/services/orderService'; 
import { useToast } from '@/hooks/use-toast';
import { useCart } from '@/hooks/useCart'; 

function OrderConfirmationContent() {
  const searchParams = useSearchParams();
  const orderId = searchParams.get('orderId');
  const paymentStatus = searchParams.get('payment_status');
  const { toast } = useToast();
  const { clearCart, items: cartItemsHook } = useCart(); 

  const [order, setOrder] = useState<Order | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (orderId) {
      const fetchOrderDetails = async () => {
        setIsLoading(true);
        try {
          let fetchedOrder = await getOrderById(orderId);
          if (fetchedOrder) {
            if (paymentStatus === 'success' && fetchedOrder.paymentMethod === 'PayPal' && fetchedOrder.status !== 'Plaćeno') {
               fetchedOrder.status = 'Plaćeno'; 
            }
            setOrder(fetchedOrder);

            if (paymentStatus === 'success' && cartItemsHook.length > 0) {
              clearCart();
              toast({
                title: "Plaćanje uspješno",
                description: "Vaša uplata je zaprimljena i košarica je ispražnjena.",
              });
            }
          } else {
            toast({ title: "Greška", description: "Narudžba nije pronađena.", variant: "destructive" });
          }
        } catch (error) {
          console.error("Greška pri dohvaćanju narudžbe:", error);
          toast({ title: "Greška", description: "Nije uspjelo dohvaćanje detalja narudžbe.", variant: "destructive" });
        } finally {
          setIsLoading(false);
        }
      };
      fetchOrderDetails();
    } else {
      setIsLoading(false);
      toast({ title: "Greška", description: "Nedostaje ID narudžbe.", variant: "destructive" });
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps 
  }, [orderId, paymentStatus, toast, clearCart, cartItemsHook.length]); 

  if (isLoading) {
    return (
      <div className="flex flex-col min-h-screen">
        <SiteHeader />
        <main className="flex-grow flex items-center justify-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
          <p className="ml-4">Učitavanje potvrde narudžbe...</p>
        </main>
        <SiteFooter />
      </div>
    );
  }
  
  if (!orderId || !order) {
    return (
      <div className="flex flex-col min-h-screen">
        <SiteHeader />
        <main className="flex-grow container mx-auto py-12 px-4 text-center">
           <Card className="max-w-md mx-auto shadow-lg">
            <CardHeader>
                <CardTitle className="text-2xl text-destructive">Narudžba nije pronađena</CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-muted-foreground mb-6">
                    Nismo mogli pronaći detalje za traženu narudžbu. Molimo provjerite ID narudžbe ili kontaktirajte podršku.
                </p>
                <Button asChild>
                    <Link href="/">Povratak na početnu</Link>
                </Button>
            </CardContent>
           </Card>
        </main>
        <SiteFooter />
      </div>
    );
  }


  return (
    <div className="flex flex-col min-h-screen">
      <SiteHeader />
      <main className="flex-grow container mx-auto py-12 px-4">
        <Card className="max-w-2xl mx-auto shadow-xl">
          <CardHeader className="text-center">
            <CheckCircle className="mx-auto h-16 w-16 text-green-500 mb-4" />
            <CardTitle className="text-3xl font-bold text-primary">Narudžba uspješno zaprimljena!</CardTitle>
            <CardDescription className="text-lg">Hvala vam na kupovini, {order.customerName}.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-center">
              Vaša narudžba broj <strong className="text-primary">#{order.id}</strong> je uspješno kreirana.
              Poslali smo potvrdu na vašu email adresu: <strong className="text-primary">{order.customerEmail}</strong>.
            </p>
            <div className="border p-4 rounded-md bg-muted/50 space-y-2">
              <h3 className="font-semibold mb-2">Detalji narudžbe:</h3>
              <p><strong>Datum narudžbe:</strong> {new Date(order.orderDate).toLocaleDateString('hr-HR')}</p>
              <p><strong>Status narudžbe:</strong> <span className={`font-semibold ${order.status === 'Plaćeno' ? 'text-green-600' : ''}`}>{order.status}</span></p>
              <p><strong>Adresa za dostavu:</strong> {order.shippingAddress}</p>
              <p><strong>Način plaćanja:</strong> {order.paymentMethod}</p>
              <p><strong>Ukupan iznos:</strong> {order.totalAmount.toFixed(2)} €</p>
              {order.notes && <p><strong>Napomene:</strong> {order.notes}</p>}
              
              <div className="pt-2">
                <h4 className="font-medium text-sm mb-1">Naručeni proizvodi:</h4>
                <ul className="list-disc list-inside text-sm space-y-1">
                  {order.items.map((item, index) => (
                    <li key={`${item.id}-${index}`}>
                      {item.name} (x{item.quantity})
                      {item.selectedFragrance && <span className="text-xs text-muted-foreground"> - Miris: {item.selectedFragrance}</span>}
                      {item.selectedColor && <span className="text-xs text-muted-foreground"> - Boja: {item.selectedColor}</span>} {/* Display selected color */}
                      : {(item.price * item.quantity).toFixed(2)} €
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            {order.paymentMethod === "Bankovni Transfer" && order.status !== 'Plaćeno' && (
                <div className="border p-4 rounded-md bg-accent/10 text-accent-foreground">
                    <h3 className="font-semibold mb-2 text-accent">Podaci za bankovni transfer:</h3>
                    <p className="text-sm">
                        Molimo izvršite uplatu na račun naveden na našoj <Link href="/payment-info" className="underline hover:text-primary font-medium">stranici s informacijama o plaćanju</Link>, koristeći broj narudžbe <strong className="text-primary">#{order.id}</strong> kao poziv na broj.
                    </p>
                </div>
            )}
             {order.paymentMethod === "PayPal" && order.status !== 'Plaćeno' && !paymentStatus && (
                <div className="border p-4 rounded-md bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-300">
                    <h3 className="font-semibold mb-2">PayPal plaćanje na čekanju:</h3>
                    <p className="text-sm">
                        Vaša PayPal uplata se obrađuje ili je prekinuta. Ako uplata nije prošla, molimo provjerite svoj PayPal račun. Status narudžbe će biti ažuriran čim primimo potvrdu uplate.
                    </p>
                </div>
            )}

            <p className="text-center text-sm text-muted-foreground">
              Svoje narudžbe možete pratiti na stranici <Link href="/account?tab=orders" className="underline hover:text-primary">Moj račun</Link>.
            </p>
          </CardContent>
          <CardFooter className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button asChild>
              <Link href="/products">
                <ShoppingBag className="mr-2 h-4 w-4" /> Nastavi kupovinu
              </Link>
            </Button>
            <Button variant="outline" asChild>
              <Link href="/account?tab=orders">Moje narudžbe</Link>
            </Button>
          </CardFooter>
        </Card>
      </main>
      <SiteFooter />
    </div>
  );
}

export default function OrderConfirmationPage() {
  return (
    <Suspense fallback={
      <div className="flex flex-col min-h-screen">
        <SiteHeader />
        <main className="flex-grow flex items-center justify-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </main>
        <SiteFooter />
      </div>
    }>
      <OrderConfirmationContent />
    </Suspense>
  );
}



"use client";

import { useEffect, useState, Suspense } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { SiteHeader } from '@/components/layout/SiteHeader';
import { SiteFooter } from '@/components/layout/SiteFooter';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import type { User, Order as OrderType } from '@/lib/types'; // Renamed Order to OrderType to avoid conflict
import { getUserById, updateUser } from '@/services/userService';
import { getOrdersByUserId } from '@/services/orderService';
import { Loader2, User as UserIcon, ShoppingBag, Settings, Edit3, Save, Eye, ArrowLeft, ShieldCheck } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import Link from 'next/link';
import { APP_NAME } from '@/lib/constants';
import { Switch } from '@/components/ui/switch';

// Wrapper component to use useSearchParams
function AccountPageContent() {
  const auth = useAuth();
  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();

  const [user, setUser] = useState<User | null>(null);
  const [orders, setOrders] = useState<OrderType[]>([]);
  const [isLoadingUser, setIsLoadingUser] = useState(true);
  const [isLoadingOrders, setIsLoadingOrders] = useState(true);
  const [isEditingDetails, setIsEditingDetails] = useState(false);

  // Form state for editing user details
  const [editForm, setEditForm] = useState({
    name: '',
    email: '', 
    address: '',
    phone: '',
    bankAccountNumber: ''
  });

  const activeTab = searchParams.get('tab') || 'details';

  useEffect(() => {
    if (auth.isLoading) return;
    if (!auth.isLoggedIn || !auth.userId) {
      router.push('/login');
      return;
    }

    const fetchUserData = async () => {
      setIsLoadingUser(true);
      try {
        const fetchedUser = await getUserById(auth.userId!);
        if (fetchedUser) {
          setUser(fetchedUser);
          setEditForm({
            name: fetchedUser.name || '',
            email: fetchedUser.email || '',
            address: fetchedUser.address || '',
            phone: fetchedUser.phone || '',
            bankAccountNumber: fetchedUser.bankAccountNumber || ''
          });
        } else {
          toast({ title: "Greška", description: "Korisnik nije pronađen.", variant: "destructive" });
          auth.logout_DEV_ONLY(); 
          router.push('/login');
        }
      } catch (error) {
        console.error("Greška pri dohvaćanju korisničkih podataka:", error);
        toast({ title: "Greška", description: "Nije uspjelo dohvaćanje korisničkih podataka.", variant: "destructive" });
      } finally {
        setIsLoadingUser(false);
      }
    };

    const fetchUserOrders = async () => {
      setIsLoadingOrders(true);
      try {
        const fetchedOrders = await getOrdersByUserId(auth.userId!);
        setOrders(fetchedOrders);
      } catch (error) {
        console.error("Greška pri dohvaćanju narudžbi:", error);
        toast({ title: "Greška", description: "Nije uspjelo dohvaćanje narudžbi.", variant: "destructive" });
      } finally {
        setIsLoadingOrders(false);
      }
    };

    fetchUserData();
    fetchUserOrders();

  }, [auth.isLoading, auth.isLoggedIn, auth.userId, router, toast, auth.logout_DEV_ONLY]);


  const handleEditFormChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEditForm({ ...editForm, [e.target.name]: e.target.value });
  };

  const handleSaveChanges = async () => {
    if (!user) return;
    setIsLoadingUser(true); 
    try {
      const updatedUserData: Partial<User> = {
        name: editForm.name,
        address: editForm.address,
        phone: editForm.phone,
        bankAccountNumber: editForm.bankAccountNumber,
      };
      const updatedUser = await updateUser(user.id, updatedUserData);
      if (updatedUser) {
        setUser(updatedUser);
        toast({ title: "Uspjeh", description: "Vaši podaci su uspješno ažurirani." });
        setIsEditingDetails(false);
      } else {
        toast({ title: "Greška", description: "Nije uspjelo ažuriranje podataka.", variant: "destructive" });
      }
    } catch (error) {
      console.error("Greška pri spremanju podataka:", error);
      toast({ title: "Greška", description: "Nije uspjelo spremanje podataka.", variant: "destructive" });
    } finally {
      setIsLoadingUser(false);
    }
  };

  const getOrderStatusBadgeVariant = (status: OrderType['status']) => {
    switch (status) {
      case 'Plaćeno':
      case 'Dostavljeno':
        return 'default';
      case 'Poslano':
        return 'secondary';
      case 'U obradi':
        return 'outline';
      case 'Otkazano':
        return 'destructive';
      default:
        return 'outline';
    }
  };


  if (auth.isLoading || isLoadingUser) {
    return (
      <div className="flex flex-col min-h-screen">
        <SiteHeader />
        <main className="flex-grow flex items-center justify-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
          <p className="ml-4 text-lg">Učitavanje podataka o računu...</p>
        </main>
        <SiteFooter />
      </div>
    );
  }

  if (!user) {
    return (
         <div className="flex flex-col min-h-screen">
            <SiteHeader />
            <main className="flex-grow container mx-auto py-12 px-4 text-center">
                <p className="text-xl text-muted-foreground">Korisnik nije pronađen ili niste prijavljeni.</p>
                <Button onClick={() => router.push('/login')} className="mt-4">Idi na prijavu</Button>
            </main>
            <SiteFooter />
        </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen">
      <SiteHeader />
      <main className="flex-grow container mx-auto py-8 px-4">
        <div className="flex items-center justify-between mb-8">
            <h1 className="text-3xl font-bold">Moj Račun</h1>
            {(auth.isAdmin || auth.isModerator) && (
                 <Button variant="outline" asChild>
                    <Link href="/admin/dashboard">
                        <ShieldCheck className="mr-2 h-4 w-4" /> Admin Panel
                    </Link>
                 </Button>
            )}
        </div>

        <Tabs value={activeTab} onValueChange={(value) => router.push(`/account?tab=${value}`)} className="w-full">
          <TabsList className="grid w-full grid-cols-1 sm:grid-cols-3 mb-6">
            <TabsTrigger value="details"><UserIcon className="mr-2 h-4 w-4 sm:hidden md:inline-block" />Moji Podaci</TabsTrigger>
            <TabsTrigger value="orders"><ShoppingBag className="mr-2 h-4 w-4 sm:hidden md:inline-block" />Moje Narudžbe</TabsTrigger>
            <TabsTrigger value="settings"><Settings className="mr-2 h-4 w-4 sm:hidden md:inline-block" />Postavke Računa</TabsTrigger>
          </TabsList>

          <TabsContent value="details">
            <Card className="shadow-lg">
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                    <CardTitle>Detalji o računu</CardTitle>
                    <CardDescription>Pregledajte i ažurirajte svoje osobne podatke.</CardDescription>
                </div>
                {!isEditingDetails ? (
                    <Button variant="outline" onClick={() => setIsEditingDetails(true)}>
                        <Edit3 className="mr-2 h-4 w-4" /> Uredi Podatke
                    </Button>
                ) : (
                     <div className="flex gap-2">
                        <Button variant="outline" onClick={() => setIsEditingDetails(false)} disabled={isLoadingUser}>
                            Odustani
                        </Button>
                        <Button onClick={handleSaveChanges} disabled={isLoadingUser}>
                            {isLoadingUser ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                            Spremi Promjene
                        </Button>
                    </div>
                )}
              </CardHeader>
              <CardContent className="space-y-6">
                {isEditingDetails ? (
                  <form className="space-y-4">
                    <div>
                      <Label htmlFor="name">Puno ime i prezime</Label>
                      <Input id="name" name="name" value={editForm.name} onChange={handleEditFormChange} />
                    </div>
                    <div>
                      <Label htmlFor="email">Email adresa</Label>
                      <Input id="email" name="email" type="email" value={editForm.email} disabled /> 
                      <p className="text-xs text-muted-foreground mt-1">Email se ne može mijenjati putem ovog obrasca.</p>
                    </div>
                    <div>
                      <Label htmlFor="address">Adresa (Ulica i broj, poštanski broj Mjesto)</Label>
                      <Input id="address" name="address" value={editForm.address} onChange={handleEditFormChange} placeholder="Npr. Cvjetna ulica 5, 10000 Zagreb" />
                    </div>
                    <div>
                      <Label htmlFor="phone">Broj telefona</Label>
                      <Input id="phone" name="phone" type="tel" value={editForm.phone} onChange={handleEditFormChange} placeholder="Npr. 0912345678" />
                    </div>
                     <div>
                      <Label htmlFor="bankAccountNumber">Broj bankovnog računa (IBAN)</Label>
                      <Input id="bankAccountNumber" name="bankAccountNumber" value={editForm.bankAccountNumber} onChange={handleEditFormChange} placeholder="Npr. HR1234567890123456789 (Opcionalno)" />
                    </div>
                  </form>
                ) : (
                  <div className="space-y-3">
                    <InfoRow label="Puno ime i prezime:" value={user.name || 'Nije uneseno'} />
                    <InfoRow label="Email adresa:" value={user.email} />
                    <InfoRow label="Adresa:" value={user.address || 'Nije uneseno'} />
                    <InfoRow label="Broj telefona:" value={user.phone || 'Nije uneseno'} />
                    <InfoRow label="Broj bankovnog računa:" value={user.bankAccountNumber || 'Nije uneseno'} />
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="orders">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>Povijest narudžbi</CardTitle>
                <CardDescription>Pregled svih vaših prethodnih narudžbi.</CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingOrders ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    <p className="ml-3">Učitavanje narudžbi...</p>
                  </div>
                ) : orders.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">Nemate prethodnih narudžbi.</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID Narudžbe</TableHead>
                        <TableHead>Datum</TableHead>
                        <TableHead className="text-right">Ukupno</TableHead>
                        <TableHead className="text-center">Status</TableHead>
                        <TableHead className="text-right">Akcije</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {orders.map((order) => (
                        <TableRow key={order.id}>
                          <TableCell className="font-mono text-xs">{order.id}</TableCell>
                          <TableCell>
                            {new Date(order.orderDate).toLocaleDateString('hr-HR', { day: '2-digit', month: '2-digit', year: 'numeric' })}
                          </TableCell>
                          <TableCell className="text-right font-medium">{order.totalAmount.toFixed(2)} €</TableCell>
                          <TableCell className="text-center">
                            <Badge variant={getOrderStatusBadgeVariant(order.status)} className="capitalize">
                              {order.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="outline" size="sm" asChild>
                              {/* TODO: Create a user-facing order detail page if needed, or reuse admin one with checks */}
                              <Link href={`/admin/orders/${order.id}`} title="Pregledaj narudžbu (admin link za sada)">
                                <Eye className="mr-2 h-4 w-4" /> Detalji
                              </Link>
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>Postavke Računa</CardTitle>
                <CardDescription>Upravljajte postavkama svog računa.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">Promjena lozinke</h3>
                  <p className="text-sm text-muted-foreground mb-3">Ovdje ćete moći promijeniti svoju lozinku.</p>
                  <Button variant="outline" disabled>Promijeni lozinku (uskoro)</Button>
                </div>
                <hr />
                <div>
                  <h3 className="text-lg font-medium mb-2">Postavke obavijesti</h3>
                  <p className="text-sm text-muted-foreground mb-3">Odaberite koje email obavijesti želite primati.</p>
                  {/* Placeholder for notification settings */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                        <Label htmlFor="newsletter">Pretplata na newsletter {APP_NAME}</Label>
                        <Switch id="newsletter" disabled />
                    </div>
                     <div className="flex items-center justify-between">
                        <Label htmlFor="orderUpdates">Obavijesti o statusu narudžbe</Label>
                        <Switch id="orderUpdates" checked disabled />
                    </div>
                  </div>
                </div>
                 <hr />
                 <div>
                  <h3 className="text-lg font-medium mb-2">Brisanje računa</h3>
                  <p className="text-sm text-muted-foreground mb-3">Trajno obrišite svoj račun i sve povezane podatke.</p>
                  <Button variant="destructive" disabled>Obriši račun (uskoro)</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
      <SiteFooter />
    </div>
  );
}

interface InfoRowProps {
  label: string;
  value: string | number;
}
function InfoRow({ label, value }: InfoRowProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-2 items-center py-2 border-b last:border-b-0">
      <p className="text-sm font-medium text-muted-foreground">{label}</p>
      <p className="md:col-span-2">{value}</p>
    </div>
  );
}

// Export a component that wraps AccountPageContent with Suspense
export default function AccountPage() {
  return (
    <Suspense fallback={
      <div className="flex flex-col min-h-screen">
        <SiteHeader />
        <main className="flex-grow flex items-center justify-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </main>
        <SiteFooter />
      </div>
    }>
      <AccountPageContent />
    </Suspense>
  );
}




import { SiteHeader } from '@/components/layout/SiteHeader';
import { SiteFooter } from '@/components/layout/SiteFooter';
import { ProductList } from '@/components/products/ProductList';
import { getProductsByCategory, getCategoryBySlug, getAllCategories } from '@/services/productService';
import type { Product, Category } from '@/lib/types';
import { notFound } from 'next/navigation';
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from '@/components/ui/breadcrumb';

interface CategoryPageProps {
  params: {
    slug: string;
  };
}

// Generiraj statičke putanje za sve kategorije
export async function generateStaticParams() {
  const categories = await getAllCategories();
  return categories.map((category) => ({
    slug: category.slug,
  }));
}


export default async function CategoryPage({ params }: CategoryPageProps) {
  const category: Category | undefined = await getCategoryBySlug(params.slug);
  
  if (!category) {
    notFound();
  }

  const products: Product[] = await getProductsByCategory(params.slug);

  return (
    <div className="flex flex-col min-h-screen">
      <SiteHeader />
      <main className="flex-grow container mx-auto py-8 px-4">
        <Breadcrumb className="mb-8">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/">Početna</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbLink href="/categories">Kategorije</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>{category.name}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        <h1 className="text-3xl font-bold mb-2">{category.name}</h1>
        {category.description && <p className="text-muted-foreground mb-8">{category.description}</p>}
        
        <ProductList products={products} />
      </main>
      <SiteFooter />
    </div>
  );
}

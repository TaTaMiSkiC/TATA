
"use client";

import { SiteHeader } from '@/components/layout/SiteHeader';
import { SiteFooter } from '@/components/layout/SiteFooter';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from '@/components/ui/breadcrumb';
import { Mail, Phone, MapPin, Loader2 } from 'lucide-react';
import { APP_NAME } from '@/lib/constants';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { useForm, type SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { sendContactEmail } from '@/actions/sendContactEmail'; 

const contactFormSchema = z.object({
  name: z.string().min(2, "Ime i prezime su obavezni.").max(100),
  email: z.string().email("Unesite važeću email adresu."),
  subject: z.string().min(3, "Naslov poruke je obavezan.").max(150),
  message: z.string().min(10, "Poruka mora imati najmanje 10 znakova.").max(1000),
});

type ContactFormData = z.infer<typeof contactFormSchema>;

export default function ContactPage() {
  const { toast } = useToast();
  const form = useForm<ContactFormData>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: '',
      email: '',
      subject: '',
      message: '',
    },
  });

  const { handleSubmit, formState: { isSubmitting }, reset } = form;

  const onSubmit: SubmitHandler<ContactFormData> = async (data) => {
    try {
      const result = await sendContactEmail(data);
      if (result.success) {
        toast({
          title: "Poruka poslana!",
          description: "Hvala vam na poruci. Odgovorit ćemo vam u najkraćem mogućem roku.",
        });
        reset(); 
      } else {
        toast({
          title: "Greška",
          description: result.error || "Nije uspjelo slanje poruke. Molimo pokušajte ponovno.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Contact form submission error:", error);
      toast({
        title: "Greška",
        description: "Došlo je do neočekivane greške. Molimo pokušajte ponovno.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      <SiteHeader />
      <main className="flex-grow container mx-auto py-12 px-4">
        <Breadcrumb className="mb-8">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/">Početna</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>Kontakt</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        <h1 className="text-4xl font-bold mb-8 text-center">Kontaktirajte nas</h1>
        <p className="text-center text-lg text-muted-foreground mb-12 max-w-2xl mx-auto">
          Imate pitanje, prijedlog ili trebate podršku? Javite nam se! Rado ćemo vam pomoći.
        </p>

        <div className="grid md:grid-cols-2 gap-12">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Mail className="mr-3 h-6 w-6 text-primary" />
                Pošaljite nam poruku
              </CardTitle>
              <CardDescription>Ispunite obrazac ispod i odgovorit ćemo vam u najkraćem mogućem roku.</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Ime i prezime</FormLabel>
                        <FormControl>
                          <Input placeholder="Vaše ime i prezime" {...field} disabled={isSubmitting} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email adresa</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="vaš@email.com" {...field} disabled={isSubmitting} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="subject"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Naslov poruke</FormLabel>
                        <FormControl>
                          <Input placeholder="Naslov vaše poruke" {...field} disabled={isSubmitting} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Poruka</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Napišite svoju poruku ovdje..." rows={5} {...field} disabled={isSubmitting} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button type="submit" className="w-full" size="lg" disabled={isSubmitting}>
                    {isSubmitting ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Slanje...
                      </>
                    ) : (
                      "Pošalji poruku"
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center">
                <MapPin className="mr-3 h-6 w-6 text-primary" />
                Naše informacije
              </CardTitle>
              <CardDescription>Ostali načini kako nas možete kontaktirati.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold flex items-center mb-1">
                  <Mail className="mr-2 h-5 w-5 text-muted-foreground" /> Email
                </h3>
                <a href="mailto:daniela.svoboda2@gmail.com" className="text-primary hover:underline">
                  daniela.svoboda2@gmail.com
                </a>
              </div>
              <div>
                <h3 className="text-lg font-semibold flex items-center mb-1">
                  <Phone className="mr-2 h-5 w-5 text-muted-foreground" /> Telefon
                </h3>
                <p>00436603878221</p>
              </div>
              <div>
                <h3 className="text-lg font-semibold flex items-center mb-1">
                  <MapPin className="mr-2 h-5 w-5 text-muted-foreground" /> Adresa
                </h3>
                <p>{APP_NAME} by Dani</p>
                <p>Ossiacher Zeile 30, 9500 Villach, Österreich</p>
              </div>
              <div>
                <h3 className="text-lg font-semibold flex items-center mb-1">
                  Radno vrijeme
                </h3>
                <p>Ponedjeljak - Četvrtak: 13:00 - 20:00</p>
                <p>Petak: 09:00 - 20:00</p>
                <p>Subota: 09:00 - 13:00</p>
                <p>Nedjelja: Zatvoreno</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}


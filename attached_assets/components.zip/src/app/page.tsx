
import { SiteHeader } from '@/components/layout/SiteHeader';
import { SiteFooter } from '@/components/layout/SiteFooter';
import { ProductList } from '@/components/products/ProductList';
import { Button } from '@/components/ui/button';
import { getAllProducts, getAllCategories } from '@/services/productService';
import type { Product, Category } from '@/lib/types';
import Link from 'next/link';
import Image from 'next/image';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowRight } from 'lucide-react';
import { APP_NAME } from '@/lib/constants';

export default async function HomePage() {
  const products: Product[] = await getAllProducts();
  const categories: Category[] = await getAllCategories();

  // Odaberi nekoliko proizvoda za isticanje, npr. prva 4
  const featuredProducts = products.slice(0, 4);
  // Odaberi nekoliko kategorija za isticanje
  const featuredCategories = categories.slice(0, 3); // Changed to 3 to fit better with candle theme

  return (
    <div className="flex flex-col min-h-screen">
      <SiteHeader />
      <main className="flex-grow">
        {/* Hero Sekcija */}
        <section className="relative text-primary-foreground py-20 md:py-32">
           <Image 
            src="https://i.imgur.com/oTqYBpI.jpeg" 
            alt={`${APP_NAME} hero background image of candles`}
            fill
            style={{objectFit: 'cover'}}
            quality={75}
            className="opacity-30"
            data-ai-hint="candles background"
            priority
           />
          <div className="container mx-auto text-center relative z-10">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">Dobrodošli u {APP_NAME}</h1>
            <p className="text-lg md:text-xl mb-8 max-w-2xl mx-auto">Otkrijte svijet jedinstvenih svijeća, ručno izrađenih s ljubavlju.</p>
            <Button asChild size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
              <Link href="/products">Kupujte sada <ArrowRight className="ml-2 h-5 w-5" /></Link>
            </Button>
          </div>
        </section>

        {/* Istaknute Kategorije Sekcija */}
        <section className="py-16 bg-background">
          <div className="container mx-auto">
            <h2 className="text-3xl font-bold text-center mb-12">Istaknute kategorije</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
              {featuredCategories.map((category) => (
                <Link key={category.id} href={`/category/${category.slug}`}>
                  <Card className="hover:shadow-lg transition-shadow duration-300 group">
                    <CardHeader className="p-0">
                       <div className="aspect-[4/3] relative w-full rounded-t-lg overflow-hidden">
                        <Image 
                            src={`https://picsum.photos/seed/cat-${category.slug}/300/200`} 
                            alt={category.name}
                            fill
                            style={{objectFit: 'cover'}}
                            className="group-hover:scale-105 transition-transform duration-300"
                            data-ai-hint={`${category.name.split(' ')[0].toLowerCase()} svijeće`}
                        />
                       </div>
                    </CardHeader>
                    <CardContent className="p-4 text-center">
                      <CardTitle className="text-lg group-hover:text-primary transition-colors">{category.name}</CardTitle>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
             <div className="text-center mt-12">
                <Button variant="outline" asChild>
                    <Link href="/categories">Pogledaj sve kategorije <ArrowRight className="ml-2 h-4 w-4" /></Link>
                </Button>
            </div>
          </div>
        </section>

        {/* Istaknuti Proizvodi Sekcija */}
        <section className="py-16">
          <div className="container mx-auto">
            <h2 className="text-3xl font-bold text-center mb-12">Istaknuti proizvodi</h2>
            <ProductList products={featuredProducts} />
            <div className="text-center mt-12">
                <Button variant="outline" asChild>
                    <Link href="/products">Pogledaj sve proizvode <ArrowRight className="ml-2 h-4 w-4" /></Link>
                </Button>
            </div>
          </div>
        </section>

      </main>
      <SiteFooter />
    </div>
  );
}


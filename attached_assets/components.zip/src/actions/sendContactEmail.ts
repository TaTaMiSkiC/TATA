
"use server";

import nodemailer from 'nodemailer';
import * as z from 'zod';

const contactFormSchema = z.object({
  name: z.string().min(2).max(100),
  email: z.string().email(),
  subject: z.string().min(3).max(150),
  message: z.string().min(10).max(1000),
});

type ContactFormData = z.infer<typeof contactFormSchema>;

//IMPORTANT: Configure these environment variables for your email provider
const SMTP_HOST = process.env.SMTP_HOST || 'smtp.gmail.com'; // Default to Gmail SMTP
const SMTP_PORT = parseInt(process.env.SMTP_PORT || '465', 10); // Default to Gmail SSL port
const SMTP_USER = process.env.SMTP_USER; // Your email address (e.g., daniela.svoboda2@gmail.com)
const SMTP_PASS = process.env.SMTP_PASS; // Your email password or App Password for Gmail
const EMAIL_TO = 'daniela.svoboda2@gmail.com'; // Recipient email address

export async function sendContactEmail(
  data: ContactFormData
): Promise<{ success: boolean; error?: string }> {
  try {
    const validation = contactFormSchema.safeParse(data);
    if (!validation.success) {
      console.error("Contact form validation failed:", validation.error.flatten().fieldErrors);
      return { success: false, error: "Podaci nisu valjani." };
    }

    if (!SMTP_USER || !SMTP_PASS) {
      console.error("SMTP credentials not configured. Email not sent. Check .env file.");
      console.log("Simulating email send for contact form:");
      console.log("From:", data.name, `<${data.email}>`);
      console.log("Subject:", data.subject);
      console.log("Message:", data.message);
      // For development, you can return success here to test the form flow without actual email sending.
      // For production, this should be an error.
      // return { success: true }; // Temporarily return success for UI testing if SMTP is not set
       return { success: false, error: "Konfiguracija email servera nedostaje. Poruka nije poslana." };
    }

    const transporter = nodemailer.createTransport({
      host: SMTP_HOST,
      port: SMTP_PORT,
      secure: SMTP_PORT === 465, // true for 465, false for other ports
      auth: {
        user: SMTP_USER,
        pass: SMTP_PASS,
      },
      // If using Gmail and encounter TLS errors, you might need to add:
      // tls: {
      //   rejectUnauthorized: false // NOT recommended for production, only for debugging
      // }
    });

    const mailOptions = {
      from: `"${data.name}" <${SMTP_USER}>`, // Sender address (your configured email)
      replyTo: data.email, // User's email address as reply-to
      to: EMAIL_TO, // Your recipient email
      subject: `Nova poruka s kontakt forme: ${data.subject}`,
      html: `
        <p>Dobili ste novu poruku s kontakt forme web stranice Kerzenwelt by dani:</p>
        <ul>
          <li><strong>Ime:</strong> ${data.name}</li>
          <li><strong>Email:</strong> ${data.email}</li>
          <li><strong>Naslov:</strong> ${data.subject}</li>
        </ul>
        <p><strong>Poruka:</strong></p>
        <p>${data.message.replace(/\n/g, '<br>')}</p>
      `,
    };

    await transporter.sendMail(mailOptions);
    console.log('Contact email sent successfully to:', EMAIL_TO);
    return { success: true };
  } catch (error) {
    console.error('Error sending contact email:', error);
    let errorMessage = "Slanje poruke nije uspjelo.";
    if (error instanceof Error) {
        // Check for common Nodemailer errors to provide more specific feedback
        if ((error as any).code === 'ECONNECTION' || (error as any).code === 'ETIMEDOUT') {
            errorMessage = "Nije moguće uspostaviti vezu s email serverom. Provjerite mrežne postavke.";
        } else if ((error as any).responseCode === 535 || (error as any).command === 'AUTH LOGIN') {
            errorMessage = "Autentifikacija na email serveru nije uspjela. Provjerite korisničko ime i lozinku.";
        }
    }
    return { success: false, error: errorMessage };
  }
}


export const APP_NAME = "Kerzenwelt";


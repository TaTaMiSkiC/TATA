
"use client";

import type { ReactNode } from 'react';
import React, { createContext, useContext } from 'react';

export function createSafeContext<T>() {
  const context = createContext<T | undefined>(undefined);

  const useSafeContextHook = () => {
    const ctx = useContext(context);
    if (ctx === undefined) {
      throw new Error('useSafeContext must be used within its corresponding Provider');
    }
    return ctx;
  };

  // This is the Provider component that will wrap parts of the app
  // It expects a 'value' prop which is the context value.
  const ProviderComponent = ({ children, value }: { children: ReactNode; value: T }) => {
    return <context.Provider value={value}>{children}</context.Provider>;
  };

  return [ProviderComponent, useSafeContextHook] as const;
}



export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  imageUrl: string;
  categorySlug: string; 
  stock: number;
  fragrances?: string[]; // Array of fragrance names
  hasSelectableColors?: boolean; // New: Does this product allow color selection?
  colorSelections?: string[]; // New: Array of available color names for this product
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string;
}

export interface Fragrance {
  id: string;
  name: string;
  description?: string;
}

export interface ColorOption { // New Interface
  id: string;
  name: string; // e.g., "Crvena", "Plava"
  hexCode?: string; // Optional: e.g., "#FF0000" for visual representation
  description?: string;
}

export interface CartItem {
  // Nasljeđuje svojstva iz Product, ali ih eksplicitno navodimo radi jasnoće u kontekstu košarice
  id: string; // Product ID
  name: string;
  price: number;
  imageUrl: string;
  categorySlug: string; 
  // Stock i description dolaze iz Product objekta, ne moraju biti direktno na CartItem ako se product dohvaća
  
  quantity: number;
  selectedFragrance?: string; // Odabrani miris za ovaj predmet u košarici
  selectedColor?: string; // New: Odabrana boja za ovaj predmet u košarici
}

export interface Order {
  id: string;
  userId: string; 
  customerName: string; 
  customerEmail: string; 
  items: Array<CartItem & { productId?: string }>; // Osiguravamo da itemi u narudžbi imaju selectedFragrance i selectedColor
  totalAmount: number;
  status: 'U obradi' | 'Plaćeno' | 'Poslano' | 'Dostavljeno' | 'Otkazano';
  orderDate: string; 
  shippingAddress: string; 
  paymentMethod?: string; 
  notes?: string;
}

export interface User {
  id: string;
  email: string;
  name?: string;
  password?: string; 
  role: 'korisnik' | 'moderator' | 'admin'; 
  address?: string;
  phone?: string;
  bankAccountNumber?: string; 
  emailVerified?: boolean;
  emailVerificationToken?: string;
  emailVerificationTokenExpires?: string; 
}

export interface Customer {
  id: string;
  name?: string; 
  email: string;
  totalOrders: number;
  totalSpent: number;
  lastOrderDate?: string; 
  userId?: string; 
  address?: string;
  phone?: string;
  nextPurchaseDiscountPercentage?: number | null; 
}

// Details for the user account page
export interface AccountDetails extends User {
  // Potentially more fields specific to account view
}


// Ponovni izvoz iz payment.ts ili definiranje ovdje radi dosljednosti ako se proširi
export type { BankAccountConfig as BankAccount } from '@/services/payment'; 






# **App Name**: Balkan Pazar

## Core Features:

- User Authentication: User authentication and authorization system for both administrators and regular users.
- Category Management: Allow administrators to create, edit, and delete product categories.
- Product Display: Display products with images, descriptions, and prices.

## Style Guidelines:

- Primary color: Green (#4CAF50) to convey trust and growth.
- Secondary color: Light gray (#F0F0F0) for backgrounds and neutral elements.
- Accent: Gold (#FFD700) for highlighting important elements like prices and call-to-action buttons.
- Clean and modern fonts for easy readability.
- Simple, recognizable icons for navigation and product categories.
- Clean and organized layout with clear sections for products, categories, and user accounts.